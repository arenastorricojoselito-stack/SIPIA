# Decisiones técnicas

## ADR-001 · Núcleo MVC nativo

Se aplica DA-01 de la ERS. PHP 8.4, Composer PSR-4 y PDO son la base. PHPUnit se usa en desarrollo. El router y el manejo de errores centralizados cubren la superficie HTTP de la primera etapa. Las dependencias de futuras etapas se evaluarán por licencia, mantenimiento y seguridad.

## ADR-002 · Aislamiento inicial en PostgreSQL

El rol de aplicación carece de privilegios administrativos y seguridad por fila limita la lectura por institución. El ámbito se fija localmente a una transacción. El esquema se administrará mediante SQL versionado, con credenciales privilegiadas confinadas al servicio de migración. La autorización previa del ámbito se integrará con la identidad en la etapa correspondiente.

## ADR-003 · Alcance y nomenclatura documental

Se conservan ambas fuentes v1.1 sin edición. Los nombres de los documentos técnicos siguen la instrucción de inicio del desarrollo. Las referencias a otros nombres en la ERS corresponden a su propuesta de organización.

## ADR-004 · Dependencias de desarrollo

Composer fija PHPUnit y sus dependencias en el archivo de bloqueo. El
núcleo usa PHP y PDO sin paquetes Composer de ejecución. En desarrollo
se elige PHP 8.4 y PostgreSQL 16 como versiones de referencia. La revisión
de licencias de bibliotecas de procesamiento y modelos se hará antes de
adoptarlos.

## ADR-005 · Alta institucional y cuentas

El alta inicial es una operación de mantenimiento por CLI. La interfaz
institucional administra el nombre y las cuentas de su propia
institución. La cuenta y su correo pertenecen a una institución. Una
persona que colabora con otras instituciones dispone de cuentas
separadas. Los roles iniciales siguen los actores de la ERS. El
administrador institucional gestiona cuentas y roles, y la coordinación
tiene lectura de auditoría. Los permisos académicos se incorporarán
junto con los módulos correspondientes conforme a PV-02.

Cada POST autenticado usa un bloqueo transaccional por institución
antes de volver a verificar permisos. Junto con la prohibición de editar
el acceso propio, esto evita que dos administradores se desactiven entre
sí de manera concurrente. Las revocaciones se aplican mediante la
versión de sesión.

## ADR-006 · Catálogos tipados y fichas por cuenta

Los catálogos académicos comparten su estructura y se distinguen por
tipo. Las referencias verifican tipo e institución en PostgreSQL. Se usa
la cuenta institucional como identidad de la ficha, con un identificador
académico propio. El acceso a la gestión académica sigue la línea base de
administración institucional. Cualquier permiso delegado se validará
con PV-02.

Una ficha docente habilitada para tutoría es elegible mientras su cuenta
está activa y mantiene el rol Tutor o evaluador. La asignación a
propuestas, el alcance de revisión y los campos por modalidad se
incorporarán con el flujo correspondiente según PV-02 y PV-04.
