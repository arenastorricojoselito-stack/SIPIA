# Plan de pruebas

| Etapa | Verificación |
|---|---|
| 1 | PHPUnit para rutas, métodos, cabeceras, errores y configuración PDO. SQL con dos instituciones sintéticas para aislamiento, rol web y pgvector. HTTP local para portada, estado, rutas desconocidas y rechazo de métodos. |
| 2–4 | Autenticación, autorización, catálogos y documentos. Cubrir éxito, errores, acceso directo por identificador y cruces de institución. |
| 5–6 | Extracción, OCR, embeddings, trabajos, fallos y reintentos. Corpus etiquetado y evidencia por sección. |
| 7–8 | Correcciones, concurrencia de decisiones, entrega final, informes, restauración, accesibilidad y carga. |

Los CP-01 a CP-23 de la ERS siguen siendo la referencia de aceptación. La prueba inicial SQL cubre la parte de lectura de instituciones de CP-07. Las rutas, colas, documentos y exportaciones de etapas posteriores requieren sus propias pruebas. El README documenta la ejecución local.

## Verificación de Etapa 2

La prueba tests/identity_isolation.sql usa dos instituciones sintéticas,
comprueba lecturas y escrituras con el rol web y revierte sus cambios.
La prueba HTTP tests/administration_flow.py ejercita RF-01 y RF-11 en una
base aislada. Requiere dos instituciones de prueba creadas mediante
bin/provision.php con códigos demo-a y demo-b y correos
admin-a@example.test y admin-b@example.test. Proporciona sus contraseñas
sintéticas mediante SIPIA_TEST_PASSWORD_A y SIPIA_TEST_PASSWORD_B y, si
corresponde, SIPIA_TEST_URL. Ejecuta python tests/administration_flow.py
con Python 3. Usa una base desechable porque la prueba crea cuentas,
renombra una institución y verifica el límite de intentos.

Quedan para las próximas etapas las pruebas de autorización de carreras,
archivos, vectores, colas, reportes y exportaciones.

## Verificación de Etapa 3

La prueba tests/academic_isolation.sql verifica RLS, escrituras cruzadas
y referencias de institución y de tipo. Utiliza datos sintéticos y
revierte sus filas. Ejecuta tests/academic_flow.py con las mismas
instituciones de prueba y variables de la Etapa 2, en una base desechable.
Valida catálogos, roles, formularios, tutoría, auditoría y la retirada de
una gestión predeterminada sin afectar fichas históricas.
