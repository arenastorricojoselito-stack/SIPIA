# Estado del proyecto

## Etapa 1 · Fundamentos

- Base MVC con Composer PSR-4, controladores, vistas, rutas, cabeceras, configuración, validación y logs.
- Compose local con Nginx, PHP-FPM, PostgreSQL 16 y pgvector.
- Migración serializada y repetible. Rol web de solo lectura y aislamiento inicial por fila en instituciones.
- Portada en español, estado de disponibilidad y documentación de arranque.

## Verificación

- PHPUnit 12.5.45 ejecutó 4 pruebas y 11 aserciones con éxito. Composer validó el manifiesto y el archivo de bloqueo. El análisis de sintaxis de PHP pasó.
- La migración inicial y su repetición finalizaron con código 0. Con dos instituciones sintéticas, el rol web no recibió filas sin contexto y solo recibió la propia al aplicar cada contexto. La prueba verificó denegación por identificador, ausencia de permisos de escritura y una operación de pgvector.
- Nginx y PHP-FPM sirvieron la portada y el estado. Se verificaron las respuestas 404 y 405, las cabeceras y el estado 503 durante la detención de PostgreSQL. El estado volvió a estar disponible tras reiniciar la base.
- Para verificar la compilación en la nube, se usó la CA del entorno y el servidor oficial de archivos de GitHub para descargar las mismas revisiones del archivo de bloqueo, porque el proxy bloquea API GitHub. El lock del repositorio conserva las URL originales de Composer.
- La resolución de Composer no reportó avisos de seguridad. Las dependencias instaladas de desarrollo declaran licencias MIT o BSD-3-Clause.

## Pendientes

El procesamiento documental, FastAPI, la cola, el motor semántico, la
evaluación y los informes se mantienen en el plan. Ver ERS v1.1 para las
decisiones institucionales pendientes.

## Arranque de desarrollo en Windows

Se agregó una guía de PHP y PostgreSQL/pgvector locales, un comando de
PowerShell para migración y arranque, y la carga de dos instituciones de
demostración. Se verificaron los comandos equivalentes en Linux con el
servidor integrado de PHP, PostgreSQL en 55432, pgvector, migración, datos
de demostración, aislamiento y las 6 pruebas PHPUnit (14 aserciones).
La ejecución en Windows queda por comprobar en un equipo Windows.

## Etapa 2 · Seguridad y administración

Se incorporaron cuentas por institución, roles, inicio y cierre de
sesión, cambio de contraseña, revocación de sesión, gestión de usuarios,
edición institucional, panel y auditoría. El alta de la primera cuenta
ocurre en consola con una contraseña definida durante la operación.

La migración 002 se aplicó dos veces sobre una base de la Etapa 1 con una
institución preexistente. Se verificó la conservación de esa institución
y la asignación de un código de acceso. Las pruebas SQL de aislamiento
validaron lecturas y escrituras con el rol web y la protección del
historial de auditoría ante cambios. Las pruebas HTTP cubrieron dos
administradores de instituciones diferentes y un usuario con roles
limitados, incluidas peticiones directas por identificador. Se verificaron
autenticación, cierre, CSRF, escape de salida, límites de intentos,
cambio de contraseña, asignación de roles y revocación por desactivación.
Chromium verificó navegación en tamaños móvil y escritorio.

La recuperación y segundo factor dependen de PV-08. El flujo se probó en
Linux con el servidor integrado de PHP y
con Nginx/PHP-FPM. El procedimiento Windows requiere validación en ese equipo.

## Etapa 3 · Gestión académica

Se incorporaron carreras, gestiones y modalidades con registro,
edición, búsqueda, paginación y desactivación. Las fichas de estudiantes
y docentes se vinculan a cuentas institucionales existentes. Se
habilitó el filtro de tutores y la configuración de una gestión de
ingreso predeterminada.

La migración 003 se ejecutó dos veces sobre una base de Etapa 2 y
conservó sus cuentas y eventos de auditoría. Pasaron PHPUnit, las
pruebas SQL de aislamiento y las integraciones HTTP de las etapas 2 y 3.
Se comprobaron permisos en dos instituciones y restricciones de tipo
en las claves foráneas. El flujo se ejecutó en Linux con
el servidor integrado de PHP. La guía de Windows documenta la
actualización sobre una base existente.

La siguiente etapa incorpora el repositorio histórico, fichas de
proyecto, archivos, carga y versiones. La asignación de tutores a
propuestas se incorpora junto con esos flujos, según corresponda.
