# Arquitectura inicial

La aplicación es un monolito modular PHP con un servicio Python especializado previsto para las etapas de procesamiento y similitud. El stack de referencia incluye HTML5, CSS3, Bootstrap 5 y JavaScript con Fetch API para las interfaces de usuario, y PostgreSQL/pgvector para persistencia y búsqueda.

| Área | Responsabilidad |
|---|---|
| public, config | Front controller y composición de dependencias y rutas. |
| app/Http, app/Middleware | Entrada HTTP, dispatch, respuestas, errores y cabeceras. |
| app/Controllers, app/Views | Adaptación HTTP y presentación. Las vistas reciben datos mediante los controladores. |
| app/Services, app/Repositories | Casos de uso y acceso a persistencia. Los futuros modelos representan datos y reglas del dominio. |
| app/Persistence, app/Validation, app/Support | PDO, contexto institucional, validación de configuración y logs. |
| database, bin | Migraciones SQL versionadas y ejecución por CLI. |
| docker, tests | Entorno local, pruebas unitarias e integración. |

Nginx entrega las peticiones a PHP-FPM mediante el punto de entrada fijo `public/index.php`. La portada, el estado técnico, el acceso y las hojas de estilo son recursos públicos. Un contenedor transitorio ejecuta migraciones con credenciales distintas de las del proceso PHP-FPM.

En etapas posteriores, PHP será autoridad de identidad, permisos y transiciones académicas. Una cola PostgreSQL y trabajadores PHP CLI coordinarán extracción, embeddings y comparación mediante FastAPI en la red interna. Cada trabajo llevará institución y versión. El contrato, los reintentos y el acceso a archivos se detallarán antes de integrar el servicio. Se conservarán las referencias exactas de proyecto, versión, documento y análisis.

## Etapa 2 · Identidad y administración

El router distingue GET, HEAD y POST. AuthenticationController gestiona el
inicio y cierre de sesión. AdministrationController expone el panel, la
institución, los usuarios, la cuenta y la auditoría. InstitutionAccess
aplica la sesión, el ámbito institucional, CSRF y los permisos antes de
invocar operaciones. IdentityRepository concentra el SQL.

La administración usa vistas PHP en español, Bootstrap 5.3.8 local bajo
licencia MIT y un menú desplegable. El alta institucional y su primera
cuenta se hacen por CLI con el rol de mantenimiento. El proceso web solo
opera sobre la institución autenticada.

## Etapa 3 · Gestión académica

AcademicController y AcademicRepository administran los catálogos, las
fichas académicas y la gestión predeterminada. Los accesos reutilizan
InstitutionAccess, la sesión institucional, la comprobación CSRF y la
auditoría. El permiso ManageAcademic corresponde al administrador
institucional en esta etapa, conforme a la línea base de la ERS. Las
cuentas de la Etapa 2 se reutilizan para vincular las fichas.
