"""Smoke test for an isolated Etapa 2 database with the demo-a and demo-b admins."""

import os
import re
import uuid

from http_browser import Browser

PASSWORD_A = os.environ["SIPIA_TEST_PASSWORD_A"]
PASSWORD_B = os.environ["SIPIA_TEST_PASSWORD_B"]
SUBJECT = uuid.uuid4().hex[:8]
USER_EMAIL = f"prueba-{SUBJECT}@example.test"
USER_PASSWORD = f"Prueba-{SUBJECT}-clave-inicial"
USER_PASSWORD_UPDATED = f"Prueba-{SUBJECT}-clave-actualizada"
USER_NAME = f"Prueba {SUBJECT} <b>texto</b>"


public = Browser()
assert public.request("/salud", 200)[0] == "Disponible"
assert re.search(r"Bootstrap\s+v5\.3\.8", public.request("/assets/bootstrap.min.css", 200)[0])
assert public.request("/panel", 303)[1]["Location"] == "/iniciar"
public.request("/iniciar", 403, {"csrf": "no-valido"})
denied = public.login("demo-b", "admin-a@example.test", PASSWORD_A, 401)
assert "No se pudo iniciar sesión" in denied

alpha, beta = Browser(), Browser()
alpha.login("demo-a", "admin-a@example.test", PASSWORD_A)
beta.login("demo-b", "admin-b@example.test", PASSWORD_B)
assert "Usuarios registrados" in alpha.request("/panel", 200)[0]
institution_name = f"Instituto A {SUBJECT}"
alpha.request("/institucion", 303, {
    "csrf": alpha.token("/institucion"), "nombre": institution_name,
})
assert institution_name in alpha.request("/panel", 200)[0]
assert institution_name not in beta.request("/panel", 200)[0]

new_token = alpha.token("/usuarios/nuevo")
alpha.request("/usuarios/nuevo", 403, {"csrf": "no-valido"})
alpha.request("/usuarios/nuevo", 422, {
    "csrf": new_token, "nombre": USER_NAME, "correo": USER_EMAIL,
    "clave": USER_PASSWORD, "roles[]": ["rol_invalido"],
})
alpha.request("/usuarios/nuevo", 303, {
    "csrf": new_token, "nombre": USER_NAME, "correo": USER_EMAIL,
    "clave": USER_PASSWORD, "roles[]": ["estudiante"],
})
listing, _ = alpha.request("/usuarios?q=" + SUBJECT, 200)
assert USER_EMAIL in listing and "<b>texto</b>" not in listing and "&lt;b&gt;texto&lt;/b&gt;" in listing
assert USER_EMAIL not in beta.request("/usuarios?q=" + SUBJECT, 200)[0]
path = re.search(r'href="(/usuarios/editar\?id=[0-9]+)"', listing).group(1)
beta.request(path, 404)
beta.request(path, 404, {"csrf": beta.token("/usuarios")})

student = Browser()
student.login("demo-a", USER_EMAIL, USER_PASSWORD)
student.request("/panel", 200)
student.request("/usuarios", 403)
student.request("/auditoria", 403)
student.request("/cuenta", 303, {
    "csrf": student.token("/cuenta"), "actual": USER_PASSWORD,
    "clave": USER_PASSWORD_UPDATED, "confirmacion": USER_PASSWORD_UPDATED,
})
student.request("/panel", 303)
student.login("demo-a", USER_EMAIL, USER_PASSWORD, 401)
student.login("demo-a", USER_EMAIL, USER_PASSWORD_UPDATED)
alpha.request(path, 303, {
    "csrf": alpha.token(path), "nombre": USER_NAME, "correo": USER_EMAIL, "activo": "1",
    "roles[]": ["estudiante", "coordinacion"],
})
student.request("/panel", 303)
student.login("demo-a", USER_EMAIL, USER_PASSWORD_UPDATED)
student.request("/auditoria", 200)
student.request("/usuarios", 403)
alpha.request(path, 303, {
    "csrf": alpha.token(path), "nombre": USER_NAME, "correo": USER_EMAIL,
    "roles[]": ["estudiante", "coordinacion"],
})
assert student.request("/panel", 303)[1]["Location"] == "/iniciar"

audit, _ = alpha.request("/auditoria", 200)
assert "Usuario desactivado" in audit and "Contraseña actualizada" in audit and "Roles actualizados" in audit
assert "Usuario desactivado" not in beta.request("/auditoria", 200)[0]
assert USER_PASSWORD not in audit and USER_PASSWORD_UPDATED not in audit
alpha.request("/salir", 303, {"csrf": alpha.token("/panel")})
assert alpha.request("/usuarios", 303)[1]["Location"] == "/iniciar"

for _ in range(6):
    public.login("demo-b", f"inexistente-{SUBJECT}@example.test", USER_PASSWORD, 401)
assert "Límite de intentos aplicado" in beta.request("/auditoria", 200)[0]
print("Administración HTTP: autenticación, CSRF, RLS, roles, auditoría, revocación y límites verificados.")
