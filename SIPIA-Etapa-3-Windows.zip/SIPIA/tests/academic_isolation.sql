\set ON_ERROR_STOP on
BEGIN;

INSERT INTO sipia.institutions (name) VALUES ('Sede académica A') RETURNING id AS tenant_a \gset
INSERT INTO sipia.institutions (name) VALUES ('Sede académica B') RETURNING id AS tenant_b \gset
INSERT INTO sipia.users (institution_id, name, email, password_hash)
VALUES (:tenant_a, 'Cuenta académica A', 'academica@example.test', 'solo-fixture') RETURNING id AS user_a \gset
INSERT INTO sipia.users (institution_id, name, email, password_hash)
VALUES (:tenant_b, 'Cuenta académica B', 'academica@example.test', 'solo-fixture') RETURNING id AS user_b \gset

INSERT INTO sipia.academic_catalog (institution_id, kind, code, name)
VALUES (:tenant_a, 'carrera', 'INF', 'Carrera A') RETURNING id AS career_a \gset
INSERT INTO sipia.academic_catalog (institution_id, kind, code, name)
VALUES (:tenant_b, 'carrera', 'INF', 'Carrera B') RETURNING id AS career_b \gset
INSERT INTO sipia.academic_catalog (institution_id, kind, code, name)
VALUES (:tenant_a, 'gestion', 'PER', 'Gestión A') RETURNING id AS period_a \gset
INSERT INTO sipia.academic_catalog (institution_id, kind, code, name)
VALUES (:tenant_b, 'gestion', 'PER', 'Gestión B') RETURNING id AS period_b \gset
INSERT INTO sipia.academic_catalog (institution_id, kind, code, name)
VALUES (:tenant_a, 'modalidad', 'MOD', 'Modalidad A') RETURNING id AS modality_a \gset

INSERT INTO sipia.academic_participants (institution_id, kind, user_id, code, career_id, period_id)
VALUES (:tenant_a, 'estudiante', :user_a, 'EST', :career_a, :period_a),
       (:tenant_b, 'estudiante', :user_b, 'EST', :career_b, :period_b);
INSERT INTO sipia.academic_settings (institution_id, default_period_id)
VALUES (:tenant_a, :period_a), (:tenant_b, :period_b);

SELECT set_config('sipia.test_tenant_a', :'tenant_a', true);
SELECT set_config('sipia.test_user_b', :'user_b', true);
SELECT set_config('sipia.test_career_b', :'career_b', true);
SELECT set_config('sipia.test_period_b', :'period_b', true);
SELECT set_config('sipia.test_modality_a', :'modality_a', true);
SET LOCAL ROLE sipia_app;

DO $$
DECLARE
    tenant_a bigint := current_setting('sipia.test_tenant_a')::bigint;
    user_b bigint := current_setting('sipia.test_user_b')::bigint;
    career_b bigint := current_setting('sipia.test_career_b')::bigint;
    period_b bigint := current_setting('sipia.test_period_b')::bigint;
    modality_a bigint := current_setting('sipia.test_modality_a')::bigint;
    rows_changed int;
BEGIN
    IF EXISTS (SELECT FROM sipia.academic_catalog) OR EXISTS (SELECT FROM sipia.academic_participants)
       OR EXISTS (SELECT FROM sipia.academic_settings) THEN
        RAISE EXCEPTION 'El rol web obtuvo datos académicos sin contexto';
    END IF;

    PERFORM set_config('sipia.institution_id', tenant_a::text, true);
    IF (SELECT count(*) FROM sipia.academic_catalog) <> 3
       OR (SELECT count(*) FROM sipia.academic_participants) <> 1
       OR (SELECT count(*) FROM sipia.academic_settings) <> 1 THEN
        RAISE EXCEPTION 'El alcance académico no coincide con el de la institución A';
    END IF;

    UPDATE sipia.academic_catalog SET name = 'Cambio externo' WHERE id = career_b;
    GET DIAGNOSTICS rows_changed = ROW_COUNT;
    IF rows_changed <> 0 THEN
        RAISE EXCEPTION 'Se modificó un catálogo ajeno';
    END IF;
    UPDATE sipia.academic_participants SET code = 'EXTERNO' WHERE user_id = user_b;
    GET DIAGNOSTICS rows_changed = ROW_COUNT;
    IF rows_changed <> 0 THEN
        RAISE EXCEPTION 'Se modificó una ficha ajena';
    END IF;

    BEGIN
        UPDATE sipia.academic_participants SET career_id = career_b;
        RAISE EXCEPTION 'Se permitió una carrera de otra institución';
    EXCEPTION WHEN foreign_key_violation THEN
        NULL;
    END;
    BEGIN
        UPDATE sipia.academic_participants SET period_id = modality_a;
        RAISE EXCEPTION 'Se permitió una modalidad como gestión';
    EXCEPTION WHEN foreign_key_violation THEN
        NULL;
    END;
    BEGIN
        INSERT INTO sipia.academic_participants (institution_id, kind, user_id, code)
        VALUES (tenant_a, 'docente', user_b, 'AJENO');
        RAISE EXCEPTION 'Se permitió una cuenta ajena';
    EXCEPTION WHEN foreign_key_violation THEN
        NULL;
    END;
    BEGIN
        UPDATE sipia.academic_settings SET default_period_id = period_b;
        RAISE EXCEPTION 'Se permitió una gestión predeterminada ajena';
    EXCEPTION WHEN foreign_key_violation THEN
        NULL;
    END;
END
$$;

ROLLBACK;
\echo Catalogos, fichas y configuracion academica aislados
