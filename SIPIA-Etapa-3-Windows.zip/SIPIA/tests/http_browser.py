import http.cookiejar
import os
import re
import urllib.error
import urllib.parse
import urllib.request

BASE = os.environ.get("SIPIA_TEST_URL", "http://127.0.0.1:8080").rstrip("/")


class WithoutRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Browser:
    def __init__(self):
        self.cookies = http.cookiejar.CookieJar()
        self.session = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.cookies), WithoutRedirects()
        )

    def request(self, path, expected, fields=None):
        data = urllib.parse.urlencode(fields, doseq=True).encode() if fields is not None else None
        request = urllib.request.Request(BASE + path, data=data)
        try:
            response = self.session.open(request, timeout=8)
        except urllib.error.HTTPError as failure:
            response = failure
        with response:
            body = response.read().decode("utf-8")
            assert response.code == expected, (path, response.code, body[:180])
            return body, response.headers

    def token(self, path):
        page, _ = self.request(path, 200)
        return re.search(r'name="csrf" value="([a-f0-9]+)"', page).group(1)

    def login(self, code, email, password, expected=303):
        token = self.token("/iniciar")
        session_id = next(cookie.value for cookie in self.cookies if cookie.name == "SIPIASESSID")
        body, headers = self.request("/iniciar", expected, {
            "csrf": token, "codigo": code, "correo": email, "clave": password,
        })
        if expected == 303:
            assert headers["Location"] == "/panel"
            assert session_id != next(cookie.value for cookie in self.cookies if cookie.name == "SIPIASESSID")
        return body
