"""Academic smoke test against disposable demo-a and demo-b institutions."""

import os
import re
import uuid

from http_browser import Browser

TOKEN = uuid.uuid4().hex[:8].upper()
A, B = Browser(), Browser()
CAREERS = "/academico/carreras"
PERIODS = "/academico/gestiones"
MODALITIES = "/academico/modalidades"
STUDENTS = "/academico/estudiantes"
TEACHERS = "/academico/docentes"
SETTINGS = "/academico/configuracion"
USER_PASS = "Prueba-" + TOKEN + "-SIPIA"


def admin_login(browser, suffix):
    browser.login("demo-" + suffix, f"admin-{suffix}@example.test", os.environ[f"SIPIA_TEST_PASSWORD_{suffix.upper()}"])


def save(browser, path, values, expected=303):
    return browser.request(path, expected, {"csrf": browser.token(path), **values})


def create_catalog(browser, path, code, name):
    save(browser, path, {"codigo": code, "nombre": name})
    body, _ = browser.request(path + "?q=" + code, 200)
    assert name in body
    return re.search(r"\?id=(\d+)#formulario", body).group(1)


def create_account(browser, role, name):
    email = f"{name.lower()}@example.test"
    save(browser, "/usuarios/nuevo", {"nombre": name, "correo": email, "clave": USER_PASS, "roles[]": [role]})
    body, _ = browser.request("/usuarios?q=" + name, 200)
    return re.search(r'/usuarios/editar\?id=(\d+)', body).group(1), email


assert Browser().request(CAREERS, 303)[1]["Location"] == "/iniciar"
admin_login(A, "a")
admin_login(B, "b")

A.request(CAREERS, 403, {"csrf": "invalido", "codigo": TOKEN, "nombre": "No autorizado"})
career_a = create_catalog(A, CAREERS, "CAR-" + TOKEN, "Carrera A " + TOKEN)
career_b = create_catalog(B, CAREERS, "CAR-" + TOKEN, "Carrera B " + TOKEN)
period_a = create_catalog(A, PERIODS, "GES-" + TOKEN, "Gestión A " + TOKEN)
period_b = create_catalog(B, PERIODS, "GES-" + TOKEN, "Gestión B " + TOKEN)
modality = create_catalog(A, MODALITIES, "MOD-" + TOKEN, "Modalidad " + TOKEN)
assert "Carrera A " + TOKEN not in B.request(CAREERS, 200)[0]
assert "Carrera B " + TOKEN not in A.request(CAREERS, 200)[0]
assert "Modalidad " + TOKEN not in B.request(MODALITIES, 200)[0]
B.request(f"{CAREERS}?id={career_a}", 404)
B.request(f"{CAREERS}?id={career_a}", 404, {
    "csrf": B.token(CAREERS), "codigo": "FALSO", "nombre": "Edición ajena", "activo": "1",
})
save(A, CAREERS, {"codigo": "car-" + TOKEN.lower(), "nombre": "Duplicada"}, 422)
save(A, SETTINGS, {"gestion": period_b}, 422)
save(A, SETTINGS, {"gestion": modality}, 422)
save(A, SETTINGS, {"gestion": period_a})

student_a, student_email = create_account(A, "estudiante", "AlumnoA" + TOKEN)
teacher_a, teacher_email = create_account(A, "evaluador", "DocenteA" + TOKEN)
student_b, _ = create_account(B, "estudiante", "AlumnoB" + TOKEN)
student_form = STUDENTS + "?nuevo=1"
teacher_form = TEACHERS + "?nuevo=1"
assert f'value="{period_a}" selected' in A.request(student_form, 200)[0]
assert student_b != student_a
assert student_email not in B.request(student_form, 200)[0]

student_data = {"usuario": student_a, "codigo": "EST-" + TOKEN, "carrera": career_a, "gestion": period_a}
save(A, student_form, {**student_data, "usuario": student_b}, 422)
save(A, student_form, {**student_data, "usuario": teacher_a}, 422)
save(A, student_form, {**student_data, "carrera": career_b}, 422)
save(A, student_form, {**student_data, "gestion": modality}, 422)
save(A, student_form, student_data)
save(A, student_form, student_data, 422)
assert "EST-" + TOKEN in A.request(STUDENTS, 200)[0]
assert "EST-" + TOKEN not in B.request(STUDENTS, 200)[0]
B.request(f"{STUDENTS}?id={student_a}", 404)
B.request(f"{STUDENTS}?id={student_a}", 404, {"csrf": B.token(STUDENTS), "codigo": "OTRO"})

save(A, teacher_form, {"usuario": teacher_a, "codigo": "DOC-" + TOKEN, "carrera": career_a, "tutor": "1"})
assert "DOC-" + TOKEN in A.request(TEACHERS + "?tutores=1", 200)[0]
teacher = Browser()
teacher.login("demo-a", teacher_email, USER_PASS)
teacher.request(TEACHERS, 403)
student = Browser()
student.login("demo-a", student_email, USER_PASS)
student.request(CAREERS, 403)
student.request(STUDENTS, 403)

edit_teacher = f"/usuarios/editar?id={teacher_a}"
save(A, edit_teacher, {
    "nombre": "DocenteA" + TOKEN, "correo": teacher_email, "roles[]": ["evaluador"],
})
assert "DOC-" + TOKEN in A.request(TEACHERS, 200)[0]
assert "DOC-" + TOKEN not in A.request(TEACHERS + "?tutores=1", 200)[0]

student_new, _ = create_account(A, "estudiante", "AlumnoNuevo" + TOKEN)
save(A, f"{PERIODS}?id={period_a}", {"codigo": "GES-" + TOKEN, "nombre": "Gestión histórica " + TOKEN})
assert f'value="{period_a}"' not in A.request(SETTINGS, 200)[0]
assert f'value="{period_a}"' not in A.request(student_form, 200)[0]
assert "Gestión histórica " + TOKEN in A.request(STUDENTS, 200)[0]
edit_student = f"{STUDENTS}?id={student_a}"
assert f'value="{period_a}" selected' in A.request(edit_student, 200)[0]
save(A, edit_student, {**student_data, "codigo": "ACT-" + TOKEN})
save(A, student_form, {**student_data, "usuario": student_new}, 422)

audit_a, _ = A.request("/auditoria", 200)
audit_b, _ = B.request("/auditoria", 200)
assert "Gestión predeterminada retirada" in audit_a
assert "Ficha de docente creada" in audit_a and "Ficha de docente creada" not in audit_b
print("Gestión académica HTTP: catálogos, fichas, tutores, configuración, historial, permisos y aislamiento verificados.")
