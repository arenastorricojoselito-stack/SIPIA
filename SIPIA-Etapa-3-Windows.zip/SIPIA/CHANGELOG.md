# Historial de cambios

## Sin publicar

- Guía y comandos de desarrollo en Windows con PHP local y PostgreSQL/pgvector nativos.
- Puerto PostgreSQL configurable y carga reutilizable de dos instituciones sintéticas.

- Base PHP MVC con autoload PSR-4, rutas HTTP, configuración, errores y logs.
- Entorno Docker local con Nginx, PHP-FPM, PostgreSQL y pgvector.
- Migraciones iniciales, seguridad por fila y pruebas de fundamentos.
- Fuentes v1.1 y documentación técnica inicial.

## Etapa 2 · Seguridad y administración

- Alta de instituciones y primera cuenta en consola.
- Autenticación, sesiones, contraseña, límites de intentos y CSRF.
- Panel en Bootstrap, actualización institucional, gestión de usuarios y
  roles, y auditoría institucional con aislamiento en PostgreSQL.

## Etapa 3 · Gestión académica

- Carreras, gestiones y modalidades con búsqueda, edición e inactivación.
- Fichas de estudiantes y docentes vinculadas a usuarios existentes.
- Habilitación de tutores, gestión de ingreso predeterminada y auditoría.
- Migración 003 con aislamiento por institución y referencias tipadas.
