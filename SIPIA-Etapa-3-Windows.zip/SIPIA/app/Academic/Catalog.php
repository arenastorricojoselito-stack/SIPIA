<?php

declare(strict_types=1);

namespace Sipia\Academic;

enum Catalog: string
{
    case Career = 'carrera';
    case Period = 'gestion';
    case Modality = 'modalidad';

    public function label(): string
    {
        return match ($this) {
            self::Career => 'Carreras',
            self::Period => 'Gestiones',
            self::Modality => 'Modalidades',
        };
    }

    public function path(): string
    {
        return '/academico/' . match ($this) {
            self::Career => 'carreras',
            self::Period => 'gestiones',
            self::Modality => 'modalidades',
        };
    }
}
