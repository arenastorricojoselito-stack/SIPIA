<?php

declare(strict_types=1);

namespace Sipia\Academic;

final class AcademicInput
{
    public static function code(string $value): ?string
    {
        $code = strtoupper(trim($value));
        return preg_match('/\A[A-Z0-9][A-Z0-9._\/-]{0,31}\z/', $code) === 1 ? $code : null;
    }

    public static function id(string $value): ?int
    {
        $id = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        return $id === false ? null : $id;
    }

    public static function page(string $value): int
    {
        return filter_var($value, FILTER_VALIDATE_INT, ['options' => [
            'min_range' => 1, 'max_range' => 100000,
        ]]) ?: 1;
    }
}
