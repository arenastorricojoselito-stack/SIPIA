<?php

declare(strict_types=1);

namespace Sipia\Academic;

use Sipia\Security\Role;

enum Participant: string
{
    case Student = 'estudiante';
    case Teacher = 'docente';

    public function role(): Role
    {
        return $this === self::Student ? Role::Student : Role::Evaluator;
    }

    public function label(): string
    {
        return $this === self::Student ? 'Estudiantes' : 'Docentes y tutores';
    }

    public function path(): string
    {
        return $this === self::Student ? '/academico/estudiantes' : '/academico/docentes';
    }
}
