<?php

declare(strict_types=1);

namespace Sipia\Http;

use InvalidArgumentException;

final readonly class Request
{
    public function __construct(
        public string $method,
        public string $path,
        private array $query = [],
        private array $form = [],
        public string $remoteAddress = '',
    ) {
    }

    public static function fromTarget(
        string $method,
        string $target,
        array $query = [],
        array $form = [],
        string $remoteAddress = '',
    ): self {
        $path = explode('?', $target, 2)[0];
        if (!str_starts_with($path, '/') || preg_match('/[\x00-\x20\x7f]/', $path)) {
            throw new InvalidArgumentException('Ruta inválida.');
        }

        return new self($method, $path, $query, $form, $remoteAddress);
    }

    public function query(string $key): string
    {
        return is_string($this->query[$key] ?? null) ? $this->query[$key] : '';
    }

    public function hasQuery(string $key): bool
    {
        return array_key_exists($key, $this->query);
    }

    public function field(string $key): string
    {
        return is_string($this->form[$key] ?? null) ? $this->form[$key] : '';
    }

    public function fields(string $key): array
    {
        return is_array($this->form[$key] ?? null) ? $this->form[$key] : [];
    }
}
