<?php

declare(strict_types=1);

namespace Sipia\Controllers;

use Closure;
use PDO;
use Sipia\Academic\AcademicInput;
use Sipia\Academic\Catalog;
use Sipia\Academic\Participant;
use Sipia\Http\Request;
use Sipia\Http\Response;
use Sipia\Repositories\AcademicRepository;
use Sipia\Repositories\IdentityRepository;
use Sipia\Security\InstitutionAccess;
use Sipia\Security\Permission;
use Sipia\Security\WebSession;
use Sipia\Validation\AccountInput;

final class AcademicController extends Controller
{
    public function __construct(private readonly InstitutionAccess $access, private readonly WebSession $session)
    {
    }

    public function catalog(Request $request, Catalog $kind): Response
    {
        return $this->authorized($request, function (AcademicRepository $academic, IdentityRepository $identity, array $actor) use ($request, $kind): Response {
            $id = AcademicInput::id($request->query('id'));
            $record = $id === null ? null : $academic->catalog($kind, $id);
            if ($request->hasQuery('id') && $record === null) {
                return $this->unavailable($identity, $actor);
            }

            $form = $record ?? ['code' => '', 'name' => '', 'active' => true];
            $error = null;
            if ($request->method === 'POST') {
                $code = AcademicInput::code($request->field('codigo'));
                $name = trim($request->field('nombre'));
                $active = $record === null || $request->field('activo') === '1';
                $form = ['code' => $code ?? $request->field('codigo'), 'name' => $name, 'active' => $active];
                if ($code === null || !AccountInput::validName($name)) {
                    $error = 'Revisa el código y el nombre del catálogo.';
                } elseif ($academic->catalogCodeUsed($kind, $code, $id)) {
                    $error = 'Este código ya está registrado en el catálogo.';
                } else {
                    $this->saveCatalog($academic, $identity, $actor, $kind, $record, $code, $name, $active);
                    return $this->saved($kind->path(), 'El catálogo se guardó.');
                }
            }

            $page = AcademicInput::page($request->query('pagina'));
            $search = $this->search($request);
            $rows = $academic->catalogPage($kind, $search, ($page - 1) * 20);
            return $this->institutionalView('academic_catalog', $kind->label(), $identity, $actor, $this->session, [
                'kind' => $kind, 'id' => $id, 'form' => $form, 'error' => $error,
                'records' => array_slice($rows, 0, 20), 'more' => count($rows) > 20,
                'page' => $page, 'search' => $search,
            ], $error === null ? 200 : 422);
        });
    }

    public function people(Request $request, Participant $kind): Response
    {
        return $this->authorized($request, function (AcademicRepository $academic, IdentityRepository $identity, array $actor) use ($request, $kind): Response {
            if ($request->hasQuery('id') || $request->query('nuevo') === '1' || $request->method === 'POST') {
                return $this->participantForm($request, $kind, $academic, $identity, $actor);
            }

            $page = AcademicInput::page($request->query('pagina'));
            $search = $this->search($request);
            $tutors = $kind === Participant::Teacher && $request->query('tutores') === '1';
            $rows = $academic->participantPage($kind, $search, $tutors, ($page - 1) * 20);
            return $this->institutionalView('academic_people', $kind->label(), $identity, $actor, $this->session, [
                'kind' => $kind, 'records' => array_slice($rows, 0, 20), 'more' => count($rows) > 20,
                'page' => $page, 'search' => $search, 'tutors' => $tutors,
            ]);
        });
    }

    public function settings(Request $request): Response
    {
        return $this->authorized($request, function (AcademicRepository $academic, IdentityRepository $identity, array $actor) use ($request): Response {
            $default = $academic->defaultPeriod();
            $error = null;
            if ($request->method === 'POST') {
                $submitted = $request->field('gestion');
                $period = AcademicInput::id($submitted);
                if ($submitted !== '' && ($period === null || !$this->usableOption($academic, Catalog::Period, $period, null))) {
                    $error = 'Selecciona una gestión activa de tu institución.';
                } else {
                    $academic->setDefaultPeriod((int) $actor['institution_id'], $period);
                    $identity->audit((int) $actor['institution_id'], (int) $actor['id'], 'configuracion_academica_actualizada', $period);
                    return $this->saved('/academico/configuracion', 'La configuración académica se guardó.');
                }
            }

            return $this->institutionalView(
                'academic_settings', 'Configuración académica', $identity, $actor, $this->session,
                ['default' => $default, 'periods' => $academic->options(Catalog::Period), 'error' => $error],
                $error === null ? 200 : 422,
            );
        });
    }

    private function participantForm(
        Request $request, Participant $kind, AcademicRepository $academic, IdentityRepository $identity, array $actor,
    ): Response {
        $id = AcademicInput::id($request->query('id'));
        $record = $id === null ? null : $academic->participant($kind, $id);
        if ($request->hasQuery('id') && $record === null) {
            return $this->unavailable($identity, $actor);
        }

        $student = $kind === Participant::Student;
        $oldCareer = isset($record['career_id']) ? (int) $record['career_id'] : null;
        $oldPeriod = isset($record['period_id']) ? (int) $record['period_id'] : null;
        $form = [
            'user' => $id,
            'code' => $record['code'] ?? '',
            'career' => $oldCareer,
            'period' => $record === null && $student ? $academic->defaultPeriod() : $oldPeriod,
            'tutor' => $record['can_tutor'] ?? false,
        ];
        $error = null;

        if ($request->method === 'POST') {
            $userId = $id ?? AcademicInput::id($request->field('usuario'));
            $code = AcademicInput::code($request->field('codigo'));
            $careerInput = $request->field('carrera');
            $career = AcademicInput::id($careerInput);
            $period = $student ? AcademicInput::id($request->field('gestion')) : null;
            $canTutor = !$student && $request->field('tutor') === '1';
            $form = [
                'user' => $userId, 'code' => $code ?? $request->field('codigo'),
                'career' => $career, 'period' => $period, 'tutor' => $canTutor,
            ];

            $user = $userId === null ? null : $identity->user($userId);
            $eligible = $user !== null && $user['active'] && in_array($kind->role()->value, $identity->roles($userId), true);
            if ($userId === null || ($record === null && (!$eligible || $academic->participant($kind, $userId) !== null))) {
                $error = 'Selecciona una cuenta activa con el rol indicado y sin ficha registrada.';
            } elseif ($code === null || $academic->participantCodeUsed($kind, $code, $userId)) {
                $error = 'Usa un código válido y único para la ficha.';
            } elseif (($student && ($career === null || $period === null)) || ($careerInput !== '' && $career === null)
                || !$this->usableOption($academic, Catalog::Career, $career, $oldCareer)
                || !$this->usableOption($academic, Catalog::Period, $period, $oldPeriod)) {
                $error = 'Selecciona una carrera o gestión válida de tu institución. Las nuevas asignaciones requieren opciones activas.';
            } elseif ($canTutor && !$eligible && !($record['can_tutor'] ?? false)) {
                $error = 'Para habilitar la tutoría, la cuenta debe estar activa y tener el rol Tutor o evaluador.';
            } else {
                $institution = (int) $actor['institution_id'];
                if ($record === null) {
                    $academic->createParticipant($institution, $kind, $userId, $code, $career, $period, $canTutor);
                } else {
                    $academic->updateParticipant($kind, $userId, $code, $career, $period, $canTutor);
                }
                $action = $record === null ? 'ficha_creada_' : 'ficha_actualizada_';
                $identity->audit($institution, (int) $actor['id'], $action . $kind->value, $userId);
                return $this->saved($kind->path(), 'La ficha académica se guardó.');
            }
        }

        return $this->institutionalView(
            'academic_participant', $kind->label(), $identity, $actor, $this->session,
            [
                'kind' => $kind, 'record' => $record, 'form' => $form, 'error' => $error,
                'accounts' => $record === null ? $academic->availableAccounts($kind) : [],
                'careers' => $academic->options(Catalog::Career, $oldCareer),
                'periods' => $student ? $academic->options(Catalog::Period, $oldPeriod) : [],
            ],
            $error === null ? 200 : 422,
        );
    }

    private function saveCatalog(
        AcademicRepository $academic, IdentityRepository $identity, array $actor,
        Catalog $kind, ?array $record, string $code, string $name, bool $active,
    ): void {
        $institution = (int) $actor['institution_id'];
        $actorId = (int) $actor['id'];
        if ($record === null) {
            $id = $academic->createCatalog($institution, $kind, $code, $name);
            $action = 'creado';
        } else {
            $id = (int) $record['id'];
            $academic->updateCatalog($kind, $id, $code, $name, $active);
            $action = $active === $record['active'] ? 'actualizado' : ($active ? 'activado' : 'desactivado');
            if ($kind === Catalog::Period && !$active && $academic->defaultPeriod() === $id) {
                $academic->setDefaultPeriod($institution, null);
                $identity->audit($institution, $actorId, 'gestion_predeterminada_retirada', $id);
            }
        }
        $identity->audit($institution, $actorId, 'catalogo_' . $kind->value . '_' . $action, $id);
    }

    private function usableOption(AcademicRepository $academic, Catalog $kind, ?int $id, ?int $existing): bool
    {
        if ($id === null || $id === $existing) {
            return true;
        }
        $option = $academic->catalog($kind, $id);
        return $option !== null && $option['active'];
    }

    private function authorized(Request $request, Closure $operation): Response
    {
        return $this->access->handle(
            $request,
            Permission::ManageAcademic,
            static fn (IdentityRepository $identity, array $actor, PDO $database): Response =>
                $operation(new AcademicRepository($database), $identity, $actor),
        );
    }

    private function unavailable(IdentityRepository $identity, array $actor): Response
    {
        $identity->audit((int) $actor['institution_id'], (int) $actor['id'], 'recurso_inaccesible');
        return Response::text('Registro no encontrado.', 404);
    }

    private function saved(string $path, string $message): Response
    {
        $this->session->flash($message);
        return Response::redirect($path);
    }

    private function search(Request $request): string
    {
        $value = trim($request->query('q'));
        return AccountInput::validName($value) ? $value : '';
    }
}
