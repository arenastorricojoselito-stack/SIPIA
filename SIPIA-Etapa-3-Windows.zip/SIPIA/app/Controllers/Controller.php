<?php

declare(strict_types=1);

namespace Sipia\Controllers;

use Sipia\Http\Response;
use Sipia\Repositories\IdentityRepository;
use Sipia\Security\WebSession;
use Throwable;

abstract class Controller
{
    protected function institutionalView(
        string $name,
        string $title,
        IdentityRepository $identity,
        array $actor,
        WebSession $session,
        array $data = [],
        int $status = 200,
    ): Response {
        return $this->view($name, $title, [
            'institution' => $identity->institution(),
            'actor' => $actor,
            'csrf' => $session->csrf(),
            'notice' => $session->notice(),
            ...$data,
        ], $status);
    }

    protected function view(string $name, string $title, array $data = [], int $status = 200): Response
    {
        $content = dirname(__DIR__) . "/Views/{$name}.php";
        ob_start();
        try {
            require dirname(__DIR__) . '/Views/layout.php';
            return new Response((string) ob_get_clean(), $status);
        } catch (Throwable $failure) {
            ob_end_clean();
            throw $failure;
        }
    }
}
