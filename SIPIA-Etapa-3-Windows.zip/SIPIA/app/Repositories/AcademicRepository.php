<?php

declare(strict_types=1);

namespace Sipia\Repositories;

use PDO;
use Sipia\Academic\Catalog;
use Sipia\Academic\Participant;

final readonly class AcademicRepository
{
    public function __construct(private PDO $database)
    {
    }

    public function catalog(Catalog $kind, int $id): ?array
    {
        $query = $this->database->prepare('SELECT id, code, name, active FROM sipia.academic_catalog WHERE kind = ? AND id = ?');
        $query->execute([$kind->value, $id]);
        return $query->fetch() ?: null;
    }

    public function catalogPage(Catalog $kind, string $search, int $offset): array
    {
        $query = $this->database->prepare(
            'SELECT id, code, name, active FROM sipia.academic_catalog
             WHERE kind = ? AND (strpos(lower(name), lower(?)) > 0 OR strpos(lower(code), lower(?)) > 0)
             ORDER BY active DESC, lower(name), id LIMIT 21 OFFSET ?'
        );
        $query->execute([$kind->value, $search, $search, $offset]);
        return $query->fetchAll();
    }

    public function options(Catalog $kind, ?int $includeInactive = null): array
    {
        $query = $this->database->prepare(
            'SELECT id, code, name, active FROM sipia.academic_catalog
             WHERE kind = ? AND (active OR id = ?) ORDER BY lower(name), id'
        );
        $query->execute([$kind->value, $includeInactive]);
        return $query->fetchAll();
    }

    public function catalogCodeUsed(Catalog $kind, string $code, ?int $except): bool
    {
        $query = $this->database->prepare('SELECT id FROM sipia.academic_catalog WHERE kind = ? AND code = ?');
        $query->execute([$kind->value, $code]);
        $id = $query->fetchColumn();
        return $id !== false && (int) $id !== $except;
    }

    public function createCatalog(int $institution, Catalog $kind, string $code, string $name): int
    {
        $query = $this->database->prepare(
            'INSERT INTO sipia.academic_catalog (institution_id, kind, code, name) VALUES (?, ?, ?, ?) RETURNING id'
        );
        $query->execute([$institution, $kind->value, $code, $name]);
        return (int) $query->fetchColumn();
    }

    public function updateCatalog(Catalog $kind, int $id, string $code, string $name, bool $active): void
    {
        $query = $this->database->prepare(
            'UPDATE sipia.academic_catalog SET code = ?, name = ?, active = ? WHERE kind = ? AND id = ?'
        );
        $query->execute([$code, $name, $active ? 'true' : 'false', $kind->value, $id]);
    }

    public function defaultPeriod(): ?int
    {
        $id = $this->database->query('SELECT default_period_id FROM sipia.academic_settings')->fetchColumn();
        return $id === false || $id === null ? null : (int) $id;
    }

    public function setDefaultPeriod(int $institution, ?int $period): void
    {
        $query = $this->database->prepare(
            'INSERT INTO sipia.academic_settings (institution_id, default_period_id) VALUES (?, ?)
             ON CONFLICT (institution_id) DO UPDATE SET default_period_id = EXCLUDED.default_period_id'
        );
        $query->execute([$institution, $period]);
    }

    public function participant(Participant $kind, int $userId): ?array
    {
        $query = $this->database->prepare(
            'SELECT p.*, u.name, u.email, u.active AS account_active
             FROM sipia.academic_participants p
             JOIN sipia.users u ON (u.institution_id, u.id) = (p.institution_id, p.user_id)
             WHERE p.kind = ? AND p.user_id = ?'
        );
        $query->execute([$kind->value, $userId]);
        return $query->fetch() ?: null;
    }

    public function participantPage(Participant $kind, string $search, bool $tutors, int $offset): array
    {
        $query = $this->database->prepare(
            'SELECT p.user_id, p.code, p.can_tutor, u.name, u.email, u.active,
                    career.name AS career, period.name AS period, r.role IS NOT NULL AS has_role
             FROM sipia.academic_participants p
             JOIN sipia.users u ON (u.institution_id, u.id) = (p.institution_id, p.user_id)
             LEFT JOIN sipia.user_roles r ON (r.institution_id, r.user_id, r.role) = (p.institution_id, p.user_id, ?)
             LEFT JOIN sipia.academic_catalog career ON (career.institution_id, career.id) = (p.institution_id, p.career_id)
             LEFT JOIN sipia.academic_catalog period ON (period.institution_id, period.id) = (p.institution_id, p.period_id)
             WHERE p.kind = ? AND (strpos(lower(u.name), lower(?)) > 0 OR strpos(lower(p.code), lower(?)) > 0)
               AND (NOT CAST(? AS boolean) OR (p.can_tutor AND u.active AND r.role IS NOT NULL))
             ORDER BY lower(u.name), p.user_id LIMIT 21 OFFSET ?'
        );
        $query->execute([$kind->role()->value, $kind->value, $search, $search, $tutors ? 'true' : 'false', $offset]);
        return $query->fetchAll();
    }

    public function availableAccounts(Participant $kind): array
    {
        $query = $this->database->prepare(
            'SELECT u.id, u.name, u.email
             FROM sipia.users u
             JOIN sipia.user_roles r ON (r.institution_id, r.user_id) = (u.institution_id, u.id)
             WHERE u.active AND r.role = ? AND NOT EXISTS (
                SELECT 1 FROM sipia.academic_participants p
                WHERE (p.institution_id, p.user_id, p.kind) = (u.institution_id, u.id, ?)
             )
             ORDER BY lower(u.name), u.id'
        );
        $query->execute([$kind->role()->value, $kind->value]);
        return $query->fetchAll();
    }

    public function participantCodeUsed(Participant $kind, string $code, int $except): bool
    {
        $query = $this->database->prepare('SELECT user_id FROM sipia.academic_participants WHERE kind = ? AND code = ?');
        $query->execute([$kind->value, $code]);
        $id = $query->fetchColumn();
        return $id !== false && (int) $id !== $except;
    }

    public function createParticipant(
        int $institution, Participant $kind, int $user, string $code, ?int $career, ?int $period, bool $canTutor,
    ): void {
        $query = $this->database->prepare(
            'INSERT INTO sipia.academic_participants (institution_id, kind, user_id, code, career_id, period_id, can_tutor)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $query->execute([$institution, $kind->value, $user, $code, $career, $period, $canTutor ? 'true' : 'false']);
    }

    public function updateParticipant(
        Participant $kind, int $user, string $code, ?int $career, ?int $period, bool $canTutor,
    ): void {
        $query = $this->database->prepare(
            'UPDATE sipia.academic_participants SET code = ?, career_id = ?, period_id = ?, can_tutor = ?
             WHERE kind = ? AND user_id = ?'
        );
        $query->execute([$code, $career, $period, $canTutor ? 'true' : 'false', $kind->value, $user]);
    }
}
