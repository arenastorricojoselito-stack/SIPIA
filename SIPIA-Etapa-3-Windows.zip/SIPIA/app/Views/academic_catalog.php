<?php
$path = $data['kind']->path();
$form = $data['form'];
$editing = $data['id'] !== null;
$formTitle = $editing ? 'Editar registro' : 'Crear registro';
?>
<h1 class="h2 mb-4"><?= $escape($title) ?></h1>
<div class="row g-4">
    <div class="col-xl-7">
        <form method="get" action="<?= $escape($path) ?>" class="mb-3">
            <label for="q" class="form-label">Buscar por código o nombre</label>
            <div class="input-group">
                <input type="search" class="form-control" id="q" name="q" value="<?= $escape($data['search']) ?>" maxlength="120">
                <button class="btn btn-outline-secondary" type="submit">Buscar</button>
            </div>
        </form>
        <?php if ($data['records'] === []): ?>
            <p class="surface p-4">No hay registros en esta página.</p>
        <?php else: ?>
            <div class="table-responsive surface">
                <table class="table align-middle mb-0">
                    <thead><tr><th scope="col">Código</th><th scope="col">Nombre</th><th scope="col">Estado</th><th scope="col">Acción</th></tr></thead>
                    <tbody>
                    <?php foreach ($data['records'] as $record): ?>
                        <tr>
                            <th scope="row"><?= $escape($record['code']) ?></th>
                            <td><?= $escape($record['name']) ?></td>
                            <td><?= $record['active'] ? 'Activo' : 'Inactivo' ?></td>
                            <td><a href="<?= $escape($path . '?id=' . $record['id']) ?>#formulario" aria-label="Editar <?= $escape($record['name']) ?>">Editar</a></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
        <?php
        $listPath = $path;
        $listQuery = $data['search'] === '' ? [] : ['q' => $data['search']];
        require __DIR__ . '/pagination.php';
        ?>
    </div>
    <div class="col-xl-5">
        <form id="formulario" class="surface p-4" method="post" action="<?= $escape($path . ($editing ? '?id=' . $data['id'] : '')) ?>">
            <input type="hidden" name="csrf" value="<?= $escape($data['csrf']) ?>">
            <h2 class="h5 mb-3"><?= $escape($formTitle) ?></h2>
            <label class="form-label" for="codigo">Código</label>
            <input class="form-control mb-3" id="codigo" name="codigo" value="<?= $escape($form['code']) ?>" maxlength="32" required>
            <label class="form-label" for="nombre">Nombre</label>
            <input class="form-control mb-3" id="nombre" name="nombre" value="<?= $escape($form['name']) ?>" maxlength="120" required>
            <?php if ($editing): ?>
                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" id="activo" name="activo" value="1"<?= $form['active'] ? ' checked' : '' ?>>
                    <label class="form-check-label" for="activo">Activo para nuevas asignaciones</label>
                </div>
            <?php endif; ?>
            <button class="btn btn-sipia" type="submit">Guardar</button>
            <?php if ($editing): ?><a class="btn btn-link" href="<?= $escape($path) ?>">Cancelar</a><?php endif; ?>
        </form>
    </div>
</div>
