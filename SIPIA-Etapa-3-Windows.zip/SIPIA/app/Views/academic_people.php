<?php
$kind = $data['kind'];
$path = $kind->path();
$student = $kind === \Sipia\Academic\Participant::Student;
?>
<div class="d-flex align-items-center justify-content-between gap-2 flex-wrap mb-4">
    <h1 class="h2 mb-0"><?= $escape($title) ?></h1>
    <a class="btn btn-sipia" href="<?= $escape($path) ?>?nuevo=1">Registrar <?= $escape($kind->value) ?></a>
</div>
<form method="get" action="<?= $escape($path) ?>" class="mb-3">
    <label for="q" class="form-label">Buscar por nombre o código</label>
    <div class="input-group">
        <input type="search" class="form-control" id="q" name="q" value="<?= $escape($data['search']) ?>" maxlength="120">
        <button class="btn btn-outline-secondary" type="submit">Buscar</button>
    </div>
    <?php if (!$student): ?>
        <div class="form-check mt-2">
            <input class="form-check-input" type="checkbox" id="tutores" name="tutores" value="1"<?= $data['tutors'] ? ' checked' : '' ?>>
            <label class="form-check-label" for="tutores">Mostrar solo tutores habilitados</label>
        </div>
    <?php endif; ?>
</form>
<?php if ($data['records'] === []): ?>
    <p class="surface p-4">No hay fichas que coincidan con la búsqueda.</p>
<?php else: ?>
    <div class="table-responsive surface">
        <table class="table align-middle mb-0">
            <thead><tr><th scope="col">Nombre</th><th scope="col">Código</th><th scope="col">Carrera</th><th scope="col"><?= $student ? 'Gestión de ingreso' : 'Tutoría' ?></th><th scope="col">Cuenta</th><th scope="col">Acción</th></tr></thead>
            <tbody>
            <?php foreach ($data['records'] as $record): ?>
                <?php $eligible = $record['active'] && $record['has_role']; ?>
                <tr>
                    <th scope="row"><?= $escape($record['name']) ?></th>
                    <td><?= $escape($record['code']) ?></td>
                    <td><?= $escape($record['career'] ?? 'Sin asignar') ?></td>
                    <td>
                        <?= $student ? $escape($record['period']) : ($eligible && $record['can_tutor'] ? 'Habilitada' : 'Sin habilitar') ?>
                    </td>
                    <td><?= $eligible ? 'Activa' : ($record['active'] ? 'Sin el rol requerido' : 'Inactiva') ?></td>
                    <td><a href="<?= $escape($path . '?id=' . $record['user_id']) ?>" aria-label="Editar <?= $escape($record['name']) ?>">Editar</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
<?php
$listPath = $path;
$listQuery = array_filter(['q' => $data['search'], 'tutores' => $data['tutors'] ? '1' : ''], static fn (string $value): bool => $value !== '');
require __DIR__ . '/pagination.php';
?>
