<?php
$kind = $data['kind'];
$path = $kind->path();
$record = $data['record'];
$form = $data['form'];
$editing = $record !== null;
$student = $kind === \Sipia\Academic\Participant::Student;
?>
<h1 class="h2 mb-4"><?= $editing ? 'Editar ficha de' : 'Registrar' ?> <?= $escape($kind->value) ?></h1>
<?php if (!$editing && $data['accounts'] === []): ?>
    <section class="surface p-4">
        <p>Para registrar la ficha, crea o habilita una cuenta con el rol <?= $escape($kind->role()->label()) ?> en Usuarios.</p>
        <a class="btn btn-sipia" href="/usuarios">Ir a Usuarios</a>
        <a class="btn btn-link" href="<?= $escape($path) ?>">Volver</a>
    </section>
<?php else: ?>
    <form class="surface p-4" method="post" action="<?= $escape($path . ($editing ? '?id=' . $record['user_id'] : '?nuevo=1')) ?>">
        <input type="hidden" name="csrf" value="<?= $escape($data['csrf']) ?>">
        <?php if ($editing): ?>
            <p><strong><?= $escape($record['name']) ?></strong> · <?= $escape($record['email']) ?></p>
        <?php else: ?>
            <label class="form-label" for="usuario">Cuenta con rol <?= $escape($kind->role()->label()) ?></label>
            <select class="form-select mb-3" id="usuario" name="usuario" required>
                <option value="">Selecciona una cuenta</option>
                <?php foreach ($data['accounts'] as $account): ?>
                    <option value="<?= $escape($account['id']) ?>"<?= $form['user'] === (int) $account['id'] ? ' selected' : '' ?>><?= $escape($account['name'] . ' · ' . $account['email']) ?></option>
                <?php endforeach; ?>
            </select>
        <?php endif; ?>
        <label class="form-label" for="codigo"><?= $student ? 'Matrícula o código estudiantil' : 'Código de docente' ?></label>
        <input class="form-control mb-3" id="codigo" name="codigo" value="<?= $escape($form['code']) ?>" maxlength="32" required>
        <label class="form-label" for="carrera">Carrera</label>
        <select class="form-select mb-3" id="carrera" name="carrera"<?= $student ? ' required' : '' ?>>
            <option value=""><?= $student ? 'Selecciona una carrera' : 'Sin asignar' ?></option>
            <?php foreach ($data['careers'] as $career): ?>
                <option value="<?= $escape($career['id']) ?>"<?= $form['career'] === (int) $career['id'] ? ' selected' : '' ?>><?= $escape($career['name'] . ($career['active'] ? '' : ' (inactiva)')) ?></option>
            <?php endforeach; ?>
        </select>
        <?php if ($student): ?>
            <label class="form-label" for="gestion">Gestión de ingreso</label>
            <select class="form-select mb-3" id="gestion" name="gestion" required>
                <option value="">Selecciona una gestión</option>
                <?php foreach ($data['periods'] as $period): ?>
                    <option value="<?= $escape($period['id']) ?>"<?= $form['period'] === (int) $period['id'] ? ' selected' : '' ?>><?= $escape($period['name'] . ($period['active'] ? '' : ' (inactiva)')) ?></option>
                <?php endforeach; ?>
            </select>
        <?php else: ?>
            <div class="form-check mb-3">
                <input class="form-check-input" type="checkbox" id="tutor" name="tutor" value="1"<?= $form['tutor'] ? ' checked' : '' ?>>
                <label class="form-check-label" for="tutor">Habilitar como tutor</label>
            </div>
        <?php endif; ?>
        <?php if ($student && ($data['careers'] === [] || $data['periods'] === [])): ?>
            <p class="note">Registra al menos una <a href="/academico/carreras">carrera</a> y una <a href="/academico/gestiones">gestión</a> activa para guardar la ficha.</p>
        <?php else: ?>
            <button class="btn btn-sipia" type="submit">Guardar ficha</button>
        <?php endif; ?>
        <a class="btn btn-link" href="<?= $escape($path) ?>">Volver</a>
    </form>
<?php endif; ?>
