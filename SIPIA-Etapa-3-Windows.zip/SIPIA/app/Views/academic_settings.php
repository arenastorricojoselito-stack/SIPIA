<h1 class="h2 mb-4">Configuración académica</h1>
<form class="surface p-4" method="post" action="/academico/configuracion">
    <input type="hidden" name="csrf" value="<?= $escape($data['csrf']) ?>">
    <label class="form-label" for="gestion">Gestión de ingreso predeterminada</label>
    <select class="form-select" id="gestion" name="gestion" aria-describedby="gestion-ayuda">
        <option value="">Sin gestión predeterminada</option>
        <?php foreach ($data['periods'] as $period): ?>
            <option value="<?= $escape($period['id']) ?>"<?= $data['default'] === (int) $period['id'] ? ' selected' : '' ?>><?= $escape($period['name']) ?></option>
        <?php endforeach; ?>
    </select>
    <p class="form-text mb-3" id="gestion-ayuda">Se seleccionará al abrir una nueva ficha de estudiante.</p>
    <button class="btn btn-sipia" type="submit">Guardar configuración</button>
</form>
