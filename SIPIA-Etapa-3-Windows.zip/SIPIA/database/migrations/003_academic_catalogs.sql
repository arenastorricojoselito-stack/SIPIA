CREATE TABLE sipia.academic_catalog (
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    institution_id bigint NOT NULL REFERENCES sipia.institutions (id),
    kind text NOT NULL CHECK (kind IN ('carrera', 'gestion', 'modalidad')),
    code varchar(32) NOT NULL CHECK (code ~ '^[A-Z0-9][A-Z0-9._/-]{0,31}$'),
    name varchar(120) NOT NULL CHECK (length(btrim(name)) > 0),
    active boolean NOT NULL DEFAULT true,
    UNIQUE (institution_id, kind, id),
    UNIQUE (institution_id, kind, code)
);

CREATE TABLE sipia.academic_participants (
    institution_id bigint NOT NULL,
    kind text NOT NULL CHECK (kind IN ('estudiante', 'docente')),
    user_id bigint NOT NULL,
    code varchar(32) NOT NULL CHECK (code ~ '^[A-Z0-9][A-Z0-9._/-]{0,31}$'),
    career_id bigint,
    period_id bigint,
    can_tutor boolean NOT NULL DEFAULT false,
    career_kind text GENERATED ALWAYS AS ('carrera'::text) STORED,
    period_kind text GENERATED ALWAYS AS ('gestion'::text) STORED,
    PRIMARY KEY (institution_id, kind, user_id),
    UNIQUE (institution_id, kind, code),
    FOREIGN KEY (institution_id, user_id) REFERENCES sipia.users (institution_id, id),
    FOREIGN KEY (institution_id, career_kind, career_id)
        REFERENCES sipia.academic_catalog (institution_id, kind, id),
    FOREIGN KEY (institution_id, period_kind, period_id)
        REFERENCES sipia.academic_catalog (institution_id, kind, id),
    CHECK (
        (kind = 'estudiante' AND career_id IS NOT NULL AND period_id IS NOT NULL AND NOT can_tutor)
        OR (kind = 'docente' AND period_id IS NULL)
    )
);

CREATE TABLE sipia.academic_settings (
    institution_id bigint PRIMARY KEY REFERENCES sipia.institutions (id),
    default_period_id bigint,
    period_kind text GENERATED ALWAYS AS ('gestion'::text) STORED,
    FOREIGN KEY (institution_id, period_kind, default_period_id)
        REFERENCES sipia.academic_catalog (institution_id, kind, id)
);

DO $$
DECLARE
    table_name text;
BEGIN
    FOREACH table_name IN ARRAY ARRAY['academic_catalog', 'academic_participants', 'academic_settings']
    LOOP
        EXECUTE format('ALTER TABLE sipia.%I ENABLE ROW LEVEL SECURITY', table_name);
        EXECUTE format('ALTER TABLE sipia.%I FORCE ROW LEVEL SECURITY', table_name);
        EXECUTE format(
            'CREATE POLICY institution_scope ON sipia.%I TO sipia_app
             USING (institution_id = NULLIF(current_setting(''sipia.institution_id'', true), '''')::bigint)
             WITH CHECK (institution_id = NULLIF(current_setting(''sipia.institution_id'', true), '''')::bigint)',
            table_name
        );
    END LOOP;
END
$$;

GRANT SELECT, INSERT ON sipia.academic_catalog, sipia.academic_participants, sipia.academic_settings TO sipia_app;
GRANT UPDATE (code, name, active) ON sipia.academic_catalog TO sipia_app;
GRANT UPDATE (code, career_id, period_id, can_tutor) ON sipia.academic_participants TO sipia_app;
GRANT UPDATE (default_period_id) ON sipia.academic_settings TO sipia_app;
