<?php

declare(strict_types=1);

require dirname(__DIR__) . '/vendor/autoload.php';

use Sipia\Controllers\AdministrationController;
use Sipia\Controllers\AuthenticationController;
use Sipia\Controllers\HomeController;
use Sipia\Controllers\ReadinessController;
use Sipia\Http\Kernel;
use Sipia\Http\Router;
use Sipia\Middleware\SecurityHeaders;
use Sipia\Persistence\Connection;
use Sipia\Repositories\ReadinessRepository;
use Sipia\Security\InstitutionAccess;
use Sipia\Security\WebSession;
use Sipia\Services\Login;
use Sipia\Services\Readiness;
use Sipia\Support\Environment;
use Sipia\Support\Logger;

$logger = new Logger();
$router = new Router();
$connection = new Connection(new Environment());
$session = new WebSession(in_array(strtolower($_SERVER['HTTPS'] ?? ''), ['on', '1'], true));
$access = new InstitutionAccess($connection, $session);
$readiness = new Readiness(new ReadinessRepository($connection), $logger);
$register = require dirname(__DIR__) . '/config/routes.php';
$register(
    $router,
    new HomeController(),
    new ReadinessController($readiness),
    new AuthenticationController(new Login($connection), $access, $session),
    new AdministrationController($access, $session),
);

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
(new Kernel($router, new SecurityHeaders(), $logger))
    ->handle($method, $_SERVER['REQUEST_URI'] ?? '/', $_GET, $_POST, $_SERVER['REMOTE_ADDR'] ?? '')
    ->send($method !== 'HEAD');
