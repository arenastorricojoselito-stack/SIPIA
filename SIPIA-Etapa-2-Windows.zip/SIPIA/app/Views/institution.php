<h1 class="h2 mb-4">Institución</h1>
<form class="surface p-4" method="post" action="/institucion">
    <input type="hidden" name="csrf" value="<?= $escape($data['csrf']) ?>">
    <p>Código de acceso <strong><?= $escape($data['institution']['code']) ?></strong></p>
    <label class="form-label" for="nombre">Nombre de la institución</label>
    <input class="form-control mb-3" id="nombre" name="nombre" value="<?= $escape($data['entered'] ?? $data['institution']['name']) ?>" maxlength="120" required>
    <button class="btn btn-sipia" type="submit">Guardar cambios</button>
</form>
