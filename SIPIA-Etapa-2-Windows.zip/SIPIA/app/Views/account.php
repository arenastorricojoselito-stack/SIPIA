<h1 class="h2 mb-4">Mi cuenta</h1>
<form class="surface p-4" method="post" action="/cuenta">
    <input type="hidden" name="csrf" value="<?= $escape($data['csrf']) ?>">
    <h2 class="h5">Cambiar contraseña</h2>
    <p class="note"><?= $escape($data['actor']['email']) ?></p>
    <label class="form-label" for="actual">Contraseña actual</label>
    <input class="form-control mb-3" type="password" id="actual" name="actual" autocomplete="current-password" required>
    <label class="form-label" for="clave">Nueva contraseña</label>
    <input class="form-control" type="password" id="clave" name="clave" minlength="12" autocomplete="new-password" aria-describedby="clave-nota" required>
    <p class="form-text mb-3" id="clave-nota">Usa al menos 12 caracteres y un máximo de 72 bytes.</p>
    <label class="form-label" for="confirmacion">Confirmar nueva contraseña</label>
    <input class="form-control mb-3" type="password" id="confirmacion" name="confirmacion" minlength="12" autocomplete="new-password" required>
    <button class="btn btn-sipia" type="submit">Cambiar contraseña</button>
</form>
