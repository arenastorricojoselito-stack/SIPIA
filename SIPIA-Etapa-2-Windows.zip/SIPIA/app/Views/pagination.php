<?php if ($data['page'] > 1 || $data['more']): ?>
    <nav class="d-flex align-items-center gap-3 mt-3" aria-label="Paginación">
        <?php if ($data['page'] > 1): ?>
            <a href="<?= $escape($listPath . '?' . http_build_query([...$listQuery, 'pagina' => $data['page'] - 1])) ?>">Anterior</a>
        <?php endif; ?>
        <span>Página <?= $escape($data['page']) ?></span>
        <?php if ($data['more']): ?>
            <a href="<?= $escape($listPath . '?' . http_build_query([...$listQuery, 'pagina' => $data['page'] + 1])) ?>">Siguiente</a>
        <?php endif; ?>
    </nav>
<?php endif; ?>
