<?php
$labels = \Sipia\Security\Role::labels();
$editing = $data['editing'];
$target = $editing ? '/usuarios/editar?id=' . $data['id'] : '/usuarios/nuevo';
?>
<h1 class="h2 mb-4"><?= $editing ? 'Editar usuario' : 'Crear usuario' ?></h1>
<form class="surface p-4" method="post" action="<?= $escape($target) ?>">
    <input type="hidden" name="csrf" value="<?= $escape($data['csrf']) ?>">
    <label class="form-label" for="nombre">Nombre</label>
    <input class="form-control mb-3" id="nombre" name="nombre" value="<?= $escape($data['name']) ?>" maxlength="120" required>
    <label class="form-label" for="correo">Correo electrónico</label>
    <input class="form-control mb-3" type="email" id="correo" name="correo" value="<?= $escape($data['email']) ?>" maxlength="254" required>
    <?php if (!$editing): ?>
        <label class="form-label" for="clave">Contraseña inicial</label>
        <input class="form-control" type="password" id="clave" name="clave" autocomplete="new-password" minlength="12" aria-describedby="clave-nota" required>
        <p class="form-text mb-3" id="clave-nota">Usa al menos 12 caracteres y un máximo de 72 bytes.</p>
    <?php endif; ?>
    <fieldset class="mb-3">
        <legend class="h6">Roles</legend>
        <?php foreach ($labels as $role => $label): ?>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="rol-<?= $escape($role) ?>" name="roles[]" value="<?= $escape($role) ?>"<?= in_array($role, $data['roles'], true) ? ' checked' : '' ?>>
                <label class="form-check-label" for="rol-<?= $escape($role) ?>"><?= $escape($label) ?></label>
            </div>
        <?php endforeach; ?>
    </fieldset>
    <?php if ($editing): ?>
        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" id="activo" name="activo" value="1"<?= $data['active'] ? ' checked' : '' ?>>
            <label class="form-check-label" for="activo">Cuenta activa</label>
        </div>
    <?php endif; ?>
    <button class="btn btn-sipia" type="submit"><?= $editing ? 'Guardar cambios' : 'Crear usuario' ?></button>
    <a class="btn btn-link" href="/usuarios">Volver a usuarios</a>
</form>
