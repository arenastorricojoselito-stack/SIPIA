<?php $roleLabels = \Sipia\Security\Role::labels(); ?>
<h1 class="h2">Panel institucional</h1>
<p class="note mb-4"><?= $escape($data['actor']['name']) ?> · <?= $escape(implode(', ', array_intersect_key($roleLabels, array_flip($data['actor']['roles'])))) ?></p>
<?php if ($data['total'] !== null): ?>
    <div class="row g-3">
        <div class="col-sm-6">
            <section class="surface p-4 h-100">
                <h2 class="h6">Usuarios registrados</h2>
                <p class="metric mb-2"><?= $escape($data['total']['total']) ?></p>
                <a href="/usuarios">Gestionar usuarios</a>
            </section>
        </div>
        <div class="col-sm-6">
            <section class="surface p-4 h-100">
                <h2 class="h6">Usuarios activos</h2>
                <p class="metric mb-0"><?= $escape($data['total']['active']) ?></p>
            </section>
        </div>
    </div>
<?php endif; ?>
