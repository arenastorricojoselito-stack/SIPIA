<section class="surface p-4 p-md-5">
    <h1 class="h3 mb-4">Iniciar sesión</h1>
    <form method="post" action="/iniciar">
        <input type="hidden" name="csrf" value="<?= $escape($data['csrf']) ?>">
        <label class="form-label" for="codigo">Código de institución</label>
        <input class="form-control mb-3" id="codigo" name="codigo" maxlength="48" value="<?= $escape($data['code'] ?? '') ?>" autocapitalize="none" required>
        <label class="form-label" for="correo">Correo electrónico</label>
        <input class="form-control mb-3" type="email" id="correo" name="correo" maxlength="254" value="<?= $escape($data['email'] ?? '') ?>" autocomplete="username" required>
        <label class="form-label" for="clave">Contraseña</label>
        <input class="form-control mb-4" type="password" id="clave" name="clave" autocomplete="current-password" required>
        <button class="btn btn-sipia w-100" type="submit">Entrar</button>
    </form>
</section>
