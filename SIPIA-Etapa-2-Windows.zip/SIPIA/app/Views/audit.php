<?php
$actions = [
    'institucion_habilitada' => 'Institución habilitada',
    'institucion_actualizada' => 'Institución actualizada',
    'sesion_iniciada' => 'Sesión iniciada',
    'sesion_cerrada' => 'Sesión cerrada',
    'acceso_fallido' => 'Acceso fallido',
    'acceso_limitado' => 'Límite de intentos aplicado',
    'permiso_denegado' => 'Permiso denegado',
    'csrf_denegado' => 'Solicitud sin token válido',
    'recurso_inaccesible' => 'Recurso inaccesible',
    'usuario_creado' => 'Usuario creado',
    'usuario_actualizado' => 'Usuario actualizado',
    'usuario_activado' => 'Usuario activado',
    'usuario_desactivado' => 'Usuario desactivado',
    'roles_actualizados' => 'Roles actualizados',
    'clave_actualizada' => 'Contraseña actualizada',
    'cambio_clave_denegado' => 'Cambio de contraseña denegado',
];
?>
<h1 class="h2 mb-4">Auditoría</h1>
<?php if ($data['events'] === []): ?>
    <p class="surface p-4">No hay eventos en esta página.</p>
<?php else: ?>
    <div class="table-responsive surface">
        <table class="table align-middle mb-0">
            <thead><tr><th scope="col">Fecha y hora</th><th scope="col">Evento</th><th scope="col">Usuario</th><th scope="col">Recurso</th></tr></thead>
            <tbody>
            <?php foreach ($data['events'] as $event): ?>
                <tr>
                    <td><?= $escape($event['occurred_at']) ?></td>
                    <th scope="row"><?= $escape($actions[$event['action']] ?? $event['action']) ?></th>
                    <td><?= $escape($event['actor'] ?? 'Sin autenticar') ?></td>
                    <td><?= $escape($event['resource_id'] ?? '—') ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
<?php
$listPath = '/auditoria';
$listQuery = [];
require __DIR__ . '/pagination.php';
?>
