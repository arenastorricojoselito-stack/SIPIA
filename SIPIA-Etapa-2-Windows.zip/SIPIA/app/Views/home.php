<section class="surface p-4 p-md-5">
    <h1 class="h2">SIPIA</h1>
    <p class="lead mb-4">Sistema Inteligente de Proyectos e Innovación Académica</p>
    <a class="btn btn-sipia" href="/iniciar">Iniciar sesión</a>
</section>
