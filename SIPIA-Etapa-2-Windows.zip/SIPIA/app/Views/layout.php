<?php

use Sipia\Security\Permission;

$escape = static fn (mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
?><!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $escape($title) ?> · SIPIA</title>
    <link rel="stylesheet" href="/assets/bootstrap.min.css">
    <link rel="stylesheet" href="/assets/sipia.css">
</head>
<body>
    <a class="visually-hidden-focusable" href="#contenido">Ir al contenido</a>
    <header class="masthead px-3 px-md-4 py-3 d-flex align-items-center justify-content-between gap-3">
        <a class="brand h5 text-decoration-none mb-0" href="<?= isset($data['actor']) ? '/panel' : '/' ?>">SIPIA</a>
        <?php if (isset($data['actor'])): ?>
            <div class="d-flex align-items-center gap-3">
                <span class="small"><?= $escape($data['institution']['name']) ?></span>
                <form method="post" action="/salir">
                    <input type="hidden" name="csrf" value="<?= $escape($data['csrf']) ?>">
                    <button class="btn btn-outline-light btn-sm text-nowrap" type="submit">Cerrar sesión</button>
                </form>
            </div>
        <?php endif; ?>
    </header>
    <?php if (isset($data['actor'])): ?>
        <div class="workspace">
            <aside class="sidebar">
                <details open>
                    <summary>Menú</summary>
                    <nav aria-label="Navegación principal">
                        <a href="/panel"<?= $title === 'Panel' ? ' aria-current="page"' : '' ?>>Panel</a>
                        <?php if (Permission::ManageInstitution->allowedFor($data['actor']['roles'])): ?>
                            <a href="/institucion"<?= $title === 'Institución' ? ' aria-current="page"' : '' ?>>Institución</a>
                        <?php endif; ?>
                        <?php if (Permission::ManageUsers->allowedFor($data['actor']['roles'])): ?>
                            <a href="/usuarios"<?= str_contains($title, 'Usuario') ? ' aria-current="page"' : '' ?>>Usuarios</a>
                        <?php endif; ?>
                        <?php if (Permission::ReadAudit->allowedFor($data['actor']['roles'])): ?>
                            <a href="/auditoria"<?= $title === 'Auditoría' ? ' aria-current="page"' : '' ?>>Auditoría</a>
                        <?php endif; ?>
                        <a href="/cuenta"<?= $title === 'Mi cuenta' ? ' aria-current="page"' : '' ?>>Mi cuenta</a>
                    </nav>
                </details>
            </aside>
    <?php endif; ?>
    <main id="contenido" class="<?= isset($data['actor']) ? 'content' : 'container signin my-5' ?>">
        <?php if (!empty($data['notice'])): ?><p class="alert alert-success" role="status"><?= $escape($data['notice']) ?></p><?php endif; ?>
        <?php if (!empty($data['error'])): ?><p class="alert alert-danger" role="alert"><?= $escape($data['error']) ?></p><?php endif; ?>
        <?php require $content; ?>
    </main>
    <?php if (isset($data['actor'])): ?></div><?php endif; ?>
</body>
</html>
