<?php $labels = \Sipia\Security\Role::labels(); ?>
<div class="d-flex align-items-center justify-content-between gap-2 flex-wrap mb-4">
    <h1 class="h2 mb-0">Usuarios</h1>
    <a class="btn btn-sipia" href="/usuarios/nuevo">Crear usuario</a>
</div>
<form method="get" action="/usuarios" class="mb-3">
    <label for="q" class="form-label">Buscar por nombre o correo</label>
    <div class="input-group">
        <input type="search" class="form-control" id="q" name="q" value="<?= $escape($data['search']) ?>" maxlength="120">
        <button class="btn btn-outline-secondary" type="submit">Buscar</button>
    </div>
</form>
<?php if ($data['users'] === []): ?>
    <p class="surface p-4">No hay usuarios en esta página.</p>
<?php else: ?>
    <div class="table-responsive surface">
        <table class="table align-middle mb-0">
            <thead><tr><th scope="col">Nombre</th><th scope="col">Correo</th><th scope="col">Roles</th><th scope="col">Estado</th><th scope="col">Acción</th></tr></thead>
            <tbody>
            <?php foreach ($data['users'] as $user): ?>
                <tr>
                    <th scope="row"><?= $escape($user['name']) ?></th>
                    <td><?= $escape($user['email']) ?></td>
                    <td><?= $escape(implode(', ', array_intersect_key($labels, array_flip(explode(',', $user['roles'] ?? ''))))) ?></td>
                    <td><?= $user['active'] ? 'Activo' : 'Inactivo' ?></td>
                    <td>
                        <?php if ((int) $user['id'] === (int) $data['actor']['id']): ?>
                            <a href="/cuenta">Mi cuenta</a>
                        <?php else: ?>
                            <a href="/usuarios/editar?id=<?= $escape($user['id']) ?>" aria-label="Editar <?= $escape($user['name']) ?>">Editar</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
<?php
$listPath = '/usuarios';
$listQuery = $data['search'] === '' ? [] : ['q' => $data['search']];
require __DIR__ . '/pagination.php';
?>
