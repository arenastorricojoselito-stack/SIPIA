<?php

declare(strict_types=1);

namespace Sipia\Repositories;

use PDO;

final readonly class IdentityRepository
{
    public function __construct(private PDO $database)
    {
    }

    public function findInstitution(string $code): ?int
    {
        $query = $this->database->prepare('SELECT sipia.find_login_institution(?)');
        $query->execute([$code]);
        $id = $query->fetchColumn();
        return $id === null || $id === false ? null : (int) $id;
    }

    public function institution(): array
    {
        return $this->database->query('SELECT id, name, code FROM sipia.institutions')->fetch();
    }

    public function user(int $id): ?array
    {
        $query = $this->database->prepare(
            'SELECT id, institution_id, name, email, active, session_version FROM sipia.users WHERE id = ?'
        );
        $query->execute([$id]);
        return $query->fetch() ?: null;
    }

    public function credentials(string $email): ?array
    {
        $query = $this->database->prepare(
            'SELECT id, institution_id, active, session_version, password_hash FROM sipia.users WHERE email = ?'
        );
        $query->execute([$email]);
        return $query->fetch() ?: null;
    }

    public function roles(int $id): array
    {
        $query = $this->database->prepare('SELECT role FROM sipia.user_roles WHERE user_id = ? ORDER BY role');
        $query->execute([$id]);
        return $query->fetchAll(PDO::FETCH_COLUMN);
    }

    public function listUsers(string $search, int $offset): array
    {
        $query = $this->database->prepare(
            "SELECT u.id, u.name, u.email, u.active, string_agg(r.role, ',' ORDER BY r.role) AS roles
             FROM sipia.users u LEFT JOIN sipia.user_roles r ON r.user_id = u.id AND r.institution_id = u.institution_id
             WHERE strpos(lower(u.name), lower(?)) > 0 OR strpos(u.email, lower(?)) > 0
             GROUP BY u.id ORDER BY lower(u.name), u.id LIMIT 21 OFFSET ?"
        );
        $query->execute([$search, $search, $offset]);
        return $query->fetchAll();
    }

    public function totals(): array
    {
        return $this->database->query(
            'SELECT count(*) AS total, count(*) FILTER (WHERE active) AS active FROM sipia.users'
        )->fetch();
    }

    public function renameInstitution(string $name): void
    {
        $query = $this->database->prepare('UPDATE sipia.institutions SET name = ?');
        $query->execute([$name]);
    }

    public function lockInstitution(int $institution): void
    {
        $query = $this->database->prepare('SELECT pg_advisory_xact_lock(CAST(? AS bigint) * -1)');
        $query->execute([$institution]);
    }

    public function createUser(int $institution, string $name, string $email, string $hash): int
    {
        $query = $this->database->prepare(
            'INSERT INTO sipia.users (institution_id, name, email, password_hash) VALUES (?, ?, ?, ?) RETURNING id'
        );
        $query->execute([$institution, $name, $email, $hash]);
        return (int) $query->fetchColumn();
    }

    public function updateUser(int $id, string $name, string $email, bool $active, bool $revoke): void
    {
        $query = $this->database->prepare(
            'UPDATE sipia.users SET name = ?, email = ?, active = ?, session_version = session_version + ?
             WHERE id = ?'
        );
        $query->execute([$name, $email, $active ? 'true' : 'false', $revoke ? 1 : 0, $id]);
    }

    public function changePassword(int $id, string $hash): void
    {
        $query = $this->database->prepare(
            'UPDATE sipia.users SET password_hash = ?, session_version = session_version + 1 WHERE id = ?'
        );
        $query->execute([$hash, $id]);
    }

    public function setRoles(int $institution, int $id, array $roles): void
    {
        $delete = $this->database->prepare('DELETE FROM sipia.user_roles WHERE institution_id = ? AND user_id = ?');
        $delete->execute([$institution, $id]);
        $insert = $this->database->prepare('INSERT INTO sipia.user_roles VALUES (?, ?, ?)');
        foreach ($roles as $role) {
            $insert->execute([$institution, $id, $role]);
        }
    }

    public function audit(int $institution, ?int $actor, string $action, ?int $resource = null): void
    {
        $query = $this->database->prepare(
            'INSERT INTO sipia.audit_events (institution_id, actor_id, action, resource_id) VALUES (?, ?, ?, ?)'
        );
        $query->execute([$institution, $actor, $action, $resource]);
    }

    public function auditEvents(int $offset): array
    {
        $query = $this->database->prepare(
            'SELECT e.action, e.resource_id, e.occurred_at, u.name AS actor
             FROM sipia.audit_events e LEFT JOIN sipia.users u ON u.id = e.actor_id AND u.institution_id = e.institution_id
             ORDER BY e.id DESC LIMIT 21 OFFSET ?'
        );
        $query->execute([$offset]);
        return $query->fetchAll();
    }

    public function consumeLoginAttempt(string $key, int $max): bool
    {
        $query = $this->database->prepare(
            "INSERT INTO sipia.login_limits AS entry VALUES (?, now() + interval '15 minutes', 1)
             ON CONFLICT (client_key) DO UPDATE SET
                attempts = CASE WHEN entry.expires_at <= now() THEN 1 ELSE LEAST(entry.attempts + 1, 100) END,
                expires_at = CASE WHEN entry.expires_at <= now() THEN EXCLUDED.expires_at ELSE entry.expires_at END
             RETURNING attempts"
        );
        $query->execute([$key]);
        return (int) $query->fetchColumn() <= $max;
    }

    public function resetLoginAttempts(string $key): void
    {
        $query = $this->database->prepare('DELETE FROM sipia.login_limits WHERE client_key = ?');
        $query->execute([$key]);
    }

    public function expireLoginAttempts(): void
    {
        $this->database->exec('DELETE FROM sipia.login_limits WHERE expires_at < now()');
    }
}
