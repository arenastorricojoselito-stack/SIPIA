<?php

declare(strict_types=1);

namespace Sipia\Http;

final readonly class Response
{
    public function __construct(
        public string $body,
        public int $status = 200,
        public array $headers = ['Content-Type' => 'text/html; charset=utf-8'],
    ) {
    }

    public static function text(string $body, int $status, array $headers = []): self
    {
        return new self($body, $status, ['Content-Type' => 'text/plain; charset=utf-8', ...$headers]);
    }

    public static function redirect(string $path): self
    {
        return new self('', 303, ['Location' => $path, 'Content-Type' => 'text/plain; charset=utf-8']);
    }

    public function send(bool $includeBody): void
    {
        http_response_code($this->status);
        foreach ($this->headers as $name => $value) {
            header("{$name}: {$value}");
        }
        if ($includeBody) {
            echo $this->body;
        }
    }
}
