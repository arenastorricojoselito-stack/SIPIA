<?php

declare(strict_types=1);

namespace Sipia\Http;

use LogicException;

final class Router
{
    private array $routes = [];

    public function get(string $path, callable $handler): void
    {
        $this->register('GET', $path, $handler);
    }

    public function post(string $path, callable $handler): void
    {
        $this->register('POST', $path, $handler);
    }

    private function register(string $method, string $path, callable $handler): void
    {
        if (isset($this->routes[$path][$method])) {
            throw new LogicException('Ruta duplicada.');
        }

        $this->routes[$path][$method] = $handler;
    }

    public function dispatch(Request $request): Response
    {
        $methods = $this->routes[$request->path] ?? null;
        if ($methods === null) {
            return Response::text('Página no encontrada.', 404);
        }
        $method = $request->method === 'HEAD' ? 'GET' : $request->method;
        if (!isset($methods[$method])) {
            $allowed = isset($methods['GET']) ? ['GET', 'HEAD'] : [];
            if (isset($methods['POST'])) {
                $allowed[] = 'POST';
            }
            return Response::text('Método no permitido.', 405, ['Allow' => implode(', ', $allowed)]);
        }

        return $methods[$method]($request);
    }
}
