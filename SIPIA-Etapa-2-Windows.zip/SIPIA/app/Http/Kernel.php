<?php

declare(strict_types=1);

namespace Sipia\Http;

use InvalidArgumentException;
use Sipia\Middleware\SecurityHeaders;
use Sipia\Support\Logger;
use Throwable;

final readonly class Kernel
{
    public function __construct(
        private Router $router,
        private SecurityHeaders $security,
        private Logger $logger,
    ) {
    }

    public function handle(
        string $method,
        string $target,
        array $query = [],
        array $form = [],
        string $remoteAddress = '',
    ): Response {
        try {
            $request = Request::fromTarget($method, $target, $query, $form, $remoteAddress);
        } catch (InvalidArgumentException) {
            return $this->security->apply(Response::text('Solicitud inválida.', 400));
        }

        try {
            $response = $this->router->dispatch($request);
        } catch (Throwable $failure) {
            $this->logger->failure('http.failure', $failure);
            $response = Response::text('Error interno del servidor.', 500);
        }

        return $this->security->apply($response);
    }
}
