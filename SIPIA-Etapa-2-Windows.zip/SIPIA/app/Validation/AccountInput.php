<?php

declare(strict_types=1);

namespace Sipia\Validation;

final class AccountInput
{
    public static function validName(string $name): bool
    {
        return preg_match('/\A[^\x00-\x1f\x7f]{1,120}\z/u', $name) === 1;
    }

    public static function validEmail(string $email): bool
    {
        return strlen($email) <= 254 && filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    public static function validInstitution(string $code): bool
    {
        return preg_match('/\A[a-z0-9][a-z0-9-]{1,47}\z/', $code) === 1;
    }

    public static function validPassword(string $password): bool
    {
        return strlen($password) <= 72 && preg_match('/\A[^\x00]{12,}\z/u', $password) === 1;
    }
}
