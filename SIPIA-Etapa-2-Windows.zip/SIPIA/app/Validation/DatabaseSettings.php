<?php

declare(strict_types=1);

namespace Sipia\Validation;

use InvalidArgumentException;

final class DatabaseSettings
{
    public static function port(string|false $value): int
    {
        if ($value === false) {
            return 5432;
        }

        $port = filter_var($value, FILTER_VALIDATE_INT, ['options' => [
            'min_range' => 1, 'max_range' => 65535,
        ]]);
        if ($port === false) {
            throw new InvalidArgumentException('Puerto de conexión inválido.');
        }

        return $port;
    }

    public static function identifier(string $value): string
    {
        if (preg_match('/\A[a-zA-Z0-9_.-]+\z/', $value) !== 1) {
            throw new InvalidArgumentException('Identificador de conexión inválido.');
        }

        return $value;
    }
}
