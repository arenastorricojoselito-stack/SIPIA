<?php

declare(strict_types=1);

namespace Sipia\Services;

use Sipia\Persistence\Connection;
use Sipia\Persistence\InstitutionScope;
use Sipia\Repositories\IdentityRepository;
use Sipia\Validation\AccountInput;

final readonly class Login
{
    private const DUMMY_HASH = '$2y$12$9Fpp9N917NFz7OV.l0ux6eKr4NF4zDiMYIsvVqmxvuh2FRhdu6ahm';

    public function __construct(private Connection $connection)
    {
    }

    public function attempt(string $institution, string $email, string $password, string $remoteAddress): ?array
    {
        $database = $this->connection->open();
        $repository = new IdentityRepository($database);
        $institutionId = AccountInput::validInstitution($institution) ? $repository->findInstitution($institution) : null;
        $accountKey = hash('sha256', "account\0{$institution}\0{$email}");
        if (random_int(1, 64) === 1) {
            $repository->expireLoginAttempts();
        }

        $addressKey = hash('sha256', "address\0{$remoteAddress}");
        if (!$repository->consumeLoginAttempt($addressKey, 30) || !$repository->consumeLoginAttempt($accountKey, 5)) {
            if ($institutionId !== null) {
                (new InstitutionScope($database))->write($institutionId, static function () use ($repository, $institutionId): void {
                    $repository->audit($institutionId, null, 'acceso_limitado');
                });
            }
            return null;
        }

        if ($institutionId === null) {
            password_verify('Acceso no válido', self::DUMMY_HASH);
            return null;
        }

        return (new InstitutionScope($database))->write($institutionId, static function () use (
            $repository, $institutionId, $email, $password, $accountKey,
        ): ?array {
            $user = AccountInput::validEmail($email) ? $repository->credentials($email) : null;
            $usablePassword = AccountInput::validPassword($password);
            $valid = password_verify($usablePassword ? $password : 'Acceso no válido', $user['password_hash'] ?? self::DUMMY_HASH);
            if (!$valid || !$usablePassword || !$user || !$user['active']) {
                $repository->audit($institutionId, null, 'acceso_fallido');
                return null;
            }

            $repository->resetLoginAttempts($accountKey);
            $repository->audit($institutionId, (int) $user['id'], 'sesion_iniciada');
            unset($user['password_hash']);
            return $user;
        });
    }
}
