<?php

declare(strict_types=1);

namespace Sipia\Controllers;

use Sipia\Http\Request;
use Sipia\Http\Response;
use Sipia\Repositories\IdentityRepository;
use Sipia\Security\InstitutionAccess;
use Sipia\Security\WebSession;
use Sipia\Services\Login;

final class AuthenticationController extends Controller
{
    public function __construct(
        private readonly Login $login,
        private readonly InstitutionAccess $access,
        private readonly WebSession $session,
    ) {
    }

    public function form(): Response
    {
        if ($this->session->identity() !== null) {
            return Response::redirect('/panel');
        }
        return $this->view('login', 'Iniciar sesión', ['csrf' => $this->session->csrf(), 'notice' => $this->session->notice()]);
    }

    public function authenticate(Request $request): Response
    {
        if (!$this->session->verifyCsrf($request->field('csrf'))) {
            return Response::text('La solicitud caducó. Vuelve a abrir el formulario.', 403);
        }

        $code = strtolower(trim($request->field('codigo')));
        $email = strtolower(trim($request->field('correo')));
        $user = $this->login->attempt($code, $email, $request->field('clave'), $request->remoteAddress);
        if ($user === null) {
            return $this->view('login', 'Iniciar sesión', [
                'csrf' => $this->session->csrf(),
                'code' => substr($code, 0, 48),
                'email' => substr($email, 0, 254),
                'error' => 'No se pudo iniciar sesión. Revisa los datos o espera unos minutos antes de reintentar.',
            ], 401);
        }

        $this->session->signIn($user);
        return Response::redirect('/panel');
    }

    public function logout(Request $request): Response
    {
        return $this->access->handle($request, null, function (IdentityRepository $repository, array $actor): Response {
            $repository->audit((int) $actor['institution_id'], (int) $actor['id'], 'sesion_cerrada');
            $this->session->signOut();
            return Response::redirect('/iniciar');
        });
    }
}
