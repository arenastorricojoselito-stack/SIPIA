<?php

declare(strict_types=1);

namespace Sipia\Controllers;

use Sipia\Http\Request;
use Sipia\Http\Response;
use Sipia\Repositories\IdentityRepository;
use Sipia\Security\InstitutionAccess;
use Sipia\Security\Permission;
use Sipia\Security\Role;
use Sipia\Security\WebSession;
use Sipia\Validation\AccountInput;

final class AdministrationController extends Controller
{
    public function __construct(private readonly InstitutionAccess $access, private readonly WebSession $session)
    {
    }

    public function panel(Request $request): Response
    {
        return $this->access->handle($request, null, function (IdentityRepository $repository, array $actor): Response {
            $total = Permission::ManageUsers->allowedFor($actor['roles']) ? $repository->totals() : null;
            return $this->page('panel', $repository, $actor, ['total' => $total]);
        });
    }

    public function institution(Request $request): Response
    {
        return $this->access->handle($request, Permission::ManageInstitution, function (
            IdentityRepository $repository, array $actor,
        ) use ($request): Response {
            if ($request->method !== 'POST') {
                return $this->page('institution', $repository, $actor);
            }

            $name = trim($request->field('nombre'));
            if (!AccountInput::validName($name)) {
                return $this->page('institution', $repository, $actor, [
                    'error' => 'Indica un nombre válido de hasta 120 caracteres.',
                    'entered' => $name,
                ], 422);
            }

            $repository->renameInstitution($name);
            $repository->audit((int) $actor['institution_id'], (int) $actor['id'], 'institucion_actualizada', (int) $actor['institution_id']);
            return $this->saved('/institucion', 'La institución se actualizó.');
        });
    }

    public function users(Request $request): Response
    {
        return $this->access->handle($request, Permission::ManageUsers, function (
            IdentityRepository $repository, array $actor,
        ) use ($request): Response {
            $page = $this->pageNumber($request);
            $search = $request->query('q');
            $search = AccountInput::validName($search) ? $search : '';
            $users = $repository->listUsers($search, ($page - 1) * 20);
            return $this->page('users', $repository, $actor, [
                'users' => array_slice($users, 0, 20),
                'more' => count($users) > 20,
                'page' => $page,
                'search' => $search,
            ]);
        });
    }

    public function userForm(Request $request): Response
    {
        return $this->access->handle($request, Permission::ManageUsers, function (
            IdentityRepository $repository, array $actor,
        ) use ($request): Response {
            $creating = $request->path === '/usuarios/nuevo';
            $userId = filter_var($request->query('id'), FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            $user = $creating ? null : $repository->user($userId === false ? 0 : $userId);
            $institutionId = (int) $actor['institution_id'];
            $actorId = (int) $actor['id'];

            if (!$creating && $user === null) {
                $repository->audit($institutionId, $actorId, 'recurso_inaccesible');
                return Response::text('Usuario no encontrado.', 404);
            }
            if (!$creating && $userId === $actorId) {
                return Response::text('Usa Mi cuenta para cambiar tu contraseña.', 403);
            }

            $currentRoles = $user === null ? [] : $repository->roles((int) $user['id']);
            $values = [
                'editing' => !$creating,
                'id' => $userId,
                'name' => $user['name'] ?? '',
                'email' => $user['email'] ?? '',
                'active' => $user['active'] ?? true,
                'roles' => $currentRoles,
            ];
            if ($request->method !== 'POST') {
                return $this->page('user_form', $repository, $actor, $values);
            }

            $name = trim($request->field('nombre'));
            $email = strtolower(trim($request->field('correo')));
            $password = $request->field('clave');
            $active = $creating || $request->field('activo') === '1';
            $submittedRoles = $request->fields('roles');
            $roles = array_values(array_intersect(array_keys(Role::labels()), array_filter($submittedRoles, 'is_string')));
            sort($roles);

            $values = array_replace($values, [
                'name' => $name, 'email' => $email, 'active' => $active, 'roles' => $roles,
            ]);
            if (!AccountInput::validName($name) || !AccountInput::validEmail($email) || $roles === []
                || count($roles) !== count($submittedRoles) || ($creating && !AccountInput::validPassword($password))) {
                return $this->page('user_form', $repository, $actor, [
                    ...$values, 'error' => 'Revisa el nombre, el correo, los roles y la contraseña inicial cuando corresponda.',
                ], 422);
            }

            $existing = $repository->credentials($email);
            if ($existing !== null && (int) $existing['id'] !== $userId) {
                return $this->page('user_form', $repository, $actor, [
                    ...$values, 'error' => 'Ya existe un usuario con ese correo en esta institución.',
                ], 422);
            }

            if ($creating) {
                $userId = $repository->createUser($institutionId, $name, $email, password_hash($password, PASSWORD_DEFAULT));
                $repository->setRoles($institutionId, $userId, $roles);
                $repository->audit($institutionId, $actorId, 'usuario_creado', $userId);
                return $this->saved('/usuarios', 'El usuario se creó.');
            }

            $revoke = $roles !== $currentRoles || $active !== $user['active'] || $email !== $user['email'];
            $repository->updateUser($userId, $name, $email, $active, $revoke);
            if ($roles !== $currentRoles) {
                $repository->setRoles($institutionId, $userId, $roles);
                $repository->audit($institutionId, $actorId, 'roles_actualizados', $userId);
            }
            if ($active !== $user['active']) {
                $repository->audit($institutionId, $actorId, $active ? 'usuario_activado' : 'usuario_desactivado', $userId);
            }
            $repository->audit($institutionId, $actorId, 'usuario_actualizado', $userId);
            return $this->saved('/usuarios', 'El usuario se actualizó.');
        });
    }

    public function account(Request $request): Response
    {
        return $this->access->handle($request, null, function (IdentityRepository $repository, array $actor) use ($request): Response {
            if ($request->method !== 'POST') {
                return $this->page('account', $repository, $actor);
            }

            $current = $request->field('actual');
            $password = $request->field('clave');
            $credentials = $repository->credentials($actor['email']);
            if (!AccountInput::validPassword($current) || !password_verify($current, $credentials['password_hash'])
                || !AccountInput::validPassword($password) || $password !== $request->field('confirmacion')) {
                $repository->audit((int) $actor['institution_id'], (int) $actor['id'], 'cambio_clave_denegado');
                return $this->page('account', $repository, $actor, [
                    'error' => 'Comprueba tu contraseña actual y la confirmación de la nueva.',
                ], 422);
            }

            $repository->changePassword((int) $actor['id'], password_hash($password, PASSWORD_DEFAULT));
            $repository->audit((int) $actor['institution_id'], (int) $actor['id'], 'clave_actualizada', (int) $actor['id']);
            $this->session->signOut();
            return Response::redirect('/iniciar');
        });
    }

    public function audit(Request $request): Response
    {
        return $this->access->handle($request, Permission::ReadAudit, function (
            IdentityRepository $repository, array $actor,
        ) use ($request): Response {
            $page = $this->pageNumber($request);
            $events = $repository->auditEvents(($page - 1) * 20);
            return $this->page('audit', $repository, $actor, [
                'events' => array_slice($events, 0, 20),
                'more' => count($events) > 20,
                'page' => $page,
            ]);
        });
    }

    private function page(
        string $template, IdentityRepository $repository, array $actor, array $data = [], int $status = 200,
    ): Response {
        $title = match ($template) {
            'panel' => 'Panel',
            'institution' => 'Institución',
            'users' => 'Usuarios',
            'user_form' => 'Usuario',
            'account' => 'Mi cuenta',
            'audit' => 'Auditoría',
        };
        return $this->view($template, $title, [
            'institution' => $repository->institution(),
            'actor' => $actor,
            'csrf' => $this->session->csrf(),
            'notice' => $this->session->notice(),
            ...$data,
        ], $status);
    }

    private function saved(string $target, string $message): Response
    {
        $this->session->flash($message);
        return Response::redirect($target);
    }

    private function pageNumber(Request $request): int
    {
        return filter_var($request->query('pagina'), FILTER_VALIDATE_INT, ['options' => [
            'min_range' => 1, 'max_range' => 100000,
        ]]) ?: 1;
    }
}
