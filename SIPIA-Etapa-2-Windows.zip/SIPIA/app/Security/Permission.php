<?php

declare(strict_types=1);

namespace Sipia\Security;

enum Permission
{
    case ManageInstitution;
    case ManageUsers;
    case ReadAudit;

    public function allowedFor(array $roles): bool
    {
        $allowed = match ($this) {
            self::ManageInstitution, self::ManageUsers => [Role::Administrator->value],
            self::ReadAudit => [Role::Administrator->value, Role::Coordination->value],
        };

        return array_intersect($allowed, $roles) !== [];
    }
}
