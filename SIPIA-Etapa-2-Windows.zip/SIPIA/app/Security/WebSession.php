<?php

declare(strict_types=1);

namespace Sipia\Security;

use RuntimeException;

final class WebSession
{
    public function __construct(private readonly bool $https)
    {
    }

    public function csrf(): string
    {
        $this->open();
        return $_SESSION['csrf'] ??= bin2hex(random_bytes(32));
    }

    public function verifyCsrf(string $token): bool
    {
        return hash_equals($this->csrf(), $token);
    }

    public function flash(string $message): void
    {
        $this->open();
        $_SESSION['notice'] = $message;
    }

    public function notice(): ?string
    {
        $this->open();
        $message = $_SESSION['notice'] ?? null;
        unset($_SESSION['notice']);
        return $message;
    }

    public function signIn(array $user): void
    {
        $this->open();
        if (!session_regenerate_id(true)) {
            throw new RuntimeException('No se pudo renovar la sesión.');
        }

        $_SESSION = [
            'user' => (int) $user['id'],
            'institution' => (int) $user['institution_id'],
            'version' => (int) $user['session_version'],
            'since' => time(),
            'last' => time(),
        ];
    }

    public function identity(): ?array
    {
        $this->open();
        if (!isset($_SESSION['user'])) {
            return null;
        }
        if (time() - $_SESSION['last'] >= 1800 || time() - $_SESSION['since'] >= 28800) {
            $this->signOut();
            return null;
        }

        $_SESSION['last'] = time();
        return [$_SESSION['institution'], $_SESSION['user'], $_SESSION['version']];
    }

    public function signOut(): void
    {
        $this->open();
        $_SESSION = [];
        $params = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires' => 1,
            'path' => $params['path'],
            'secure' => $params['secure'],
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_destroy();
    }

    private function open(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }
        session_name('SIPIASESSID');
        if (!session_start([
            'use_strict_mode' => 1,
            'use_only_cookies' => 1,
            'cookie_secure' => $this->https,
            'cookie_httponly' => true,
            'cookie_samesite' => 'Lax',
            'cookie_path' => '/',
            'cache_limiter' => '',
            'gc_maxlifetime' => 28800,
        ])) {
            throw new RuntimeException('No se pudo iniciar la sesión.');
        }
    }
}
