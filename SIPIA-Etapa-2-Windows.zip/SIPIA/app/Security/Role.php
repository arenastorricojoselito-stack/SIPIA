<?php

declare(strict_types=1);

namespace Sipia\Security;

enum Role: string
{
    case Administrator = 'administrador';
    case Repository = 'repositorio';
    case Student = 'estudiante';
    case Evaluator = 'evaluador';
    case Coordination = 'coordinacion';

    public function label(): string
    {
        return match ($this) {
            self::Administrator => 'Administración institucional',
            self::Repository => 'Responsable de repositorio',
            self::Student => 'Estudiante',
            self::Evaluator => 'Tutor o evaluador',
            self::Coordination => 'Coordinación académica',
        };
    }

    public static function labels(): array
    {
        $labels = [];
        foreach (self::cases() as $role) {
            $labels[$role->value] = $role->label();
        }
        return $labels;
    }
}
