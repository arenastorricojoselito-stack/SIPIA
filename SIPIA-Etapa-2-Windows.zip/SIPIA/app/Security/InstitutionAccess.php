<?php

declare(strict_types=1);

namespace Sipia\Security;

use Closure;
use Sipia\Http\Request;
use Sipia\Http\Response;
use Sipia\Persistence\Connection;
use Sipia\Persistence\InstitutionScope;
use Sipia\Repositories\IdentityRepository;

final readonly class InstitutionAccess
{
    public function __construct(private Connection $connection, private WebSession $session)
    {
    }

    public function handle(Request $request, ?Permission $permission, Closure $operation): Response
    {
        $identity = $this->session->identity();
        if ($identity === null) {
            return Response::redirect('/iniciar');
        }
        [$institutionId, $userId, $version] = $identity;

        $database = $this->connection->open();
        $repository = new IdentityRepository($database);
        return (new InstitutionScope($database))->write(
            $institutionId,
            function () use ($request, $repository, $institutionId, $userId, $version, $permission, $operation): Response {
                if ($request->method === 'POST') {
                    $repository->lockInstitution($institutionId);
                }

                $actor = $repository->user($userId);
                if ($actor === null || !$actor['active'] || (int) $actor['session_version'] !== $version) {
                    $this->session->signOut();
                    return Response::redirect('/iniciar');
                }

                if ($request->method === 'POST' && !$this->session->verifyCsrf($request->field('csrf'))) {
                    $repository->audit($institutionId, $userId, 'csrf_denegado');
                    return Response::text('La solicitud caducó. Vuelve a abrir el formulario.', 403);
                }

                $actor['roles'] = $repository->roles($userId);
                if ($permission !== null && !$permission->allowedFor($actor['roles'])) {
                    $repository->audit($institutionId, $userId, 'permiso_denegado');
                    return Response::text('No tienes permiso para esta operación.', 403);
                }

                return $operation($repository, $actor);
            },
        );
    }
}
