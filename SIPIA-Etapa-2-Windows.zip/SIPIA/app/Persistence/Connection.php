<?php

declare(strict_types=1);

namespace Sipia\Persistence;

use PDO;
use Sipia\Support\Environment;
use Sipia\Validation\DatabaseSettings;

final class Connection
{
    public function __construct(private readonly Environment $environment)
    {
    }

    public function open(): PDO
    {
        $host = DatabaseSettings::identifier($this->environment->require('SIPIA_DB_HOST'));
        $database = DatabaseSettings::identifier($this->environment->require('SIPIA_DB_NAME'));
        $port = DatabaseSettings::port(getenv('SIPIA_DB_PORT'));

        return new PDO(
            "pgsql:host={$host};port={$port};dbname={$database};connect_timeout=3",
            $this->environment->require('SIPIA_DB_USER'),
            $this->environment->require('SIPIA_DB_PASSWORD'),
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false],
        );
    }
}
