<?php

declare(strict_types=1);

namespace Sipia\Persistence;

use Closure;
use InvalidArgumentException;
use PDO;
use Throwable;

final class InstitutionScope
{
    public function __construct(private readonly PDO $database)
    {
    }

    /** Receives an institution already authorized by the application. */
    public function read(int $institutionId, Closure $operation): mixed
    {
        return $this->run($institutionId, $operation, true);
    }

    public function write(int $institutionId, Closure $operation): mixed
    {
        return $this->run($institutionId, $operation, false);
    }

    private function run(int $institutionId, Closure $operation, bool $readOnly): mixed
    {
        if ($institutionId < 1) {
            throw new InvalidArgumentException('Institución inválida.');
        }

        $this->database->beginTransaction();
        try {
            if ($readOnly) {
                $this->database->exec('SET TRANSACTION READ ONLY');
            }
            $statement = $this->database->prepare("SELECT set_config('sipia.institution_id', :institution, true)");
            $statement->execute(['institution' => (string) $institutionId]);
            $result = $operation($this->database);
            $this->database->commit();

            return $result;
        } catch (Throwable $failure) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            throw $failure;
        }
    }
}
