<?php

declare(strict_types=1);

use Sipia\Controllers\AdministrationController;
use Sipia\Controllers\AuthenticationController;
use Sipia\Controllers\HomeController;
use Sipia\Controllers\ReadinessController;
use Sipia\Http\Response;
use Sipia\Http\Router;

return static function (
    Router $router,
    HomeController $home,
    ReadinessController $readiness,
    AuthenticationController $auth,
    AdministrationController $admin,
): void {
    $router->get('/', $home);
    $router->get('/salud', $readiness);
    $router->get('/iniciar', $auth->form(...));
    $router->post('/iniciar', $auth->authenticate(...));
    $router->post('/salir', $auth->logout(...));
    $router->get('/panel', $admin->panel(...));
    $router->get('/institucion', $admin->institution(...));
    $router->post('/institucion', $admin->institution(...));
    $router->get('/usuarios', $admin->users(...));
    $router->get('/usuarios/nuevo', $admin->userForm(...));
    $router->post('/usuarios/nuevo', $admin->userForm(...));
    $router->get('/usuarios/editar', $admin->userForm(...));
    $router->post('/usuarios/editar', $admin->userForm(...));
    $router->get('/auditoria', $admin->audit(...));
    $router->get('/cuenta', $admin->account(...));
    $router->post('/cuenta', $admin->account(...));

    foreach (['bootstrap.min.css', 'sipia.css'] as $stylesheet) {
        $router->get('/assets/' . $stylesheet, static function () use ($stylesheet): Response {
            $body = file_get_contents(dirname(__DIR__) . '/public/assets/' . $stylesheet);
            return $body === false
                ? Response::text('Archivo no encontrado.', 404)
                : new Response($body, 200, ['Content-Type' => 'text/css; charset=utf-8']);
        });
    }
};
