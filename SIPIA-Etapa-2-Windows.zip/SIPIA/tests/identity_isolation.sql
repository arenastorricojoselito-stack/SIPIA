\set ON_ERROR_STOP on
BEGIN;

INSERT INTO sipia.institutions (name) VALUES ('Aislamiento de identidad A') RETURNING id AS tenant_a \gset
INSERT INTO sipia.institutions (name) VALUES ('Aislamiento de identidad B') RETURNING id AS tenant_b \gset
INSERT INTO sipia.users (institution_id, name, email, password_hash)
VALUES (:tenant_a, 'Cuenta A', 'cuenta@example.test', 'solo-fixture') RETURNING id AS user_a \gset
INSERT INTO sipia.users (institution_id, name, email, password_hash)
VALUES (:tenant_b, 'Cuenta B', 'cuenta@example.test', 'solo-fixture') RETURNING id AS user_b \gset
INSERT INTO sipia.user_roles VALUES (:tenant_a, :user_a, 'administrador'), (:tenant_b, :user_b, 'estudiante');
INSERT INTO sipia.audit_events (institution_id, actor_id, action)
VALUES (:tenant_a, :user_a, 'evento_a'), (:tenant_b, :user_b, 'evento_b');

SELECT set_config('sipia.test_tenant_a', :'tenant_a', true);
SELECT set_config('sipia.test_user_a', :'user_a', true);
SELECT set_config('sipia.test_user_b', :'user_b', true);
SET LOCAL ROLE sipia_app;

DO $$
DECLARE
    tenant_a bigint := current_setting('sipia.test_tenant_a')::bigint;
    user_a bigint := current_setting('sipia.test_user_a')::bigint;
    user_b bigint := current_setting('sipia.test_user_b')::bigint;
    rows_changed int;
BEGIN
    IF EXISTS (SELECT FROM sipia.users) OR EXISTS (SELECT FROM sipia.user_roles)
       OR EXISTS (SELECT FROM sipia.audit_events) THEN
        RAISE EXCEPTION 'El rol web leyó datos sin contexto';
    END IF;

    PERFORM set_config('sipia.institution_id', tenant_a::text, true);
    IF (SELECT array_agg(id) FROM sipia.users) IS DISTINCT FROM ARRAY[user_a]
       OR (SELECT array_agg(role) FROM sipia.user_roles) IS DISTINCT FROM ARRAY['administrador']
       OR (SELECT array_agg(action::text) FROM sipia.audit_events) IS DISTINCT FROM ARRAY['evento_a'] THEN
        RAISE EXCEPTION 'El contexto A recibió datos de otra institución';
    END IF;

    UPDATE sipia.users SET name = 'Cambio externo' WHERE id = user_b;
    GET DIAGNOSTICS rows_changed = ROW_COUNT;
    IF rows_changed <> 0 THEN
        RAISE EXCEPTION 'El rol web modificó una cuenta de otra institución';
    END IF;

    BEGIN
        INSERT INTO sipia.user_roles VALUES (tenant_a, user_b, 'administrador');
        RAISE EXCEPTION 'Se permitió asignar rol a un usuario ajeno';
    EXCEPTION WHEN foreign_key_violation THEN
        NULL;
    END;

    IF has_table_privilege('sipia.audit_events', 'UPDATE,DELETE') THEN
        RAISE EXCEPTION 'El rol web puede alterar el historial de auditoría';
    END IF;
END
$$;

ROLLBACK;
\echo Identidades, roles y auditoria institucionales aislados
