<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;
use Sipia\Http\Kernel;
use Sipia\Http\Response;
use Sipia\Http\Router;
use Sipia\Middleware\SecurityHeaders;
use Sipia\Support\Logger;
use Sipia\Validation\DatabaseSettings;


final class KernelTest extends TestCase
{
    public function testQueryStringDoesNotChangeRoute(): void
    {
        $response = $this->kernel()->handle('GET', '/?consulta=uno');
        self::assertSame(200, $response->status);
        self::assertSame('Inicio', $response->body);
        self::assertSame('nosniff', $response->headers['X-Content-Type-Options']);
    }

    public function testRoutingRejectsUnknownPathsAndMethods(): void
    {
        $kernel = $this->kernel();
        self::assertSame(404, $kernel->handle('GET', '/.env')->status);
        self::assertSame(400, $kernel->handle('GET', 'malformada')->status);
        $response = $kernel->handle('POST', '/');
        self::assertSame(405, $response->status);
        self::assertSame('GET, HEAD', $response->headers['Allow']);
    }

    public function testExceptionIsRedacted(): void
    {
        $kernel = $this->kernel();
        $response = $kernel->handle('GET', '/fallo');
        self::assertSame(500, $response->status);
        self::assertStringNotContainsString('dato interno de prueba', $response->body);
        self::assertSame('no-store', $response->headers['Cache-Control']);
    }

    public function testDatabaseIdentifierRejectsDsnOptions(): void
    {
        $this->expectException(InvalidArgumentException::class);
        DatabaseSettings::identifier('sipia;host=otro');
    }

    public function testDatabasePortDefaultsAndAcceptsExplicitLocalPort(): void
    {
        self::assertSame(5432, DatabaseSettings::port(false));
        self::assertSame(55432, DatabaseSettings::port('55432'));
    }

    public function testDatabasePortRejectsDsnOptions(): void
    {
        $this->expectException(InvalidArgumentException::class);
        DatabaseSettings::port('55432;host=otro');
    }

    private function kernel(): Kernel
    {
        $router = new Router();
        $router->get('/', static fn (): Response => Response::text('Inicio', 200));
        $router->get('/fallo', static function (): never {
            throw new RuntimeException('dato interno de prueba');
        });

        return new Kernel($router, new SecurityHeaders(), new Logger());
    }
}
