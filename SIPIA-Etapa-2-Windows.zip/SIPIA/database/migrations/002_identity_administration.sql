ALTER TABLE sipia.institutions ADD COLUMN code varchar(48);
UPDATE sipia.institutions SET code = 'institucion-' || id;
ALTER TABLE sipia.institutions
    ALTER COLUMN code SET NOT NULL,
    ADD CONSTRAINT institutions_code_unique UNIQUE (code),
    ADD CONSTRAINT institutions_code_format CHECK (code ~ '^[a-z0-9][a-z0-9-]{1,47}$');

-- Keep the original insert contract for seeds and imports from Etapa 1.
CREATE FUNCTION sipia.assign_institution_code() RETURNS trigger
LANGUAGE plpgsql SET search_path = pg_catalog
AS $$
BEGIN
    IF NEW.code IS NULL THEN
        NEW.code := 'institucion-' || NEW.id;
    END IF;
    RETURN NEW;
END
$$;
CREATE TRIGGER institution_default_code BEFORE INSERT ON sipia.institutions
FOR EACH ROW EXECUTE FUNCTION sipia.assign_institution_code();

CREATE FUNCTION sipia.find_login_institution(institution_code text) RETURNS bigint
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog
AS $$
    SELECT id FROM sipia.institutions WHERE code = institution_code
$$;
REVOKE ALL ON FUNCTION sipia.find_login_institution(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION sipia.find_login_institution(text) TO sipia_app;

CREATE POLICY institution_update ON sipia.institutions FOR UPDATE TO sipia_app
    USING (id = NULLIF(current_setting('sipia.institution_id', true), '')::bigint)
    WITH CHECK (id = NULLIF(current_setting('sipia.institution_id', true), '')::bigint);
GRANT UPDATE (name) ON sipia.institutions TO sipia_app;

CREATE TABLE sipia.users (
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    institution_id bigint NOT NULL REFERENCES sipia.institutions (id),
    name varchar(120) NOT NULL CHECK (length(btrim(name)) > 0),
    email varchar(254) NOT NULL CHECK (email = lower(email)),
    password_hash text NOT NULL,
    active boolean NOT NULL DEFAULT true,
    session_version integer NOT NULL DEFAULT 1,
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (institution_id, id),
    UNIQUE (institution_id, email)
);

CREATE TABLE sipia.user_roles (
    institution_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role text NOT NULL CHECK (role IN ('administrador', 'repositorio', 'estudiante', 'evaluador', 'coordinacion')),
    PRIMARY KEY (institution_id, user_id, role),
    FOREIGN KEY (institution_id, user_id) REFERENCES sipia.users (institution_id, id)
);

CREATE TABLE sipia.audit_events (
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    institution_id bigint NOT NULL REFERENCES sipia.institutions (id),
    actor_id bigint,
    action varchar(60) NOT NULL,
    resource_id bigint,
    occurred_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (institution_id, actor_id) REFERENCES sipia.users (institution_id, id)
);
CREATE INDEX audit_events_tenant_recent ON sipia.audit_events (institution_id, id DESC);

CREATE TABLE sipia.login_limits (
    client_key text PRIMARY KEY,
    expires_at timestamptz NOT NULL,
    attempts smallint NOT NULL
);
CREATE INDEX login_limits_expiry ON sipia.login_limits (expires_at);

DO $$
DECLARE
    table_name text;
BEGIN
    FOREACH table_name IN ARRAY ARRAY['users', 'user_roles', 'audit_events']
    LOOP
        EXECUTE format('ALTER TABLE sipia.%I ENABLE ROW LEVEL SECURITY', table_name);
        EXECUTE format('ALTER TABLE sipia.%I FORCE ROW LEVEL SECURITY', table_name);
        EXECUTE format(
            'CREATE POLICY institution_scope ON sipia.%I TO sipia_app
             USING (institution_id = NULLIF(current_setting(''sipia.institution_id'', true), '''')::bigint)
             WITH CHECK (institution_id = NULLIF(current_setting(''sipia.institution_id'', true), '''')::bigint)',
            table_name
        );
    END LOOP;
END
$$;

GRANT SELECT, INSERT ON sipia.users TO sipia_app;
GRANT UPDATE (name, email, password_hash, active, session_version) ON sipia.users TO sipia_app;
GRANT SELECT, INSERT, DELETE ON sipia.user_roles TO sipia_app;
GRANT SELECT, INSERT ON sipia.audit_events TO sipia_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON sipia.login_limits TO sipia_app;
