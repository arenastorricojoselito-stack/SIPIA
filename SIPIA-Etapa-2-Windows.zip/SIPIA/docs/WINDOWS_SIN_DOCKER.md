# Ejecutar SIPIA en Windows sin Docker

Esta guía usa Windows x64, PHP 8.4, Composer y PostgreSQL 16 con pgvector.
Miniforge instala PostgreSQL y pgvector precompilados en un entorno local.
Reserva los puertos 55432 para la base y 8080 para PHP. Ambos servicios se
inician en 127.0.0.1.

## 1. Preparar PHP y Composer

1. Descarga el ZIP **x64 Non Thread Safe** de PHP 8.4 desde
   [PHP para Windows](https://windows.php.net/download/) y extráelo a una
   carpeta como C:\php84. Si falta una biblioteca de Visual C++, instala
   el redistribuible x64 indicado por la página de PHP.
2. Copia php.ini-development a php.ini en esa carpeta. En php.ini,
   configura extension_dir con la ruta de la carpeta ext y habilita
   openssl, pdo_pgsql, mbstring y zip quitando el punto y coma inicial.

       extension_dir = "C:\php84\ext"
       extension=openssl
       extension=pdo_pgsql
       extension=mbstring
       extension=zip

3. Ejecuta el [instalador de Composer para Windows](https://getcomposer.org/download/)
   y selecciona C:\php84\php.exe. Abre un PowerShell nuevo en la carpeta
   SIPIA, donde está composer.json. Si PHP no está en PATH, agrégalo a
   esta sesión con $env:Path = "C:\php84;$env:Path".

       php --ini
       php --ri openssl
       php --ri pdo_pgsql
       composer --version
       composer install

## 2. Crear la base PostgreSQL con pgvector

Instala [Miniforge para Windows x86_64](https://github.com/conda-forge/miniforge/releases/latest)
con la opción para tu usuario. Abre **Miniforge Prompt** desde Inicio. Los
siguientes comandos usan la sintaxis de esa ventana, basada en cmd.exe.

       conda create -n sipia-pg --override-channels -c conda-forge postgresql=16 pgvector
       conda activate sipia-pg
       if not exist "%LOCALAPPDATA%\SIPIA" mkdir "%LOCALAPPDATA%\SIPIA"
       initdb -D "%LOCALAPPDATA%\SIPIA\pgdata" -U postgres -A scram-sha-256 -E UTF8 -W
       pg_ctl -D "%LOCALAPPDATA%\SIPIA\pgdata" -l "%LOCALAPPDATA%\SIPIA\postgres.log" -o "-p 55432 -h 127.0.0.1" -w start
       createdb -h 127.0.0.1 -p 55432 -U postgres sipia
       createuser -h 127.0.0.1 -p 55432 -U postgres -P sipia_app

Define la contraseña de postgres cuando initdb la pida. En createuser,
elige una contraseña diferente para sipia_app y usa la de postgres cuando
psql solicite autenticación del administrador. Conserva ambas.

Ejecuta initdb, createdb y createuser una vez. Para volver a iniciar una
base ya creada, abre Miniforge Prompt, ejecuta conda activate sipia-pg y
repite el comando pg_ctl con start. Si falla el arranque, consulta
%LOCALAPPDATA%\SIPIA\postgres.log.

## 3. Migrar y arrancar SIPIA

Vuelve a PowerShell en la carpeta SIPIA. Ejecuta cada comando por separado.

       .\bin\sipia-windows.ps1 -Accion Migrar
       .\bin\sipia-windows.ps1 -Accion Iniciar

La migración pide la contraseña de postgres y habilita pgvector. El servidor
pide la contraseña de sipia_app y usa ese rol con permisos limitados.
Si Windows bloquea el script del ZIP por su procedencia, revisa el archivo y
usa Unblock-File .\bin\sipia-windows.ps1 antes de repetir. Si una política
administrativa impide ejecutar scripts, el arranque manual se describe abajo.

Abre http://127.0.0.1:8080/ y http://127.0.0.1:8080/salud. Debes ver la
portada y el texto Disponible. Mantén el PowerShell abierto mientras pruebas.
El parámetro -PuertoWeb cambia el puerto de PHP. Para usar otro puerto en
PostgreSQL, cámbialo en pg_ctl y en los comandos de PostgreSQL, y pasa
-PuertoDb a ambos comandos del script.

## 4. Cargar datos y probar

En Miniforge Prompt, activa sipia-pg y entra a la carpeta donde extrajiste
SIPIA con cd /d "RUTA_COMPLETA_A_SIPIA". Luego ejecuta:

       psql -X -h 127.0.0.1 -p 55432 -U postgres -d sipia -f database/demo.sql
       psql -X -h 127.0.0.1 -p 55432 -U postgres -d sipia -f tests/isolation.sql

El primer comando deja dos instituciones de prueba. El segundo verifica
aislamiento mediante sus propios datos temporales. Ejecuta composer test
desde otra ventana de PowerShell en la misma carpeta para correr PHPUnit.
La portada de la Etapa 1 aún no muestra los datos institucionales.

Detén PHP con Ctrl+C. Puedes apagar PostgreSQL desde Miniforge Prompt con:

       pg_ctl -D "%LOCALAPPDATA%\SIPIA\pgdata" -w stop

## Arranque manual con PowerShell

Estos comandos hacen lo mismo que el script. Se ejecutan desde la raíz de
SIPIA. Ciérrala al terminar para eliminar las variables de esa sesión.

       $env:SIPIA_DB_HOST = '127.0.0.1'
       $env:SIPIA_DB_PORT = '55432'
       $env:SIPIA_DB_NAME = 'sipia'
       $env:SIPIA_DB_USER = 'postgres'
       $env:SIPIA_DB_PASSWORD = ([System.Net.NetworkCredential]::new('', (Read-Host 'Clave de postgres' -AsSecureString))).Password
       php bin/migrate.php
       Remove-Item Env:SIPIA_DB_PASSWORD

Cuando la migración informe que está vigente, usa el rol de aplicación:

       $env:SIPIA_DB_USER = 'sipia_app'
       $env:SIPIA_DB_PASSWORD = ([System.Net.NetworkCredential]::new('', (Read-Host 'Clave de sipia_app' -AsSecureString))).Password
       php -d display_errors=0 -d log_errors=1 -S 127.0.0.1:8080 -t public public/index.php
       Remove-Item Env:SIPIA_DB_PASSWORD

## Actualizar a la Etapa 2 y crear la primera cuenta

Si ya usabas SIPIA, conserva la base sipia y sus datos. Aplica las
migraciones nuevas como postgres. El archivo 002 agrega el código de
acceso a cada institución preexistente y crea las tablas de usuarios,
roles y auditoría.

Detén el servidor PHP con Ctrl+C. Desde PowerShell, abre la carpeta con
los archivos de la Etapa 2 y ejecuta composer install. Luego pega este
bloque, con PostgreSQL ejecutándose como en la sección 2:

       $env:SIPIA_DB_HOST = '127.0.0.1'
       $env:SIPIA_DB_PORT = '55432'
       $env:SIPIA_DB_NAME = 'sipia'
       $env:SIPIA_DB_USER = 'postgres'
       $env:SIPIA_DB_PASSWORD = ([System.Net.NetworkCredential]::new('', (Read-Host 'Clave de postgres' -AsSecureString))).Password
       try {
           php .\bin\migrate.php
           if ($LASTEXITCODE -ne 0) { throw 'Revisa la salida de la migración.' }
           $env:SIPIA_ADMIN_PASSWORD = ([System.Net.NetworkCredential]::new('', (Read-Host 'Nueva contraseña para entrar a SIPIA' -AsSecureString))).Password
           php .\bin\provision.php --codigo=mi-instituto --institucion="Mi Instituto" --nombre="Administrador" --correo=admin@ejemplo.test
       } finally {
           Remove-Item Env:SIPIA_DB_PASSWORD -ErrorAction SilentlyContinue
           Remove-Item Env:SIPIA_ADMIN_PASSWORD -ErrorAction SilentlyContinue
       }

Cambia nombre, correo y código de ejemplo según tu institución. La
contraseña de la cuenta web requiere al menos 12 caracteres y un máximo
de 72 bytes. El rol PostgreSQL sipia_app sigue configurándose por separado.

Para usar una institución de tu base anterior, busca su código en
Miniforge Prompt tras migrar:

       psql -X -h 127.0.0.1 -p 55432 -U postgres -d sipia -c "SELECT code, name FROM sipia.institutions ORDER BY id"

En el comando de alta usa ese código y omite el argumento --institucion.
El alta por CLI se realiza una vez por institución y conserva los datos
preexistentes.

Arranca SIPIA con el bloque **Arranque manual con PowerShell**, desde la
línea que establece SIPIA_DB_USER como sipia_app. Usa la clave de
PostgreSQL para sipia_app. Abre http://127.0.0.1:8080/iniciar y entra con
el código, correo y **contraseña web** que elegiste en el alta. Desde el
panel puedes editar el nombre de la institución, crear usuarios y
consultar la auditoría.
