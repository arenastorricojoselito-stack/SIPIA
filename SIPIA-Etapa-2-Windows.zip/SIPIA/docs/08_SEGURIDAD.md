# Seguridad

## Fundamentos

- Rol de migraciones separado del rol web. Seguridad por fila con denegación por defecto en la tabla inicial.
- Credenciales por entorno, acceso local por loopback y conexión interna a PostgreSQL y PHP-FPM.
- Front controller fijo, respuestas de error genéricas, logs sin mensajes de excepción ni credenciales, cabeceras HTTP restrictivas.

## Controles de etapas posteriores

Los módulos nuevos deberán aplicar los controles de identidad y autorización descritos abajo. Cada capa deberá respetar institución y permiso sobre el recurso. El contexto SQL es una defensa adicional frente a errores de consulta y debe derivarse de una autorización del servidor. Las vistas dinámicas deben escapar contenido según el contexto.

Los documentos se validarán y almacenarán en privado. Archivos, trabajos, consultas vectoriales y exportaciones requerirán pruebas de acceso cruzado. El perfil de producción deberá incorporar TLS, gestión de secretos, respaldos cifrados y restauración probada. La salida a servicios de IA externos depende de autorización previa.

## Controles verificados en Etapa 2

- Hash de contraseña con password_hash y comprobación con password_verify.
- Sesiones estrictas con rotación al autenticar, cookie HttpOnly y
  SameSite=Lax, Secure bajo HTTPS. Caducidad de 30 minutos de inactividad
  y ocho horas desde el inicio. El servidor comprueba estado y versión de
  la cuenta en cada solicitud protegida.
- CSRF para operaciones POST, mensajes genéricos de acceso, escape
  contextual y consultas PDO preparadas. Límite de cinco intentos por
  cuenta solicitada y treinta por IP en 15 minutos.
- RLS y referencias compuestas para impedir cruces de datos. El único
  acceso fuera de un contexto al catálogo es la función de inicio de
  sesión, que devuelve el identificador asociado a un código exacto.
  El contexto autenticado proviene de la sesión y se restringe a la
  transacción. Los permisos por rol se comprueban en PHP.
- Eventos institucionales para accesos, denegaciones, cambios de cuentas,
  roles y contraseña. El rol web carece de privilegios para alterar o
  eliminar el historial.
- Las pruebas locales usan HTTP por loopback. Producción requiere HTTPS y
  la indicación de conexión segura desde el servidor FastCGI antes de
  exponer el servicio. La recuperación de cuentas y el segundo factor
  siguen pendientes de definición institucional (PV-08).
