# Base de datos

PostgreSQL 16 con pgvector. La migración inicial habilita la extensión, crea `sipia.institutions` y activa seguridad por fila. Sin contexto institucional, la consulta a la tabla devuelve cero filas. `InstitutionScope` fija el ámbito dentro de la transacción. Solo debe recibir una institución cuya autorización haya comprobado el servidor.

El historial de migraciones guarda nombre, suma SHA-256 y fecha. Una transacción y un bloqueo de la base serializan la aplicación. Las migraciones publicadas se amplían con archivos nuevos.

Pendiente de diseño físico según la ERS §7.2: identidades y membresías, catálogos por institución, proyectos y autores, versiones y archivos, secciones y vectores, análisis y evidencias, evaluaciones, configuraciones y auditoría. Las relaciones y políticas de los módulos posteriores deberán impedir referencias cruzadas entre instituciones.

## Migración 002 · Identidad

Se asigna un código estable a cada institución existente. Las nuevas
instituciones permiten un código explícito y las cargas de la Etapa 1
conservan su valor autogenerado. La cuenta es institucional. El correo es
único dentro de la institución y las asignaciones de roles permiten
varios roles por cuenta. Las claves compuestas impiden referencias entre
instituciones. Las tablas users, user_roles y audit_events aplican RLS.
El rol web puede agregar y leer eventos en el ámbito, con privilegios de
escritura limitados a INSERT en auditoría.

La versión de sesión cambia al modificar el acceso o la contraseña. El
control de intentos almacena claves SHA-256 derivadas del origen y de la
cuenta ingresada, con caducidad. En el perfil local se usa la dirección
que entrega el servidor web.
