\set ON_ERROR_STOP on
BEGIN;
LOCK TABLE sipia.institutions IN SHARE ROW EXCLUSIVE MODE;

INSERT INTO sipia.institutions (name)
SELECT demo.name
FROM (VALUES ('Instituto Demo Norte'), ('Instituto Demo Sur')) AS demo(name)
WHERE NOT EXISTS (
    SELECT 1 FROM sipia.institutions AS existing WHERE existing.name = demo.name
);

COMMIT;
SELECT id, name FROM sipia.institutions
WHERE name IN ('Instituto Demo Norte', 'Instituto Demo Sur')
ORDER BY id;
