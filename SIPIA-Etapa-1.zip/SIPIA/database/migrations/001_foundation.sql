CREATE EXTENSION IF NOT EXISTS vector;

CREATE SCHEMA sipia;
REVOKE ALL ON SCHEMA sipia FROM PUBLIC;
GRANT USAGE ON SCHEMA sipia TO sipia_app;

CREATE TABLE sipia.institutions (
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name text NOT NULL CHECK (length(btrim(name)) > 0)
);

ALTER TABLE sipia.institutions ENABLE ROW LEVEL SECURITY;
ALTER TABLE sipia.institutions FORCE ROW LEVEL SECURITY;

CREATE POLICY institution_read ON sipia.institutions FOR SELECT TO sipia_app
    USING (id = NULLIF(current_setting('sipia.institution_id', true), '')::bigint);
GRANT SELECT ON sipia.institutions TO sipia_app;
