<?php

declare(strict_types=1);

require dirname(__DIR__) . '/vendor/autoload.php';

use Sipia\Controllers\HomeController;
use Sipia\Controllers\ReadinessController;
use Sipia\Http\Kernel;
use Sipia\Http\Router;
use Sipia\Middleware\SecurityHeaders;
use Sipia\Persistence\Connection;
use Sipia\Repositories\ReadinessRepository;
use Sipia\Services\Readiness;
use Sipia\Support\Environment;
use Sipia\Support\Logger;

$logger = new Logger();
$router = new Router();
$readiness = new Readiness(new ReadinessRepository(new Connection(new Environment())), $logger);
$register = require dirname(__DIR__) . '/config/routes.php';
$register($router, new HomeController(), new ReadinessController($readiness));

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
(new Kernel($router, new SecurityHeaders(), $logger))
    ->handle($method, $_SERVER['REQUEST_URI'] ?? '/')
    ->send($method !== 'HEAD');
