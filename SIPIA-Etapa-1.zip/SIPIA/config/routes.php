<?php

declare(strict_types=1);

use Sipia\Controllers\HomeController;
use Sipia\Controllers\ReadinessController;
use Sipia\Http\Router;

return static function (Router $router, HomeController $home, ReadinessController $readiness): void {
    $router->get('/', $home);
    $router->get('/salud', $readiness);
};
