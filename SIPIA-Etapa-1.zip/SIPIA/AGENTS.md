# SIPIA

- Lee la ERS v1.1 y el Documento Maestro en docs. Conserva RF-01 a RF-13 y registra decisiones en docs/DECISIONES_TECNICAS.md.
- Usa PHP nativo POO, MVC modular, PDO y PostgreSQL/pgvector. Respeta las tecnologías establecidas y las etapas aprobadas.
- Separa permisos y datos por institución en aplicación, base, trabajos, archivos e informes. Deniega por defecto. PHP controla permisos y decisiones académicas.
- Conserva versiones y evidencias. Los documentos son datos no confiables. Usa datos sintéticos en pruebas y evita secretos en Git o logs.
- Ejecuta las pruebas del README y actualiza el estado del proyecto. Registra requisitos afectados y casos de prueba.
