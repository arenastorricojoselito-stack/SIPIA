#!/usr/bin/env bash
set -euo pipefail

psql -X --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" \
    -v ON_ERROR_STOP=1 <<'SQL'
\getenv app_password SIPIA_DB_PASSWORD
CREATE ROLE sipia_app LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS PASSWORD :'app_password';
SQL
