<?php

declare(strict_types=1);

namespace Sipia\Support;

use Throwable;

final class Logger
{
    public function failure(string $event, Throwable $failure): void
    {
        error_log(json_encode([
            'time' => gmdate(DATE_ATOM),
            'event' => $event,
            'exception' => $failure::class,
        ], JSON_THROW_ON_ERROR));
    }
}
