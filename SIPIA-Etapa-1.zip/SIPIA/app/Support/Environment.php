<?php

declare(strict_types=1);

namespace Sipia\Support;

use RuntimeException;

final class Environment
{
    public function require(string $name): string
    {
        $value = getenv($name);
        if ($value === false || $value === '') {
            throw new RuntimeException("Falta la variable de entorno {$name}.");
        }

        return $value;
    }
}
