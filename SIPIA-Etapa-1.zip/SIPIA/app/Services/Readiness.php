<?php

declare(strict_types=1);

namespace Sipia\Services;

use Sipia\Repositories\ReadinessRepository;
use Sipia\Support\Logger;
use Throwable;

final readonly class Readiness
{
    public function __construct(private ReadinessRepository $repository, private Logger $logger)
    {
    }

    public function isReady(): bool
    {
        try {
            return $this->repository->isReady();
        } catch (Throwable $failure) {
            $this->logger->failure('database.unavailable', $failure);
            return false;
        }
    }
}
