<?php

declare(strict_types=1);

namespace Sipia\Controllers;

use Sipia\Http\Response;
use Sipia\Services\Readiness;

final readonly class ReadinessController
{
    public function __construct(private Readiness $readiness)
    {
    }

    public function __invoke(): Response
    {
        return $this->readiness->isReady()
            ? Response::text('Disponible', 200)
            : Response::text('Servicio no disponible', 503);
    }
}
