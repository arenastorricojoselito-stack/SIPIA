<?php

declare(strict_types=1);

namespace Sipia\Controllers;

use Sipia\Http\Response;
use Throwable;

abstract class Controller
{
    protected function view(string $name): Response
    {
        ob_start();
        try {
            require dirname(__DIR__) . "/Views/{$name}.php";
            return new Response((string) ob_get_clean());
        } catch (Throwable $failure) {
            ob_end_clean();
            throw $failure;
        }
    }
}
