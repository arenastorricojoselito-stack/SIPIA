<?php

declare(strict_types=1);

namespace Sipia\Controllers;

use Sipia\Http\Response;

final class HomeController extends Controller
{
    public function __invoke(): Response
    {
        return $this->view('home');
    }
}
