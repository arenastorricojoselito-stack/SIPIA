<?php

declare(strict_types=1);

namespace Sipia\Validation;

use InvalidArgumentException;

final class DatabaseSettings
{
    public static function identifier(string $value): string
    {
        if (preg_match('/\A[a-zA-Z0-9_.-]+\z/', $value) !== 1) {
            throw new InvalidArgumentException('Identificador de conexión inválido.');
        }

        return $value;
    }
}
