<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SIPIA</title>
</head>
<body>
    <main>
        <h1>SIPIA</h1>
        <p>Sistema Inteligente de Proyectos e Innovación Académica</p>
    </main>
</body>
</html>
