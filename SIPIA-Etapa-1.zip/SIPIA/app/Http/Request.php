<?php

declare(strict_types=1);

namespace Sipia\Http;

use InvalidArgumentException;

final readonly class Request
{
    public function __construct(public string $method, public string $path)
    {
    }

    public static function fromTarget(string $method, string $target): self
    {
        $path = explode('?', $target, 2)[0];
        if (!str_starts_with($path, '/') || preg_match('/[\x00-\x20\x7f]/', $path)) {
            throw new InvalidArgumentException('Ruta inválida.');
        }

        return new self($method, $path);
    }
}
