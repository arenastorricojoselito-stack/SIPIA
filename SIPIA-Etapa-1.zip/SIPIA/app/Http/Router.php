<?php

declare(strict_types=1);

namespace Sipia\Http;

use LogicException;

final class Router
{
    private array $getRoutes = [];

    public function get(string $path, callable $handler): void
    {
        if (isset($this->getRoutes[$path])) {
            throw new LogicException('Ruta duplicada.');
        }

        $this->getRoutes[$path] = $handler;
    }

    public function dispatch(Request $request): Response
    {
        $handler = $this->getRoutes[$request->path] ?? null;
        if ($handler === null) {
            return Response::text('Página no encontrada.', 404);
        }
        if (!in_array($request->method, ['GET', 'HEAD'], true)) {
            return Response::text('Método no permitido.', 405, ['Allow' => 'GET, HEAD']);
        }

        return $handler();
    }
}
