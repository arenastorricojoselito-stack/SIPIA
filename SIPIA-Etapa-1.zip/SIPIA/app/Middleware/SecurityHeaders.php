<?php

declare(strict_types=1);

namespace Sipia\Middleware;

use Sipia\Http\Response;

final class SecurityHeaders
{
    public function apply(Response $response): Response
    {
        return new Response($response->body, $response->status, [
            ...$response->headers,
            'X-Content-Type-Options' => 'nosniff',
            'Referrer-Policy' => 'no-referrer',
            'Content-Security-Policy' => "default-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'",
            'Cache-Control' => 'no-store',
        ]);
    }
}
