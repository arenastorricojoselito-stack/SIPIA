<?php

declare(strict_types=1);

namespace Sipia\Repositories;

use Sipia\Persistence\Connection;

final readonly class ReadinessRepository
{
    public function __construct(private Connection $connection)
    {
    }

    public function isReady(): bool
    {
        $database = $this->connection->open();

        return $database->query("SELECT ('[1,0]'::public.vector <-> '[0,1]'::public.vector) > 0")->fetchColumn() === true
            && $database->query('SELECT id FROM sipia.institutions LIMIT 1')->fetchColumn() === false;
    }
}
