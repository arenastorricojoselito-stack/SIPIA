# Prueba local de SIPIA · Etapa 1

Instala y abre Docker Desktop en Windows o macOS. En Linux, usa Docker Engine y el complemento Compose v2. Extrae el ZIP y abre una terminal en la carpeta SIPIA, donde está compose.yaml.

1. Copia .env.example a .env. En Linux o macOS usa cp .env.example .env. En PowerShell usa Copy-Item .env.example .env. Abre .env en un editor y completa POSTGRES_PASSWORD y SIPIA_DB_PASSWORD con dos contraseñas de prueba distintas. SIPIA_PORT es 8080 de forma predeterminada.
2. En Linux o macOS, ejecuta chmod 755 docker/postgres/init.sh y chmod 644 docker/nginx/default.conf. Después ejecuta docker compose up --build -d. La primera ejecución crea la base sipia, los roles de migración y de aplicación y el esquema con pgvector. Ejecuta docker compose ps -a para comprobar que db, app y web están activos y migrate terminó con código 0.
3. Abre http://127.0.0.1:8080/ y http://127.0.0.1:8080/salud. Debes ver la portada y el texto Disponible. Si cambiaste SIPIA_PORT, usa ese puerto.
4. Carga los datos sintéticos. En Linux o macOS:

       docker compose exec -T db psql -X -U sipia_owner -d sipia < database/demo.sql

   En PowerShell:

       Get-Content -Raw -Encoding UTF8 database/demo.sql | docker compose exec -T db psql -X -U sipia_owner -d sipia

   Verás los identificadores de Instituto Demo Norte e Instituto Demo Sur. Puedes ejecutar la carga de nuevo sin duplicar las filas. Esta etapa aún no tiene pantalla de gestión de instituciones ni cuentas de acceso.
5. Para ejecutar PHPUnit usa docker compose exec -T app composer test. Para validar el aislamiento de instituciones, repite el comando de carga sustituyendo database/demo.sql por tests/isolation.sql. La prueba de aislamiento revierte sus propias filas y conserva las dos instituciones de demostración.

Para diagnosticar un fallo de arranque usa docker compose logs db migrate app web. Para detener el entorno y conservar los datos usa docker compose down. El README explica la configuración para redes con proxy.
