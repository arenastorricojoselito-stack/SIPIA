# SIPIA

Sistema Inteligente de Proyectos e Innovación Académica. Este repositorio contiene los fundamentos de la plataforma.

## Arranque local

Requisitos: Docker Engine, Docker Compose v2 y un puerto 8080 libre. Desde la raíz del repositorio:

1. Copia el archivo de configuración de ejemplo.

   ```sh
   cp -n .env.example .env
   ```

2. Edita `.env` y asigna dos contraseñas de desarrollo diferentes a `POSTGRES_PASSWORD` y `SIPIA_DB_PASSWORD`. Puedes generar cada una con `openssl rand -hex 24`. Para usar un puerto distinto, cambia `SIPIA_PORT`.

3. Construye e inicia los servicios.

   ```sh
   docker compose up --build -d
   docker compose ps -a
   curl -fsS http://127.0.0.1:8080/salud
   ```

Abre `http://127.0.0.1:8080/` para ver la portada. La comprobación de salud debe devolver `Disponible`. El proceso de migración debe figurar como finalizado con código 0. Si la comprobación falla, revisa `docker compose logs db migrate app web`.

Después de editar PHP, vuelve a ejecutar `docker compose up --build -d`. Las contraseñas se aplican al inicializar la base. Para rotar las de una base existente, cambia las claves de ambos roles en PostgreSQL y actualiza `.env` antes de recrear los servicios. Conserva el volumen para mantener los datos.

Detén el entorno con `docker compose down`. Los servicios de PHP y PostgreSQL están en la red interna de Compose y Nginx escucha solo en loopback. Este perfil se usa para desarrollo local.

## Pruebas

```sh
docker compose exec -T app composer test
docker compose exec -T app composer validate --strict
docker compose exec -T db psql -X -U sipia_owner -d sipia < tests/isolation.sql
docker compose run --rm migrate
curl -fsS http://127.0.0.1:8080/salud
```

La prueba SQL introduce dos instituciones sintéticas en una transacción que se revierte. Ejecútala sobre una base de desarrollo. La segunda migración comprueba que el proceso se puede repetir con las mismas versiones SQL.

El [plan de implementación](docs/11_PLAN_IMPLEMENTACION.md) y el [estado del proyecto](docs/ESTADO_PROYECTO.md) registran el alcance y los pendientes.

### Redes con proxy corporativo

La compilación admite una CA adicional mediante el secreto de BuildKit
`composer_proxy_ca`. Si el proxy bloquea los archivos de distribución de
GitHub pero permite Git HTTPS, usa `COMPOSER_INSTALL_MODE=source` como
argumento de compilación. La instalación conserva la verificación TLS y
usa las revisiones fijadas en `composer.lock`. En ese entorno, añade en un
archivo de Compose local la siguiente configuración y ejecuta
`docker compose -f compose.yaml -f /ruta/compose.proxy.yaml up --build -d`.

```yaml
services:
  app:
    build:
      args:
        COMPOSER_INSTALL_MODE: source
      secrets:
        - composer_proxy_ca
  migrate:
    build:
      args:
        COMPOSER_INSTALL_MODE: source
      secrets:
        - composer_proxy_ca
secrets:
  composer_proxy_ca:
    file: /ruta/a/ca-corporativa.crt
```
