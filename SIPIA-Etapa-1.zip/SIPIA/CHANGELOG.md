# Historial de cambios

## Sin publicar

- Base PHP MVC con autoload PSR-4, rutas HTTP, configuración, errores y logs.
- Entorno Docker local con Nginx, PHP-FPM, PostgreSQL y pgvector.
- Migraciones iniciales, seguridad por fila y pruebas de fundamentos.
- Fuentes v1.1 y documentación técnica inicial.
