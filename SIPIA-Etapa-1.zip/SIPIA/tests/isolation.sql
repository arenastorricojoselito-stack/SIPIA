\set ON_ERROR_STOP on
BEGIN;
INSERT INTO sipia.institutions (name) VALUES ('Prueba A') RETURNING id AS fixture_a \gset
INSERT INTO sipia.institutions (name) VALUES ('Prueba B') RETURNING id AS fixture_b \gset
SELECT set_config('sipia.test_fixture_a', :'fixture_a', true);
SELECT set_config('sipia.test_fixture_b', :'fixture_b', true);
SET LOCAL ROLE sipia_app;

DO $$
DECLARE
    fixture_a bigint := current_setting('sipia.test_fixture_a')::bigint;
    fixture_b bigint := current_setting('sipia.test_fixture_b')::bigint;
BEGIN
    IF EXISTS (SELECT FROM sipia.institutions) THEN
        RAISE EXCEPTION 'El rol web ve datos sin contexto';
    END IF;
    PERFORM set_config('sipia.institution_id', fixture_a::text, true);
    IF (SELECT array_agg(id) FROM sipia.institutions) IS DISTINCT FROM ARRAY[fixture_a] THEN
        RAISE EXCEPTION 'El contexto A no aísla instituciones';
    END IF;
    IF EXISTS (SELECT FROM sipia.institutions WHERE id = fixture_b) THEN
        RAISE EXCEPTION 'Acceso cruzado por ID';
    END IF;
    PERFORM set_config('sipia.institution_id', fixture_b::text, true);
    IF (SELECT array_agg(id) FROM sipia.institutions) IS DISTINCT FROM ARRAY[fixture_b] THEN
        RAISE EXCEPTION 'El contexto B no aísla instituciones';
    END IF;
    IF has_table_privilege('sipia.institutions', 'INSERT,UPDATE,DELETE') THEN
        RAISE EXCEPTION 'El rol web tiene permisos de escritura';
    END IF;
    IF ('[1,0]'::public.vector <-> '[0,1]'::public.vector) <= 0 THEN
        RAISE EXCEPTION 'pgvector no devolvió la distancia esperada';
    END IF;
END $$;

ROLLBACK;
\echo Aislamiento de instituciones y operación vectorial verificados
