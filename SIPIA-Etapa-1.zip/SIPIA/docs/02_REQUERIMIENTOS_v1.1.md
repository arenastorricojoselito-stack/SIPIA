# SIPIA — Especificación de Requerimientos de Software (ERS)

**Sistema Inteligente de Proyectos e Innovación Académica**  
**Código:** SIPIA-ERS-001 | **Versión:** 1.1 | **Fecha:** 26/11/2026  
**Estado:** Propuesta para validación institucional (no aprobada)  
**Fuente:** SIPIA_Documento_Maestro_v1.1.docx, 26/11/2026; revisión del Maestro v1.0 de 25/11/2026.  
**Destino en Git:** `docs/02_REQUERIMIENTOS.md`

## 0. Control documental

| Versión | Fecha | Descripción | Estado |
|---|---|---|---|
| 1.0 | 26/11/2026 | Primera especificación detallada derivada del Documento Maestro | En revisión |
| 1.1 | 26/11/2026 | Sustitución de Laravel por PHP nativo MVC; alcance e identificadores funcionales conservados | En revisión |

Responsables de validación propuestos: coordinación académica (normativa y flujo), administración institucional (roles y catálogos), responsable de repositorio (migración y calidad), responsable técnico (arquitectura, seguridad y operación). La aprobación deberá quedar registrada en una revisión posterior; no se presupone la aceptación institucional.

**Convenciones:** M = MVP obligatorio; E = evolución posterior; P = propuesta derivada pendiente de validar. M identifica alcance, no aprobación. Los identificadores RF-01 a RF-13 se conservan; los sufijos identifican requisitos verificables. CA = criterio de aceptación; RN = regla de negocio; RNF = requisito no funcional; CU = caso de uso; PV = pendiente de validación; CP = caso de prueba. «Debe» indica comportamiento requerido en la línea base propuesta. Los números ilustrativos del Maestro no son metas aprobadas. Las adiciones operativas (p. ej. recuperación de cuentas, reintentos, cierre final, exportación PDF) se identifican como P cuando la fuente no define su detalle. Los cambios futuros deben indicar motivo, impacto y aprobación; no renumerar IDs existentes.

## 1. Introducción y alcance

### 1.1 Propósito

Definir un contrato funcional y de calidad para diseñar, implementar y probar SIPIA. La ERS orienta los futuros documentos de arquitectura, similitud, interfaz, seguridad y pruebas y el trabajo de Codex. No sustituye las normas académicas ni el diseño técnico detallado.

### 1.2 Problema y objetivos

Cada gestión pueden repetirse ideas, problemas, objetivos o soluciones con títulos diferentes; los archivos dispersos dificultan la consulta. La comparación de títulos por sí sola no detecta equivalencias semánticas y puede confundir proyectos distintos. SIPIA debe digitalizar el historial, facilitar la búsqueda, detectar antecedentes relevantes y apoyar decisiones humanas justificadas.

Objetivos verificables: OBJ-01 centralizar archivos y fichas; OBJ-02 extraer información con procedencia y control de calidad; OBJ-03 recuperar antecedentes por similitud textual y semántica; OBJ-04 entregar evidencias y diferencias verificables; OBJ-05 preservar versiones, decisiones y trazabilidad; OBJ-06 permitir separación institucional y evolución comercial sin reescritura del núcleo.

### 1.3 Alcance del MVP

Autenticación y autorización; catálogos académicos; repositorio histórico y proyectos en curso; carga individual y masiva de PDF/Word, extracción/OCR cuando viable; revisión de fichas; búsqueda preliminar; registro y versionado de perfiles; comparación híbrida; revisión, justificación y decisión; entrega final y nuevo análisis; incorporación al repositorio; reportes, indicadores básicos, auditoría y configuración. Piloto de una carrera, con expansión a otras carreras y modalidades, incluyendo emprendimientos productivos. El modelo y la separación de datos por institución son obligatorios desde el MVP; la operación comercial multiinstitución completa es evolución posterior.

### 1.4 Exclusiones iniciales

No se incluye búsqueda universal de plagio en Internet, rechazo automático, calificación automática, integración con sistemas externos ni seguimiento integral de avances. Tampoco se comprometen facturación, pagos, licenciamiento automatizado, aplicaciones móviles nativas, asistente de innovación o estadísticas avanzadas en el MVP. RF-13 conserva la evolución prevista. Una API de IA generativa es opcional y condicionada a autorización; no es dependencia necesaria del flujo principal.

### 1.5 Definiciones

| Término | Definición |
|---|---|
| Institución | Unidad de aislamiento de datos y permisos; puede tener varias carreras y gestiones. |
| Proyecto | Identidad académica persistente, independiente de sus versiones. |
| Perfil | Versión estructurada inicial de una propuesta, con problema, objetivos y solución, entre otros. |
| Ficha | Metadatos y contenido estructurado de una versión; preliminar o confirmada. |
| Antecedente | Proyecto histórico o en curso relevante para una consulta. |
| Fragmento | Segmento de texto vinculado a una sección y documento de origen. |
| Embedding | Representación vectorial para comparar significado. |
| Índice | Medida de cercanía normalizada; no probabilidad de plagio ni nota. |
| Cobertura | Proporción del peso de campos comparables, no proporción de originalidad. |
| Corpus | Conjunto de versiones autorizadas disponibles para búsqueda en un análisis. |
| OCR | Reconocimiento óptico de caracteres; puede introducir errores. |

## 2. Contexto del producto y arquitectura de referencia

Sistema web institucional para institutos técnicos y tecnológicos. Los usuarios acceden por navegador; el procesamiento documental e IA se ejecuta en segundo plano. Se prevén 10 a 100 usuarios como objetivo preliminar de capacidad; la concurrencia, volumen de archivos y hardware se medirán en el piloto.

La arquitectura de referencia v1.1 adopta un monolito modular en PHP nativo orientado a objetos, MVC, servicios y repositorios, vistas PHP reutilizables, Bootstrap 5 y JavaScript/Fetch API. Se mantienen PostgreSQL con pgvector, Python/FastAPI y Sentence Transformers multilingüe, PyMuPDF, python-docx, Tesseract, almacenamiento privado local u objeto compatible, Docker, Nginx (PHP-FPM) y Git. Composer con autocarga PSR-4 administra dependencias sin incorporar un framework PHP completo. PDO y consultas preparadas sustituyen el ORM. IA generativa local o API externa opcional y autorizada. No se cambia a MySQL, Node.js, Tailwind ni microservicios generalizados. No se presupone entrenamiento de modelos desde cero.

Flujo lógico: navegador → PHP (HTTPS) → PostgreSQL; PHP → cola persistente → trabajador PHP CLI → API interna Python → resultados validados por PHP. PHP es autoridad del estado académico y los permisos. Python recibe únicamente el alcance y archivos autorizados, no concede acceso ni decide estados. Los originales permanecen privados; el servicio IA no se expone al navegador. El contrato de trabajos, límites y acceso a archivos y vectores se detallarán en arquitectura.

### 2.1 Decisión arquitectónica v1.1 (DA-01)

**Motivo:** facilitar el mantenimiento por el equipo con experiencia en PHP y mantener el control del código. No se elimina ningún requisito funcional. Se reemplazan los servicios proporcionados por Laravel con componentes explícitos y bibliotecas especializadas. La arquitectura y la selección final de dependencias quedan sujetas a revisión técnica e institucional.

| Componente | Solución de referencia v1.1 |
|---|---|
| Aplicación web | PHP nativo, POO, MVC modular; punto de entrada público y router central |
| Presentación | Vistas PHP reutilizables, HTML5, Bootstrap 5 y JavaScript |
| Persistencia | PDO, repositorios, consultas preparadas, transacciones, PostgreSQL/pgvector |
| Identidad y autorización | Sesiones seguras, `password_hash()` / `password_verify()`, middleware RBAC y alcance institucional |
| Seguridad web | CSRF, escape contextual XSS, validación de entradas y archivos, límites de solicitudes, errores sin datos sensibles |
| Cola asíncrona | Cola persistente en PostgreSQL como punto de partida, trabajador PHP CLI supervisado; reclamación atómica, reintentos limitados, idempotencia y recuperación de trabajos abandonados |
| Dependencias y pruebas | Composer/PSR-4, Phinx, PHPUnit, Monolog, dotenv y Dompdf como candidatos; verificar licencias, versiones y compatibilidad antes de adoptarlos |
| Despliegue | Nginx, PHP-FPM, trabajador CLI y Python/FastAPI en servicios separados; Docker y Git |

**Controles de implementación:** solo `public/` será raíz web; configuración, secretos y documentos fuera de ella; cookies de sesión seguras, regeneración de identificador al autenticar, caducidad y revocación; autorización y alcance institucional en cada acceso, incluso por ID, cola y búsqueda vectorial; credenciales de servicio limitadas; sin SQL concatenado con entrada no confiable. Las transiciones y persistencia de resultados se validarán en PHP. Los trabajos deben persistir su institución, versión, estado, intentos y clave de idempotencia. No iniciar tareas pesadas dentro de solicitudes web. Pruebas de regresión para RNF-02,03,04,08,09,12,13,17 y CP-07,13,15,19,23 antes de pilotar.

**Impacto:** aumenta el esfuerzo inicial de infraestructura, seguridad y pruebas frente al framework. No se presupone mayor rendimiento ni seguridad sin medición. El diseño de colas, sesiones, migraciones, contratos de API y permisos será especificado en SIPIA-ARQ-001. No incorporar Laravel, Blade, Eloquent ni otro framework PHP completo sin una decisión de cambio aprobada.

## 3. Actores y autorización

| Actor | Responsabilidades |
|---|---|
| Administrador institucional (AI) | Configura carreras, gestiones, modalidades, usuarios, roles y parámetros permitidos. |
| Responsable de repositorio (RR) | Migra documentos, corrige metadatos, confirma fichas y gestiona calidad. |
| Estudiante (ES) | Consulta antecedentes autorizados, registra perfiles, adjunta archivos, justifica diferencias y corrige observaciones. |
| Tutor/evaluador (TE) | Revisa propuestas asignadas y evidencias, emite observaciones y, solo si normativa y permisos lo autorizan, decisiones. |
| Coordinación académica (CAc) | Resuelve decisiones conforme a normativa, supervisa indicadores y auditoría. |
| Administrador de plataforma (AP) | Opera infraestructura y configuración técnica; no obtiene acceso académico por su cargo. |

### 3.1 Matriz preliminar de permisos (P: granularidad a validar)

A = permitido en ámbito autorizado; R = restringido por propiedad/asignación/visibilidad; C = solo permiso específico; — = denegado por defecto. La matriz no sustituye políticas por recurso y por institución.

| Operación | AI | RR | ES | TE | CAc | AP |
|---|---|---|---|---|---|---|
| Catálogos y usuarios | A | — | — | — | C | — |
| Gestionar historial y confirmar fichas | C | A | — | C | C | — |
| Buscar antecedentes | R | R | R | R | R | — |
| Consultar original/evidencias | R | R | R | R | R | — |
| Crear/editar perfil | — | — | R | — | — | — |
| Presentar y justificar | — | — | R | — | — | — |
| Ejecutar análisis | C | C | R | R | R | — |
| Observar propuestas | — | — | — | R | R | — |
| Decidir aprobación/rechazo | — | — | — | C | C | — |
| Reportes académicos | R | R | R | R | R | — |
| Auditoría institucional | C | — | — | — | A | — |
| Parámetros de similitud/visibilidad | C | — | — | — | C | — |
| Operación técnica | — | — | — | — | — | A |

Si una persona acumula roles, solo se combinan permisos de la institución activa y del recurso autorizado. No se permite autoasignación de privilegios. Cualquier soporte excepcional con acceso a contenido exige autorización explícita, alcance y auditoría (P). La concesión de permisos de decisión no se presume para todo tutor o administrador.

## 4. Flujo académico y estados

### 4.1 Flujo principal

1. Carga histórica y validación de ficha; documentos autorizados se indexan.
2. Consulta preliminar por título o significado; no determina originalidad.
3. Registro de perfil, documentos y aporte innovador; se presenta una versión.
4. Procesamiento y análisis comparativo de antecedentes de la misma institución.
5. Revisión docente: comparación, observaciones y solicitud de justificación/corrección.
6. Decisión humana autorizada: observar, aprobar o rechazar con motivo. Una observación permite una nueva versión.
7. Entrega final, versionado, nuevo análisis e incorporación al repositorio conforme a validación académica.

### 4.2 Transiciones

| Origen | Destino | Actor/condición | Evidencia |
|---|---|---|---|
| Borrador | Presentado | ES propietario autorizado; campos obligatorios | Versión y fecha de presentación |
| Presentado | En análisis | Sistema tras aceptar trabajo de análisis | ID de trabajo y versión |
| En análisis | En revisión | Sistema al completar informe o registrar resultado insuficiente para revisión humana (P) | ID de análisis y estado de calidad |
| En revisión | Observado | TE/CAc autorizado; motivo | Observación y responsable |
| En revisión | Aprobado | Responsable con permiso de decisión; motivo | Decisión firmada por identidad autenticada (no firma digital certificada) |
| En revisión | Rechazado | Responsable con permiso de decisión; motivo | Decisión y evidencias |
| Observado | Presentado | ES; nueva versión y respuesta a observaciones | Vínculo con versión anterior |

Cada transición registra institución, proyecto, versión, origen/destino, actor, fecha y motivo; las automáticas registran actor de sistema. Aprobado y rechazado no se reabren de forma ordinaria; apelaciones, anulaciones y cambios excepcionales son PV-01. Para no alterar los estados originales, la entrega final se representa provisionalmente como un hito separado de la decisión (pendiente/entregada/analizada/incorporada), sujeto a PV-01; no implica que la IA revoque una aprobación. Si el análisis falla, se conserva el estado académico y se permite reintentar o revisión humana autorizada de la incidencia, sin fabricar resultados. No se puede editar una versión presentada.

### 4.3 Estados técnicos independientes (P: taxonomía operativa)

Documento: recibido → en validación → pendiente de extracción → procesando → extraído → pendiente de revisión → confirmado/indexado; salidas de error: rechazado técnicamente, ilegible o error de procesamiento. Ficha e índice pueden tener estados distintos (confirmada no equivale a indexada). Análisis: en cola, ejecutando, completado, insuficiente, fallido. Un fallo técnico no es rechazo académico. Un resultado insuficiente puede contener antecedentes parciales, pero no semáforo concluyente.

## 5. Requerimientos funcionales

Todos los requisitos M deben probar autorización, éxito, entradas inválidas, aislamiento institucional y auditoría cuando corresponda. Cada bloque indica un criterio verificable por subrequisito. Los criterios de rendimiento pendientes se completan en el piloto, no se consideran satisfechos por defecto.

### RF-01 — Usuarios, autenticación y permisos (M; Maestro §2, §6, §8)

- **RF-01.01** Autenticar con credenciales individuales y sesión segura. CA: credenciales válidas acceden; inválidas no crean sesión ni revelan si una cuenta existe.
- **RF-01.02** Gestionar usuarios, estado, membresías, roles y alcance institucional. CA: AI autorizado crea, asigna y desactiva un usuario sin modificar otra institución; una cuenta desactivada pierde acceso.
- **RF-01.03** Autorizar cada solicitud del servidor, incluidos archivos, búsqueda vectorial, reportes, trabajos y accesos directos por ID. CA: un usuario de institución A no obtiene contenido, metadatos ni conteos de B; tampoco un estudiante accede a un perfil ajeno no autorizado.
- **RF-01.04 (P)** Permitir cierre de sesión, cambio y recuperación de contraseña mediante mecanismo seguro acordado. CA: tokens de recuperación expiran, son de un uso y no permiten escalamiento; cerrar sesión invalida la sesión.
- **RF-01.05** Separar administración técnica de acceso académico. CA: AP sin autorización no abre originales ni fichas; el acceso excepcional queda registrado.

### RF-02 — Configuración académica (M; §2, §6)

- **RF-02.01** Administrar instituciones, carreras, gestiones y modalidades dentro del ámbito correspondiente. CA: dos instituciones pueden tener catálogos independientes; solo administradores autorizados los modifican.
- **RF-02.02** Vincular proyectos a carrera, gestión y modalidad válidas. CA: se rechaza una combinación con entidad de otra institución o referencia inexistente.
- **RF-02.03 (P)** Permitir desactivar catálogos sin borrar historial y aplicar reglas de campos por modalidad. CA: catálogo inactivo no se selecciona en nuevas propuestas; sus antecedentes siguen consultables según permisos.
- **RF-02.04 (P)** Gestionar asignación de tutor/evaluador y ámbito de revisión. CA: la bandeja de un docente no incluye propuestas ajenas a su asignación, salvo permiso institucional explícito.

### RF-03 — Repositorio histórico y en curso (M; §1–3, §6)

- **RF-03.01** Registrar, editar metadatos mediante cambios auditados y consultar proyectos con ficha, autores y tutor. CA: un proyecto histórico puede recuperarse por carrera, modalidad y gestión; las modificaciones no pierden la versión analizada.
- **RF-03.02** Diferenciar origen histórico, en curso y final incorporado sin duplicar la identidad del proyecto. CA: una entrega final permanece vinculada al proyecto inicial; en curso aparece solo conforme a visibilidad.
- **RF-03.03** Permitir inventario, carga por lotes, asignación de metadatos y revisión de muestra de calidad. CA: lote con archivos válidos, repetidos e inválidos informa resultado por archivo y permite corregir los fallidos sin duplicar los exitosos.
- **RF-03.04** Permitir consultar ficha y originales autorizados. CA: la ficha referencia sus versiones y el original solo se descarga mediante autorización.
- **RF-03.05 (P)** Gestionar correcciones, archivo/inactivación y retirada de versiones del índice conforme a retención, sin borrado destructivo ordinario. CA: una versión retirada deja de participar en nuevas búsquedas, manteniendo trazabilidad autorizada.

### RF-04 — Documentos y versiones (M; §3, §6)

- **RF-04.01** Recibir PDF y DOCX, y DOC antiguo mediante conversión controlada cuando sea viable; conservar original privado, fecha, formato, tamaño y versión. CA: los formatos válidos se almacenan; archivos corruptos, cifrados no procesables, extensiones engañosas o tamaño excedido muestran error sin publicación.
- **RF-04.02** Validar formato real, límite de tamaño configurable, permisos y hash criptográfico; detectar duplicado exacto sin revelar archivos de otra institución. CA: recargar los mismos bytes genera alerta de duplicidad dentro de ámbito permitido; no crea registros administrativos accidentales ni elimina versiones legítimas.
- **RF-04.03** Conservar versiones de archivo asociadas a versión del proyecto y no sobrescribir originales. CA: v2 conserva v1 y sus resultados históricos; una descarga selecciona la versión autorizada.
- **RF-04.04** Mostrar estados, errores y calidad de extracción; permitir reprocesamiento autorizado. CA: un archivo ilegible queda pendiente o fallido, nunca interpretado como ausencia de similitud.

### RF-05 — Procesamiento documental e IA (M; §3, §6–8)

- **RF-05.01** Extraer texto de PDF y DOCX; aplicar OCR a páginas sin texto útil cuando sea viable y conversión DOC aislada. CA: documento digital y escaneado legible producen texto con procedencia; si falla OCR se registra calidad insuficiente.
- **RF-05.02** Separar secciones y fragmentos con referencia al original, página cuando exista, y localizador alternativo (sección/párrafo) cuando no haya paginación estable. CA: se puede ubicar cada evidencia en su fuente sin inventar números de página.
- **RF-05.03** Generar ficha preliminar mediante reglas o IA, indicando datos ausentes y origen; RR confirma o corrige. CA: ante ausencia de objetivo no se inventa; confirmación y corrección se auditan.
- **RF-05.04** Normalizar texto preservando original, y excluir del cálculo portadas, índices, bibliografía y plantillas comunes cuando corresponda. CA: coincidencia de portada no domina la similitud; se identifica qué contenido se excluyó.
- **RF-05.05** Generar embeddings multilingües por sección y fragmento e indexar solo versiones autorizadas; guardar modelo y versión. CA: cada vector tiene origen y versión, y los índices respetan institución y vigencia.
- **RF-05.06** Ejecutar trabajos asíncronos con estados y fallos visibles; reintento controlado e idempotente (P). CA: fallo del servicio no pierde documento, no crea resultados ficticios y un reintento no duplica el análisis lógico.

### RF-06 — Búsqueda de antecedentes (M; §2–4, §6)

- **RF-06.01** Buscar por título, palabras clave y significado. CA: un título diferente con idea equivalente aparece entre candidatos relevantes de la muestra docente; consulta léxica encuentra coincidencias textuales.
- **RF-06.02** Filtrar por carrera y gestión; modalidad y estado como filtros propuestos (P). CA: resultados respetan filtros y visibilidad, sin revelar conteos ajenos.
- **RF-06.03** Mostrar lista ordenada, ficha resumida y acceso a detalles autorizados; indicar que búsqueda por título es preliminar. CA: buscar por título nunca genera certificado de originalidad ni rechazo.
- **RF-06.04** Incluir histórico y proyectos en curso que sean elegibles. CA: un proyecto en curso restringido no expone datos a usuarios sin permiso; no se usa otra institución como corpus.

### RF-07 — Registro de propuestas (M; §2–3, §6)

- **RF-07.01** Registrar perfil con identificación, problema, objetivos, solución, funcionalidades/procesos e innovación; incluir datos específicos de emprendimiento según modalidad. CA: el formulario guarda borrador y valida campos obligatorios configurados al presentar.
- **RF-07.02** Adjuntar documentación y autores, guardar y recuperar borradores autorizados. CA: un estudiante no modifica un proyecto ajeno; los coautores se registran sin otorgar automáticamente permisos no definidos (PV-02).
- **RF-07.03** Presentar versión inmutable y crear nueva versión al responder observaciones. CA: v1 mantiene evidencia y observaciones mientras v2 puede presentarse y analizarse independientemente.
- **RF-07.04** Mostrar estado, observaciones, historial y resultados autorizados. CA: estudiante consulta sus propias versiones y responde sin poder alterar una decisión.
- **RF-07.05** Registrar entrega final y nuevo análisis, e incorporar versión autorizada al repositorio. CA: la entrega queda vinculada al perfil original; se reanaliza y solo se incorpora conforme a regla de cierre validada (PV-01).

### RF-08 — Motor de similitud (M; §4–6)

- **RF-08.01** Validar la propuesta y recuperar candidatos mediante búsqueda híbrida textual y vectorial dentro del corpus autorizado. CA: se recuperan antecedentes con palabras distintas y candidatos con copia textual; nunca candidatos de otra institución.
- **RF-08.02** Comparar por campos y fragmentos, reordenar y calcular índice normalizado con pesos versionados. CA: un título idéntico no basta para un índice alto si los restantes campos son distintos; el cálculo reproduce la configuración registrada.
- **RF-08.03** Mostrar índice por campo y global, cobertura, nivel provisional y limitaciones; distinguir ausencia de información de similitud cero. CA: campos ausentes reducen cobertura; cobertura insuficiente no produce conclusión verde ni alerta definitiva.
- **RF-08.04** Mostrar ranking y comparación lado a lado con coincidencias, diferencias, fragmentos verificables y referencias a versiones/documentos. CA: un evaluador puede rastrear las afirmaciones al original autorizado; si no hay evidencia suficiente, se indica.
- **RF-08.05** Guardar análisis, versiones de entrada/candidatos, alcance, fecha, modelo, algoritmo, configuración y evidencias. CA: un nuevo análisis no sobrescribe uno anterior y conserva sus referencias.
- **RF-08.06** Admitir proyecto relacionado, continuación legítima y diferenciación sustancial como casos de evaluación; no declarar plagio automáticamente. CA: el evaluador puede justificar una mejora incluso ante similitud elevada.
- **RF-08.07 (P)** Excluir auto-coincidencias entre versiones del propio proyecto en el ranking principal; si se comparan versiones propias, hacerlo de forma explícita. CA: v2 no aparece como copia de v1 por defecto, sin ocultar antecedentes de proyectos distintos.
- **RF-08.08 (opcional)** Si se habilita IA generativa autorizada, resumir evidencias de los 5–10 candidatos principales, con referencias y sin inventar diferencias. CA: deshabilitar el modelo generativo no impide ranking, evidencia ni decisión; documentos maliciosos no cambian instrucciones, permisos o acciones.

### RF-09 — Evaluación académica (M; §2, §5–6)

- **RF-09.01** Proveer bandeja de revisión por asignación y acceso al análisis de la versión. CA: docente autorizado accede a propuesta y evidencia permitida; otros no.
- **RF-09.02** Registrar observaciones, solicitudes de justificación y respuestas asociadas a versión/candidato cuando corresponda. CA: se conserva texto, autor, fecha y vínculo aunque se cree nueva versión.
- **RF-09.03** Registrar decisiones humanas de aprobación, observación o rechazo motivadas, respetando transición y rol. CA: sin motivo o permiso se deniega; ningún umbral ni servicio IA ejecuta aprobación o rechazo.
- **RF-09.04** Permitir revisar continuaciones legítimas y valorar diferencias técnicas, funcionales o de mercado. CA: una similitud alta puede coexistir con aprobación motivada según normativa.
- **RF-09.05** Consultar historial de decisiones y versiones; preservar decisiones concurrentes sin sobrescritura (P). CA: segunda decisión sobre una versión ya resuelta se rechaza o requiere procedimiento excepcional autorizado.

### RF-10 — Informes e indicadores (M; §5–6)

- **RF-10.01** Generar informe descargable de análisis y evaluación con datos y versión, fecha, alcance, ranking, similitudes, cobertura, referencias, diferencias, limitaciones, observaciones y decisión humana si existe. PDF es formato propuesto (P); CA: el informe corresponde a la versión y análisis elegidos y no inventa una decisión pendiente.
- **RF-10.02** Proporcionar inicio con indicadores básicos por carrera/gestión/modalidad/estado según autorización. CA: totales se reconcilian con los registros autorizados y no mezclan instituciones.
- **RF-10.03** Aplicar permisos también al contenido exportado; mostrar leyenda de que el índice no acredita plagio. CA: un informe para estudiante no revela fragmentos u originales restringidos; el mismo informe para evaluador autorizado puede incluir mayor detalle.

### RF-11 — Auditoría (M; §2, §6, §8)

- **RF-11.01** Registrar cambios relevantes en usuarios, permisos, catálogos, fichas, documentos, versiones, estados, configuraciones y decisiones. CA: registro incluye institución, recurso, actor, fecha, acción, resultado y motivo cuando corresponda.
- **RF-11.02** Registrar accesos relevantes y ejecución, error o reintento de análisis. CA: se vincula evento al análisis y versión, sin almacenar contraseñas ni texto documental innecesario en logs.
- **RF-11.03 (P)** Restringir lectura de auditoría y proteger registros contra modificación por usuarios ordinarios; consulta por fecha, actor, acción y recurso. CA: un estudiante no lee o modifica registros; CAc autorizado consulta su institución.

### RF-12 — Configuración de similitud y visibilidad (M; §4–6, §8)

- **RF-12.01** Configurar pesos por modalidad y carrera con validación de suma 100%, valores no negativos y versión efectiva. CA: se rechaza una suma inválida; un análisis previo conserva pesos originales.
- **RF-12.02** Configurar umbrales ordenados, mínimo de cobertura (P) y reglas de visibilidad por ámbito. CA: no se aceptan intervalos contradictorios; resultado de baja cobertura se etiqueta insuficiente y usuarios no autorizados no acceden a datos restringidos.
- **RF-12.03** Registrar aprobación, autor, fecha y motivo de cambios (P); reanalizar explícitamente tras cambios relevantes. CA: configuración nueva se usa en análisis posteriores y no reescribe históricos.
- **RF-12.04** Configurar uso local y, solo con autorización previa, API externa opcional. CA: sin habilitación/consentimiento institucional no se transmiten documentos a proveedor externo; cambios quedan auditados.

### RF-13 — Evolución del producto (E; §6, §9–10)

- **RF-13.01** Seguimiento integral de avances, hitos y entregas (requisitos detallados en fase posterior).
- **RF-13.02** Asistente de innovación que sugiera diferenciación sin inventar antecedentes ni decidir (fase posterior).
- **RF-13.03** Estadísticas avanzadas (fase posterior).
- **RF-13.04** Administración comercial multiinstitución, modalidades de instalación local/alojada, soporte y migración (fase posterior). El aislamiento de datos y la parametrización ya son M; facturación y licencias automatizadas requieren validación comercial, no se asumen.
- **RF-13.05** Evaluar integraciones externas y detección web como iniciativas independientes, sujetas a alcance, privacidad y viabilidad; no son compromisos del MVP.

## 6. Reglas de negocio y motor de similitud

| ID | Regla |
|---|---|
| RN-01 | Toda consulta y relación institucional debe respetar institución activa y permisos del recurso; denegar por defecto. |
| RN-02 | Los originales son privados; acceso a ficha, fragmento y original son permisos independientes. |
| RN-03 | Proyecto, versión, documento y análisis tienen identidad propia; preservar la versión utilizada. |
| RN-04 | Perfil presentado no se edita; una corrección origina una nueva versión. |
| RN-05 | Toda decisión es humana, autorizada, motivada y auditada; no se permite rechazo ni aprobación automática. |
| RN-06 | Similitud no equivale a plagio, probabilidad de copia ni falta de innovación. |
| RN-07 | No inventar campos, citas, localizadores, coincidencias ni diferencias; señalar información ausente. |
| RN-08 | Un archivo ilegible o análisis fallido no acredita originalidad. |
| RN-09 | Solo versiones elegibles y autorizadas se indexan y buscan; el histórico y en curso se contemplan. |
| RN-10 | Excluir contenido común no sustantivo cuando corresponda; conservar original y procedencia. |
| RN-11 | Hash idéntico indica igualdad de archivo, no de autoría o proyecto; verificar duplicidad administrativa. |
| RN-12 | Los pesos, umbrales, modelo y algoritmo se versionan; resultados históricos se preservan. |
| RN-13 | Campos ausentes no puntúan cero; resultado provisional y cobertura visible. |
| RN-14 | Diferenciación legítima y continuidad pueden justificar aprobación tras revisión. |
| RN-15 | Entrega final se reanaliza y su incorporación respeta normativa y visibilidad. |
| RN-16 | Documentos son datos no confiables, nunca instrucciones para IA ni autorización de acciones. |
| RN-17 | API externa requiere habilitación y autorización previa de la institución; minimizar datos enviados. |
| RN-18 | Retención, retirada y borrado deben respetar política institucional y preservar trazabilidad permitida. |
| RN-19 (P) | No comparar por defecto una versión con el mismo proyecto; el motor conserva versiones para revisión explícita. |
| RN-20 (P) | Un resultado sin candidatos debe indicar alcance y calidad del corpus, no certificar novedad. |

### 6.1 Pesos iniciales (Maestro §4)

| Campo | Peso inicial |
|---|---:|
| Título | 5% |
| Problema | 15% |
| Objetivo general | 15% |
| Objetivos específicos | 10% |
| Solución propuesta | 20% |
| Funcionalidades o procesos | 20% |
| Aporte innovador | 15% |
| Total | 100% |

Sea A el conjunto de campos comparables con evidencia válida en ambas versiones, w_i el peso y s_i el puntaje normalizado de 0 a 100. Cobertura C = 100 × suma(w_i para i en A) / suma(w_i para todos los campos). Índice I = suma(w_i × s_i para i en A) / suma(w_i para i en A). Si A está vacío o su peso total es cero, I no se calcula. Con todos los campos disponibles, C=100%. Si faltan campos, I es provisional. La normalización de señales léxicas y coseno, combinación y umbral de cobertura se definirán y calibrarán en `docs/04_SIMILITUD.md`; no se presume que coseno × 100 sea una probabilidad o una escala validada.

Ejemplo aritmético ilustrativo: problema (15%) con puntaje 80 y solución (20%) con puntaje 90; si son los únicos campos comparables, cobertura = 35%, índice ≈ 85,7. El índice es provisional y no permite afirmar duplicación. No se ha establecido aún el mínimo de cobertura aceptable.

### 6.2 Semáforo inicial (ilustrativo, no calibrado)

| Índice | Nivel | Acción sugerida |
|---|---|---|
| 0 a menos de 60 | Bajo | Evaluación normal |
| 60 a menos de 80 | Moderado | Revisar antecedentes |
| 80 a menos de 90 | Alto | Solicitar justificación |
| 90 a 100 | Muy alto | Revisión prioritaria |
| Sin índice o cobertura insuficiente | Insuficiente | Revisar calidad o completar información |

Los límites y la cobertura mínima quedan pendientes de calibración. No se usan los colores solos; incluir texto, alcance y advertencia. Antes de calibrar, el producto debe identificar estos límites como experimentales y evitar interpretarlos como política académica.

### 6.3 Pipeline exigido

1. Validar versión, permisos, configuración y elegibilidad de campos.
2. Normalizar secciones, obtener vectores y señales léxicas (TF-IDF, n-gramas o texto completo según diseño).
3. Recuperar candidatos por ambas señales dentro de la institución y ámbito autorizado; unir y desduplicar candidatos por política de versión (P: preferir versión vigente elegible, conservar referencia exacta).
4. Comparar campos/fragmentos y reordenar; calcular cobertura y puntajes, recuperar evidencias y diferencias.
5. Persistir resultados con referencias, fecha, corpus, versiones, configuración, modelo y limitaciones; si no hay datos útiles informar insuficiencia o fallo.
6. Opcionalmente resumir evidencia de los principales 5–10 candidatos con modelo generativo autorizado. La salida se valida contra referencias y se trata como sugerencia, no decisión.

### 6.4 Calibración y validación docente

Construir un corpus representativo de carreras y modalidades, con pares etiquetados como equivalentes, relacionados, distintos o continuaciones legítimas. Mantener conjunto de ajuste y conjunto de evaluación independiente, evitando fuga entre versiones del mismo proyecto. Medir recuperación de antecedentes relevantes (p. ej. recall@K), precisión, falsos positivos, falsos negativos y cobertura. Definir K, tamaño de muestra, criterios de etiqueta y metas cuantitativas en PV-07; validar resultados por modalidad y contra títulos similares pero soluciones distintas. No aprobar el motor por un ejemplo aislado ni por un índice sin evidencia.

### 6.5 Casos ilustrativos del Maestro

Farmacia: una propuesta de ventas e inventario puede encontrar antecedentes con otros títulos sobre medicamentos o gestión comercial; deben mostrarse coincidencias funcionales y diferencias en tecnología, beneficiarios o aporte. Emprendimiento: dos productos de yogur artesanal pueden compartir temática, pero diferir en formulación, mercado, proceso, costos o modelo de negocio; no se debe concluir duplicación por producto compartido.

## 7. Información e interfaces

### 7.1 Datos mínimos de la ficha

| Grupo | Atributos |
|---|---|
| Identificación | Título, gestión, carrera, modalidad, autores, tutor, estado, institución. |
| Contenido | Resumen, problema, objetivo general, objetivos específicos, solución propuesta. |
| Diferenciación | Funcionalidades o procesos, beneficiarios, tecnología, innovación, palabras clave. |
| Emprendimiento | Producto/servicio, segmento de mercado, propuesta de valor, proceso productivo, modelo de negocio; costos si la normativa lo requiere (P). |
| Documento | Archivo original, versión, fecha, hash, texto extraído, páginas/localizadores y estado de procesamiento. |

Campos mínimos de presentación propuestos: título, carrera, gestión, modalidad, autores, problema, objetivo general, objetivos específicos, solución e innovación; tutor y documento obligatorio según reglamento (PV-01/02). Borrador admite datos incompletos. Fichas históricas pueden registrar ausencia explícita sin inventar contenido. La ausencia de un campo no afecta su permiso de consulta, pero sí la cobertura si se utiliza en comparación. No se fija aún longitud, cantidad máxima de autores ni tamaños de archivo.

### 7.2 Entidades conceptuales (Maestro §8)

| Entidades | Relación y propósito |
|---|---|
| institutions, users, roles | Institución, identidad, membresías y permisos. |
| careers, academic_periods, modalities | Catálogos institucionales. |
| projects, project_authors | Proyecto y participantes. |
| project_versions, documents | Versiones y documentos privados. |
| sections, chunks, embeddings | Texto, procedencia y vectores con modelo/versiones. |
| analysis_runs, similarity_matches | Ejecuciones y candidatos con versión exacta. |
| match_evidence | Puntajes por campo, fragmentos y referencias. |
| reviews, decisions | Observaciones, justificaciones y decisiones. |
| similarity_settings, audit_logs | Configuración versionada y trazabilidad. |

Cada dato institucional debe asociarse a su institución y sus relaciones impedir cruces no autorizados. Una identidad de usuario de alcance global (si se adopta) no elimina la membresía institucional obligatoria. Los nombres y cardinalidades físicas, claves, índices y políticas de aislamiento en base de datos se definirán en arquitectura; este cuadro no es un DDL.

### 7.3 Pantallas mínimas

| ID | Pantalla | RF asociados |
|---|---|---|
| UI-01 | Inicio de sesión y cuenta | RF-01 |
| UI-02 | Inicio con indicadores | RF-10 |
| UI-03 | Administración de usuarios, catálogos y configuración | RF-01,02,12 |
| UI-04 | Buscador de antecedentes y filtros | RF-06 |
| UI-05 | Listado y ficha de repositorio | RF-03,04 |
| UI-06 | Carga individual/masiva, extracción y revisión de ficha | RF-03,04,05 |
| UI-07 | Formulario de propuesta y versiones | RF-07 |
| UI-08 | Ranking de similitud y cobertura | RF-08 |
| UI-09 | Comparación lado a lado con evidencias | RF-08,09 |
| UI-10 | Bandeja docente y evaluación | RF-09 |
| UI-11 | Historial de versiones, decisiones y entrega final | RF-07,09 |
| UI-12 | Reportes e indicadores | RF-10 |
| UI-13 | Consulta de auditoría y estados técnicos autorizados | RF-05,11 |

Interfaces externas: navegador web HTTPS; archivos PDF/DOCX/DOC; servicio interno FastAPI para trabajos de extracción, embeddings y comparación; cola y almacenamiento privado; PostgreSQL/pgvector. Entrada y salida del servicio deben incluir identificador de trabajo, institución y versión, estado y referencias a resultados, con autenticación interna, validación de contexto y tratamiento de errores. Contratos API, schemas, mecanismos de autenticación y códigos de error detallados se especificarán en arquitectura. La IA generativa externa no forma parte de una integración obligatoria.

## 8. Requerimientos no funcionales

| ID | Requisito | Verificación/criterio |
|---|---|---|
| RNF-01 Seguridad de transporte | TLS para tráfico externo y protección de comunicación interna según despliegue. | Comprobar HTTPS y rechazo de acceso no seguro en producción. |
| RNF-02 Identidad | Hash seguro de contraseñas, sesiones protegidas, CSRF y límites de solicitudes; escape contextual XSS y consultas preparadas PDO. | Pruebas de autenticación, sesión, CSRF, XSS, inyección SQL y fuerza bruta; nunca guardar contraseñas en claro. |
| RNF-03 Autorización | Menor privilegio y aislamiento por institución en UI, API, archivos, consultas vectoriales, colas y exportaciones. | Pruebas negativas de acceso cruzado, incluido ID directo; no fuga por conteos ni errores. Validar defensa en base de datos en arquitectura. |
| RNF-04 Archivos | Validación real, límites, nombres seguros y procesamiento aislado; controles de malware/archivos comprimidos abusivos (P). | Probar archivo inválido, ruta manipulada, contenido activo y fallo de conversión; sin ejecución ni publicación. |
| RNF-05 Privacidad | Originales privados, visibilidad mínima, retención institucional y autorización previa a IA externa. | Probar descargas, eliminación conforme a política y bloqueo de salida externa sin autorización. |
| RNF-06 Disponibilidad | Copias cifradas de base y archivos y prueba de restauración; registrar fallos. | Restauración demostrada de documento, metadatos, versiones y análisis; RPO/RTO en PV-06. |
| RNF-07 Rendimiento | Capacidad preliminar de 10–100 usuarios; búsquedas interactivas y trabajos pesados asíncronos. | Prueba de carga con concurrencia, corpus, tamaño y hardware acordados; p95 y tasa de error medidos, límites en PV-06. |
| RNF-08 Escalabilidad | Separar procesamiento IA de peticiones web; capacidad de crecer en documentos, trabajadores e instituciones. | Incrementar trabajadores en piloto sin duplicar resultados ni cruzar datos; medir saturación y cola. |
| RNF-09 Mantenibilidad | Módulos separados, migraciones versionadas, Git, pruebas automatizadas y documentación. | CI o procedimiento reproducible ejecuta pruebas y migraciones; cambios ligados a RF/ADR. |
| RNF-10 Accesibilidad | Interfaz adaptable, teclado, texto junto al semáforo. | Recorrer formularios y resultados con teclado, foco visible y etiquetas; contraste y referencia WCAG 2.2 AA propuestos (P). |
| RNF-11 Trazabilidad IA | Modelo, algoritmo, parámetros, procedencia y versión de cada análisis persistidos. | Reconstruir informe histórico sin recalcular con configuración actual; registrar limitaciones. |
| RNF-12 Resiliencia (P) | Trabajos con límites de recursos/tiempo, reintentos acotados, idempotencia y recuperación. | Interrumpir trabajador; estado consistente y posibilidad de reintentar sin duplicidad. |
| RNF-13 Integridad (P) | Transiciones y escrituras críticas atómicas; originales/versiones protegidos; validación de referencias. | Simular concurrencia y caída durante guardado; no quedan decisiones contradictorias ni relaciones cruzadas. |
| RNF-14 Observabilidad (P) | Logs técnicos estructurados, estados, métricas de cola, alertas de errores; no exponer secretos. | Fallo simulado identificable por correlación; no aparecen credenciales ni texto innecesario en logs. |
| RNF-15 Portabilidad comercial | Dependencias soportadas, licencias aptas para uso comercial, despliegue reproducible local o alojado según fase. | Inventario de dependencias y revisión de licencias, incluidas bibliotecas y modelos, antes de distribución. |
| RNF-16 Usabilidad (P) | Mensajes claros en español, validación de formularios y estados comprensibles. | Usuario piloto completa consulta, registro y revisión con errores recuperables; fecha/hora contextualizadas. |
| RNF-17 Seguridad de IA | Tratar documentos como entrada no confiable; no ejecutar instrucciones, herramientas o decisiones contenidas en texto. | Pruebas de inyección de instrucciones en archivos; no hay exfiltración ni alteración de permisos o estados. |

No se declaran niveles de servicio, tiempos máximos, volumen documental, exactitud del OCR, metas de recuperación ni disponibilidad garantizada antes del piloto. Deben aprobarse valores concretos para convertir estas condiciones en criterios de salida medibles.

## 9. Casos de uso principales

### CU-01 — Cargar y validar un antecedente histórico (RF-03,04,05)

Actor: RR. Precondición: autenticado, catálogos válidos, permisos de carga. Flujo: selecciona archivo/lote y metadatos → valida y registra original/hash → procesa en cola → revisa ficha y corrige → confirma → indexa versión elegible. Alternativas: duplicado se informa; archivo inválido se rechaza técnicamente; OCR insuficiente queda pendiente; error permite reintentar. Postcondición: ficha confirmada con origen e índice cuando viable, o incidencia visible y auditada.

### CU-02 — Consultar antecedentes preliminares (RF-06)

Actor: ES/TE u otro rol autorizado. Precondición: ámbito institucional definido. Flujo: escribe título o consulta → motor recupera coincidencias textuales/semánticas autorizadas → aplica filtros → muestra resultados y ficha permitida. Alternativas: consulta vacía se valida; sin resultados se indica alcance y limitación; corpus incompleto no implica originalidad. Postcondición: antecedentes consultables sin cambio académico.

### CU-03 — Registrar y presentar perfil (RF-07,01,02)

Actor: ES. Precondición: cuenta y catálogos activos. Flujo: crea borrador → completa ficha según modalidad → adjunta documentos → valida campos → presenta versión inmutable → inicia análisis. Alternativas: datos obligatorios ausentes impiden presentación; fallo al adjuntar conserva borrador. Postcondición: versión presentada, trabajo identificable, transición auditada.

### CU-04 — Analizar similitud y consultar evidencia (RF-05,08,12)

Actor: sistema tras solicitud autorizada; TE/ES consulta según permisos. Precondición: versión y configuración disponibles. Flujo: obtiene campos comparables → busca candidatos → reordena → calcula índices y cobertura → registra evidencia/configuración → muestra informe. Alternativas: documento ilegible, baja cobertura o servicio no disponible se señalan; se reintenta sin alterar decisiones. Postcondición: análisis persistido, o fallo/insuficiencia registrada.

### CU-05 — Observar y corregir (RF-07,09)

Actor: TE/CAc y ES. Precondición: versión en revisión y asignación autorizada. Flujo: revisa comparación → emite observación motivada → ES registra respuesta y crea nueva versión → presenta → ejecuta nuevo análisis. Alternativas: observación sin motivo o versión no editable se deniega. Postcondición: versión nueva vinculada, historial anterior conservado.

### CU-06 — Resolver propuesta (RF-09,10,11)

Actor: responsable autorizado por normativa. Precondición: versión en revisión; evidencia disponible o limitación explícita. Flujo: revisa antecedentes, diferencias y justificación → elige decisión permitida → registra motivo → confirma transición y auditoría → informe refleja decisión. Alternativas: rol sin permiso, estado inválido o conflicto concurrente se rechazan; similitud elevada no impide aprobación motivada. Postcondición: decisión humana persistida, sin sobrescritura.

### CU-07 — Entrega final e incorporación (RF-07,08,03)

Actor: ES y responsable institucional. Precondición: requisitos de cierre según normativa (PV-01). Flujo: registra versión final y documento → procesa → reanaliza → responsable valida incorporación → incorpora versión elegible al repositorio. Alternativas: archivo ilegible, cambios significativos o análisis fallido se remiten a revisión humana; no hay revocación automática. Postcondición: versión final vinculada y trazable, o pendiente con motivo.

### CU-08 — Configurar y supervisar (RF-01,02,10,11,12)

Actor: AI/CAc con permiso. Precondición: institución activa. Flujo: administra catálogos/usuarios → configura pesos, umbrales y visibilidad → valida y versiona → consulta indicadores y auditoría. Alternativas: valores inválidos, cambio sin autorización o acceso cruzado se deniegan. Postcondición: configuración efectiva para nuevos análisis e historial preservado.

## 10. Trazabilidad y pruebas de aceptación

| Fuente Maestro | Objetivos | RF | Validación principal |
|---|---|---|---|
| §1–2 | OBJ-01,05,06 | RF-01,02,03,07,09 | CU-01,03,05,06; CP-06,07,09 |
| §3 | OBJ-01,02 | RF-03,04,05 | CU-01; CP-03,04,10,11 |
| §4 | OBJ-03,04 | RF-06,08,12 | CU-02,04; CP-01,02,03,05,08,12,13 |
| §5 | OBJ-04,05 | RF-08,09,10 | CU-04,06; CP-02,05,09,14 |
| §6 | Todos | RF-01–13 | Criterios de §5; CU-01–08 |
| §7–8 | OBJ-02,05,06 | RF-01,04,05,08,11,12; RNF-01–17 | CP-07,08,10,15–19 |
| §9–10 | Todos | RF-01–13 | Plan de fases, piloto, evolución y pendientes |

| ID | Escenario | Resultado esperado | RF/RNF |
|---|---|---|---|
| CP-01 | Mismo proyecto con título diferente | Aparece entre candidatos relevantes de muestra etiquetada | RF-06,08 |
| CP-02 | Título similar, solución distinta o continuación legítima | Diferencias verificables; decisión humana | RF-08,09 |
| CP-03 | Copia de párrafos | Fragmentos y referencias trazables | RF-05,08 |
| CP-04 | PDF escaneado ilegible | Estado error/insuficiente; no certificado de novedad | RF-04,05 |
| CP-05 | Perfil incompleto | Cobertura visible e índice provisional o no calculable | RF-07,08 |
| CP-06 | Proyecto en curso | Detectable en ámbito autorizado; no revela datos restringidos | RF-03,06 |
| CP-07 | Acceso de otra institución (URL/ID, vector, archivo, exportación, cola) | Cero exposición de datos, identificadores, conteos o archivos ajenos | RF-01, RNF-03 |
| CP-08 | Reanálisis con pesos nuevos | Historial, configuración y versiones previas preservados | RF-08,12 |
| CP-09 | Resultado muy alto o muy bajo | No altera por sí solo decisión; motivo obligatorio | RF-09 |
| CP-10 | Lote con repetidos y archivos inválidos | Resultado por archivo, hash y reintento sin duplicidad | RF-03,04,05 |
| CP-11 | Ficha con campos ausentes y plantilla repetida | No inventa datos; excluye contenido común pertinente | RF-05 |
| CP-12 | Umbrales desordenados o pesos incorrectos | Configuración rechazada y anterior preservada | RF-12 |
| CP-13 | Documento con instrucciones maliciosas; IA externa desactivada | No cambia instrucciones, permisos ni realiza llamadas no autorizadas | RF-08,12, RNF-17 |
| CP-14 | Informe por versión y rol | Referencias correctas; decisión y limitaciones visibles; sin datos restringidos | RF-10 |
| CP-15 | Caída y reintento de trabajador | Error recuperable, sin duplicidad ni decisión automática | RF-05, RNF-12 |
| CP-16 | Restauración de respaldo | Originales, base, configuraciones y vínculos consistentes | RNF-06 |
| CP-17 | Carga de 10–100 usuarios según perfil piloto | Métricas registradas contra metas aprobadas en PV-06 | RNF-07,08 |
| CP-18 | Teclado, adaptación y contraste | Flujo operable; texto además de colores | RNF-10 |
| CP-19 | Intentos de privilegio, CSRF, sesión y auditoría alterada | Denegación, eventos relevantes registrados, sin secretos | RF-01,11, RNF-02,03 |
| CP-20 | Emprendimientos del mismo producto con distinta propuesta de valor | Campos de modalidad comparables, diferencias verificables | RF-07,08,09 |
| CP-21 | Entrega final de proyecto aprobado | Nueva versión, análisis y decisión de incorporación trazables | RF-07,08,03 |
| CP-22 | Versiones del mismo proyecto y candidato retirado | Auto-coincidencia excluida por defecto; retirado no entra en nueva búsqueda | RF-03,08 |
| CP-23 | Fallo simultáneo de dos decisiones | No se sobrescribe una decisión; conflicto informado | RF-09, RNF-13 |

Los CP son escenarios de aceptación planificados, no pruebas ejecutadas. Cada subrequisito debe vincularse a uno o más casos de prueba detallados en `docs/07_PLAN_PRUEBAS.md`, incluidos casos de éxito, errores y permisos. CP-01 y CP-02 no prometen recuperación perfecta: K y tasa mínima se acordarán en la calibración.

## 11. Etapas y criterios de salida

| Fase | Alcance | Criterio de salida |
|---|---|---|
| 0. Descubrimiento | Normativa, permisos, muestra y criterios de piloto | PV críticos acordados; ERS revisada por responsables. |
| 1. Repositorio | RF-01–04, RF-11/12 base | Carga, fichas, roles, aislamiento y migración de muestra aprobados. |
| 2. Prueba de similitud | RF-06/08 prototipo | Recuperación demostrada de títulos distintos con ideas equivalentes sobre pares reales etiquetados. |
| 3. Procesamiento | RF-04/05 y vectores | Extracción, OCR, revisión, procedencia y reintentos reproducibles. |
| 4. Flujo académico | RF-07–10, RF-11/12 completos | Perfil, análisis, comparación, observación, decisión e informe en piloto funcional; entrega final validada. |
| 5. Piloto y calidad | RNF, CP y calibración | Pruebas de seguridad/aislamiento, restauración, carga, usabilidad y calidad IA contra criterios aprobados. |
| 6. Evolución comercial | RF-13 | Alcance, licencias, operación multiinstitución y modelo comercial validados por separado. |

No se estima plazo ni presupuesto sin volumen, equipo, infraestructura y normativa. El paso de prototipo a producción exige revisión de seguridad, licencias, respaldo, recuperación y aceptación institucional. No se considera implementado ningún requisito por aparecer en este documento.

## 12. Decisiones pendientes, riesgos y supuestos

| ID | Pendiente | Propuesta/impacto | Responsable de validar |
|---|---|---|---|
| PV-01 | Normativa de aprobación, apelación, cierre y entrega final | Mantener estados originales y hito final independiente; aprobar transiciones y campos obligatorios | Coordinación académica |
| PV-02 | Roles, asignación, coautoría y visibilidad por carrera/estado; fichas y originales | Denegación por defecto, acceso por asignación y permisos específicos; acordar qué puede ver el estudiante | Coordinación/administración |
| PV-03 | Volumen, formatos, documentos escaneados y calidad | Inventariar muestra; fijar límites de archivo, lote, OCR, DOC y reglas de duplicidad | Repositorio/TI |
| PV-04 | Definición de innovación por modalidad y campos mínimos | Taller docente; incluir criterios de proyectos de grado y emprendimientos | Coordinación/docentes |
| PV-05 | Retención, privacidad, autorización de IA externa y derechos de uso de archivos | Original privado, IA local preferente; externa desactivada sin autorización; validar política de borrado y respaldos | Institución/TI |
| PV-06 | Infraestructura, conectividad, concurrencia, SLO, RPO/RTO y límites de recursos | Medición piloto; acordar p95, disponibilidad, tasa de error, capacidad de cola, tamaños y presupuesto | TI/administración |
| PV-07 | Modelo, normalización, K, cobertura mínima, pesos, umbrales y métricas de calidad | Valores Maestro provisionales; validar con corpus docente y conjunto separado | Docentes/TI |
| PV-08 | Recuperación de cuentas, segundo factor, soporte técnico y seguridad operativa | Definir mecanismo y accesos excepcionales; segundo factor a evaluar, no compromiso actual | TI |
| PV-09 | Comercialización, licencias, marca, precios y demanda | Evaluar despliegue local/alojado, dependencias y soporte sin comprometer monetización | Responsable del producto |
| PV-10 | Reporte, formato y requisitos de accesibilidad | PDF propuesto, indicadores básicos; revisar plantilla y criterios de accesibilidad | Coordinación/TI |

Riesgos principales: falsos positivos (mitigar con evidencia, cobertura y revisión humana); falsos negativos por corpus incompleto (migración y calibración); OCR deficiente (revisión y estado insuficiente); fuga entre instituciones (aislamiento y pruebas negativas); costo y latencia de IA (colas, piloto, IA generativa opcional); licencias incompatibles (inventario y revisión antes de comercialización); resistencia docente (piloto y capacitación); fallos en infraestructura web propia sin Laravel (mitigar con componentes centralizados, dependencias revisadas, pruebas negativas y revisión de seguridad antes del piloto). No se asegura cumplimiento legal específico sin revisión institucional/jurídica ni se certifica exactitud de IA.

### 12.1 Registro de decisiones derivadas de esta ERS

Se conservan los 13 módulos originales, roles, pesos, semáforo provisional y etapas del Maestro. La arquitectura se actualiza exclusivamente en el núcleo PHP y sus servicios de soporte conforme a DA-01; se mantienen PostgreSQL, pgvector y el servicio Python. Se descomponen módulos en requisitos comprobables. Las adiciones P detallan necesidades para implementar y probar: recuperación de cuenta, asignaciones, catálogos inactivos, retirada de índice, idempotencia, protección de auditoría, exclusión de auto-coincidencias, hito final, mínimos de cobertura, PDF y WCAG como propuesta, controles de archivos y métricas operativas. Se incluyen por seguridad, integridad, explicabilidad o claridad; requieren revisión, no sustituyen decisiones institucionales. La expansión de RF-13 no adelanta funcionalidades al MVP. No se fija proveedor generativo, versión de librerías, umbrales definitivos ni esquema físico.

## 13. Entrega para Codex y control de cambios

Guardar esta ERS como `docs/02_REQUERIMIENTOS.md` en el repositorio Git. Conservar el Maestro como fuente de visión. Documentos siguientes: `docs/01_VISION.md` (consolidación), `docs/03_ARQUITECTURA.md`, `docs/04_SIMILITUD.md`, `docs/05_INTERFACES.md`, `docs/06_SEGURIDAD.md`, `docs/07_PLAN_PRUEBAS.md` y `AGENTS.md`. Los cambios de arquitectura se registrarán mediante decisiones justificadas (ADR); los cambios funcionales deben referenciar RF, RN y CP afectados.

Cada tarea de Codex deberá indicar: ID de requisito, alcance exacto, precondiciones, criterio de aceptación, pruebas y restricciones de seguridad. No implementar funcionalidades E sin aprobación, no modificar pesos o transiciones sin registro de decisión, no conectar IA externa por defecto, no usar datos reales en pruebas sin autorización. Las pruebas deben emplear datos sintéticos o un corpus institucional autorizado y aislado. Los requisitos pendientes no deben resolverse silenciosamente en código; se documentarán y validarán antes de producción.

**Siguiente paso propuesto:** validar esta ERS, especialmente PV-01, PV-02, PV-03, PV-05 y PV-07; luego desarrollar arquitectura y modelo conceptual/lógico, interfaces internas y estrategias de aislamiento. Preparar en paralelo muestra de proyectos reales etiquetados para el prototipo temprano de similitud.
