# Seguridad

## Fundamentos

- Rol de migraciones separado del rol web. Seguridad por fila con denegación por defecto en la tabla inicial.
- Credenciales por entorno, acceso local por loopback y conexión interna a PostgreSQL y PHP-FPM.
- Front controller fijo, respuestas de error genéricas, logs sin mensajes de excepción ni credenciales, cabeceras HTTP restrictivas.

## Controles de etapas posteriores

La identidad y la autorización requieren sesiones seguras, verificación y hash de contraseñas, rate limiting, CSRF, validaciones del servidor y auditoría. Cada capa deberá respetar institución y permiso sobre el recurso. El contexto SQL es una defensa adicional frente a errores de consulta y debe derivarse de una autorización del servidor. Las vistas dinámicas deberán escapar contenido según el contexto.

Los documentos se validarán y almacenarán en privado. Archivos, trabajos, consultas vectoriales y exportaciones requerirán pruebas de acceso cruzado. El perfil de producción deberá incorporar TLS, gestión de secretos, respaldos cifrados y restauración probada. La salida a servicios de IA externos depende de autorización previa.
