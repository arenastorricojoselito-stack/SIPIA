# Plan de implementación

| Etapa | Alcance | Criterio de salida |
|---|---|---|
| 1 | Fundamentos MVC, configuración, seguridad HTTP básica, Docker y migraciones | Construcción, ejecución local y pruebas iniciales verificadas. |
| 2 | Identidad, roles, instituciones, auditoría base y tablero | Inicio y cierre de sesión, permisos y aislamiento por institución probados. |
| 3 | Catálogos, participantes y configuración académica | Reglas institucionales verificadas con datos sintéticos. |
| 4 | Repositorio, carga, fichas y versiones | Documentos privados y consultas autorizadas, con gestión de lotes. |
| 5 | Prototipo documental y semántico | Extracción, OCR y recuperación evaluados con corpus autorizado. |
| 6 | Propuestas, comparación híbrida y evidencias | Versiones, candidatos, puntuación, cobertura y referencias verificables. |
| 7 | Evaluación, correcciones y cierre | Decisión motivada, versiones y entrega final trazables. |
| 8 | Reportes y calidad de piloto | Indicadores, informes y pruebas integrales según ERS. |

El alcance inmediato termina en la Etapa 1. RF-13 queda en el backlog de evolución. Los pendientes PV-01 a PV-10 se tomarán de la ERS y se validarán antes de cerrar los criterios afectados.
