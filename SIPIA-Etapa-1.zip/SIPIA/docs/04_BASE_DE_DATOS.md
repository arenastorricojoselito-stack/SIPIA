# Base de datos

PostgreSQL 16 con pgvector. La migración inicial habilita la extensión, crea `sipia.institutions` y activa seguridad por fila. El rol web dispone de lectura únicamente. Sin contexto institucional, recibe cero filas. `InstitutionScope` aplica el contexto dentro de una transacción de solo lectura. Solo debe recibir una institución cuya autorización haya comprobado el servidor.

El historial de migraciones guarda nombre, suma SHA-256 y fecha. Una transacción y un bloqueo de la base serializan la aplicación. Las migraciones publicadas se amplían con archivos nuevos.

Pendiente de diseño físico según la ERS §7.2: identidades y membresías, catálogos por institución, proyectos y autores, versiones y archivos, secciones y vectores, análisis y evidencias, evaluaciones, configuraciones y auditoría. Las relaciones y políticas de los módulos posteriores deberán impedir referencias cruzadas entre instituciones.
