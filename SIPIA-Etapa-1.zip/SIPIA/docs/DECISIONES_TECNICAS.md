# Decisiones técnicas

## ADR-001 · Núcleo MVC nativo

Se aplica DA-01 de la ERS. PHP 8.4, Composer PSR-4 y PDO son la base. PHPUnit se usa en desarrollo. El router y el manejo de errores centralizados cubren la superficie HTTP de la primera etapa. Las dependencias de futuras etapas se evaluarán por licencia, mantenimiento y seguridad.

## ADR-002 · Aislamiento inicial en PostgreSQL

El rol de aplicación carece de privilegios administrativos y seguridad por fila limita la lectura por institución. El ámbito se fija localmente a una transacción. El esquema se administrará mediante SQL versionado, con credenciales privilegiadas confinadas al servicio de migración. La autorización previa del ámbito se integrará con la identidad en la etapa correspondiente.

## ADR-003 · Alcance y nomenclatura documental

Se conservan ambas fuentes v1.1 sin edición. Los nombres de los documentos técnicos siguen la instrucción de inicio del desarrollo. Las referencias a otros nombres en la ERS corresponden a su propuesta de organización.

## ADR-004 · Dependencias de desarrollo

Composer fija PHPUnit y sus dependencias en el archivo de bloqueo. El
núcleo usa PHP y PDO sin paquetes Composer de ejecución. En desarrollo
se elige PHP 8.4 y PostgreSQL 16 como versiones de referencia. La revisión
de licencias de bibliotecas de procesamiento y modelos se hará antes de
adoptarlos.
