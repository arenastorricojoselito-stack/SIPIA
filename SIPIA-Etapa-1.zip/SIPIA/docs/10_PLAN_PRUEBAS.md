# Plan de pruebas

| Etapa | Verificación |
|---|---|
| 1 | PHPUnit para rutas, métodos, cabeceras, errores y configuración PDO. SQL con dos instituciones sintéticas para aislamiento, rol web y pgvector. HTTP local para portada, estado, rutas desconocidas y rechazo de métodos. |
| 2–4 | Autenticación, autorización, catálogos y documentos. Cubrir éxito, errores, acceso directo por identificador y cruces de institución. |
| 5–6 | Extracción, OCR, embeddings, trabajos, fallos y reintentos. Corpus etiquetado y evidencia por sección. |
| 7–8 | Correcciones, concurrencia de decisiones, entrega final, informes, restauración, accesibilidad y carga. |

Los CP-01 a CP-23 de la ERS siguen siendo la referencia de aceptación. La prueba inicial SQL cubre la parte de lectura de instituciones de CP-07. Las rutas, colas, documentos y exportaciones de etapas posteriores requieren sus propias pruebas. El README documenta la ejecución local.
