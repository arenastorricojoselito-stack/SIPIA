# Estado del proyecto

## Etapa 1 · Fundamentos

- Base MVC con Composer PSR-4, controladores, vistas, rutas, cabeceras, configuración, validación y logs.
- Compose local con Nginx, PHP-FPM, PostgreSQL 16 y pgvector.
- Migración serializada y repetible. Rol web de solo lectura y aislamiento inicial por fila en instituciones.
- Portada en español, estado de disponibilidad y documentación de arranque.

## Verificación

- PHPUnit 12.5.45 ejecutó 4 pruebas y 11 aserciones con éxito. Composer validó el manifiesto y el archivo de bloqueo. El análisis de sintaxis de PHP pasó.
- La migración inicial y su repetición finalizaron con código 0. Con dos instituciones sintéticas, el rol web no recibió filas sin contexto y solo recibió la propia al aplicar cada contexto. La prueba verificó denegación por identificador, ausencia de permisos de escritura y una operación de pgvector.
- Nginx y PHP-FPM sirvieron la portada y el estado. Se verificaron las respuestas 404 y 405, las cabeceras y el estado 503 durante la detención de PostgreSQL. El estado volvió a estar disponible tras reiniciar la base.
- Para verificar la compilación en la nube, se usó la CA del entorno y el servidor oficial de archivos de GitHub para descargar las mismas revisiones del archivo de bloqueo, porque el proxy bloquea API GitHub. El lock del repositorio conserva las URL originales de Composer.
- La resolución de Composer no reportó avisos de seguridad. Las dependencias instaladas de desarrollo declaran licencias MIT o BSD-3-Clause.

## Pendientes

Etapa 2 pendiente de revisión. Incluye autenticación, sesiones, roles,
permisos, gestión institucional, auditoría funcional y tablero Bootstrap.
La separación inicial de PostgreSQL se verificó en la tabla de instituciones.
El contexto autorizado del servidor y el aislamiento de los demás recursos
se verificarán al desarrollar sus módulos. El procesamiento documental,
FastAPI, la cola, el motor semántico, la evaluación y los informes se
mantienen en el plan. Ver ERS v1.1 para las decisiones institucionales pendientes.
