# Motor de similitud

Diseño de referencia para las etapas 5 y 6. FastAPI coordinará procesamiento con PyMuPDF, python-docx y Tesseract, con conversión controlada de DOC cuando sea viable. Sentence Transformers generará vectores multilingües. La recuperación textual y vectorial se limitará al corpus autorizado y persistirá las versiones, parámetros y evidencias.

| Campo | Peso inicial |
|---|---:|
| Título | 5 % |
| Problema | 15 % |
| Objetivo general | 15 % |
| Objetivos específicos | 10 % |
| Solución | 20 % |
| Funcionalidades o procesos | 20 % |
| Innovación | 15 % |

La cobertura es la proporción de peso comparable. El índice es el promedio ponderado de los campos comparables, provisional si faltan campos. Con peso comparable nulo no se calcula. Los umbrales, modelos y metas se calibrarán con pares etiquetados y una muestra independiente. La evidencia debe incluir referencias verificables. Las decisiones académicas corresponden a responsables autorizados. La generación externa requiere autorización institucional.
